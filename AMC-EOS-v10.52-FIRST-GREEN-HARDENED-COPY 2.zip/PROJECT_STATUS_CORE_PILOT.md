# AMC-EOS Core Pilot — Evidence-Based Status

## What changed in this build

The core pilot now has a coherent referral-to-admission entry path instead of mixing the legacy referral model and the v6.1/v6.2 production models.

### Referral golden path
- Referral create is idempotent through `X-Idempotency-Key`.
- Referral create and transition events use the canonical outbox service and `eventType` schema field.
- Duplicate candidates preserve the fields that contributed to the match score.
- Status transitions use optimistic, tenant-constrained mutations to prevent stale concurrent actions.
- Create, assign, eligibility and status changes emit audit evidence.
- Referral scoring now maps the HTTP DTO to the shared referral-domain scoring contract correctly.
- Public DTOs have bounded lengths and controlled enum values.

### Pilot web workflow
- `/referrals/new` uses the production referral API rather than the legacy referral API.
- `/referrals` and `/referrals/dashboard` use the production referral model.
- `/referrals/[id]` uses the authenticated API helper rather than unauthenticated relative `fetch()`.
- The detail workspace includes guided lifecycle actions and an eligibility form.
- Accepted referrals link directly into the production admission workspace.
- The Playwright golden-path source now performs actual referral form entry, eligibility approval, acceptance and admission creation instead of route-only navigation.

### Admission bridge fixes
- The pilot housing model currently stores beds directly under homes and has no canonical Room model. `roomId` is therefore optional for v6.2 reservations until an explicit room model is introduced.
- A migration source is included for the nullable reservation room ID.
- Admission completion now creates a canonical Client from the accepted referral before creating a canonical Resident. It no longer uses a referral ID as a client ID.
- The resident preferred name is sourced from the referral rather than hard-coded as `New Resident`.
- A successfully completed admission closes the accepted referral.

## Validation executed in this environment

- Core golden-path contract: 10/10 checks passed.
- Core product boundary: passed.
- Tenant-safe mutation audit: 60 classified, 56 safe, 4 approved internal exceptions, 0 unsafe.
- TypeScript/TSX syntax transpilation: 420 files passed.
- Offline API actionable diagnostics: 0 after diagnostic-stub correction.
- Dependency-free source tests: 17 passed, 0 failed.
- Pilot regression tests: 18 passed, 0 failed.
- Build-readiness preflight: passed.

These are legitimate offline/static checks. They do not replace a dependency-backed NestJS/Prisma/PostgreSQL/Jest/Playwright run.

## Current product position

| Workstream | Status |
| --- | --- |
| Core product scope | Defined and feature-flagged |
| Core readiness | Integrated source implementation |
| Authentication | Hardened source + extensive test source |
| Referral intake | Golden path source implemented |
| Eligibility review | Golden path source implemented |
| Referral acceptance | Guided source workflow implemented |
| Admission start | Integrated with accepted referral |
| Bed reservation | Transaction-safe source exists; pilot room mismatch corrected |
| Resident creation | Admission bridge corrected to canonical Client + Resident |
| Daily service | Existing source available; not yet tied into the golden-path browser flow |
| Real dependency install | Not verified |
| Prisma generation/migrations | Not verified |
| PostgreSQL integration | Not verified |
| Jest dependency-backed run | Not verified |
| Playwright runtime run | Not verified |
| Staging deployment | Not verified |

## Highest remaining risks

1. **Runtime proof** — package installation and the real compiler/test stack have not executed in this environment.
2. **Duplicate model generations** — the schema contains legacy/canonical records and version-suffixed domain records. The pilot must choose one canonical write path per business capability.
3. **Admission readiness gaps** — funding, guardian verification, signatures and checklist completion need usable UI actions before admission completion can be demonstrated end to end.
4. **Daily-service handoff** — the created resident must flow into the DSP daily-service workspace using one canonical resident identifier.
5. **Migration validation** — the new nullable `roomId` migration and the historical migration chain must be run against disposable PostgreSQL.

## Honest readiness

The source architecture and core-pilot path are advanced, but production readiness is not 90%+. A practical evidence-based estimate is approximately **40–50% toward a deployable pilot** because the major runtime gates remain unverified.
