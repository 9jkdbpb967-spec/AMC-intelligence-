# AMC-EOS v4.4 — Analytics Hardening & Executive Briefings

Adds role-based dashboard layouts, KPI comparison and certification, report subscriptions and delivery history, CSV exports, executive briefings, and data-quality remediation tasks.
