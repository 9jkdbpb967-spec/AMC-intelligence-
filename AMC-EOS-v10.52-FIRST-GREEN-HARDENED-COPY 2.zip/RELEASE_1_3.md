# AMC-EOS Enterprise v1.3 — Pilot Workflow Implementation

This release begins implementing the pilot-priority screen registry rather than expanding only planning documents.

## Implemented APIs
- Tenant-scoped people/applicant directory and profiles
- Tenant-scoped referral assessments
- Tenant-scoped homes and bed capacity
- Audit events for applicant, assessment, and home mutations

## Implemented screens
- People directory
- Add person
- Person profile
- New referral
- Referral workspace
- Assessment workspace embedded in referral
- Homes and capacity
- Pilot reports catalog

## Production limitations
This remains a pilot engineering release. It is not authorized for real protected health, Medicaid, employee, or financial data until CI, migrations, tenant-isolation tests, security review, backups, and privacy controls pass.
