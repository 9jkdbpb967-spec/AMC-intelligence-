# AMC-EOS v4.8 — Mobile Production Validation & Pilot Controls

Adds encrypted offline drafts, explicit server conflict records, push-provider abstraction, rollout administration, mobile security controls, tests, migration source, and pilot validation documentation. External push delivery remains disabled until an approved provider and secrets resolver are configured.
