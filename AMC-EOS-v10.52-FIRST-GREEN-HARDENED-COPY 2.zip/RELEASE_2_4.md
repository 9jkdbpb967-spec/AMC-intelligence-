# AMC-EOS Enterprise v2.4 — CI & Migration Baseline

This release hardens the repository rather than adding a new business module.

## Implemented

- Native npm-workspace orchestration without a Turbo runtime dependency.
- Static Prisma structural validation and model inventory.
- OpenAPI structural validation.
- Machine-readable static release evidence.
- Multi-stage development/build/production Dockerfiles.
- Explicit Compose development and production build targets.
- CI split into static-contract and dependency/build/test gates.
- Mandatory lockfile and reviewed-migration release gates.
- Migration-baseline documentation that refuses fabricated SQL.

## Not yet validated

Dependency installation, Prisma generation, compilation, Jest, Playwright, Docker startup, and production migrations remain pending in a normal engineering environment.
