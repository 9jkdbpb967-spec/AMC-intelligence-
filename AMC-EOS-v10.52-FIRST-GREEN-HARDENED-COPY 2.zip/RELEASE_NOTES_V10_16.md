# AMC-EOS v10.16 Release Notes

Adds a GitHub Actions workflow that uses the public npm registry to install an exact standalone `pnpm@10.15.0` executable, generate the real lockfile, perform a frozen install, package the pnpm store, verify the produced archive, and upload it as an artifact.

The offline bundle producer now executes and validates the supplied pnpm binary before packaging it and again after copying it into the bundle. Producer provenance fields include workflow run ID, run attempt, repository, ref, and Git commit.

No real dependency-backed build is claimed until the workflow artifact is generated, downloaded, imported, and processed by `run_offline_build_pipeline.py`.
