# AMC-EOS Enterprise v2.3 — Production Repository Baseline

This release converts the implemented v2.2 source tree into an engineering-governed production repository baseline. It adds reproducible commands, repository contracts, architecture decisions, CI/E2E workflows, migration gates, production Compose behavior, and an evidence-based readiness matrix.

It does not claim production readiness. Dependency installation was blocked in the artifact environment because its internal npm registry did not contain an existing dependency. Compile, test, migration, and runtime gates remain pending.
