# Kubernetes blueprint
Planned resources: namespaces, network policies, deployments, services, ingress, autoscaling, disruption budgets, workload identity, external secrets, database migration job, and telemetry collectors.
