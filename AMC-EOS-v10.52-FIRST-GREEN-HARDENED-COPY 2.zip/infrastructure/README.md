# Infrastructure

Infrastructure code is divided into local Docker, Kubernetes deployment templates, and Terraform-managed cloud resources. No production credentials or raw secret values belong in this directory.
