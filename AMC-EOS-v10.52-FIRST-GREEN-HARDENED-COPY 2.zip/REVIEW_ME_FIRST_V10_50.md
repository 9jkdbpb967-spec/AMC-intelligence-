# REVIEW ME FIRST — AMC-EOS v10.50

This release addresses the v10.49 staging-migration safety review.

Review these first:
- `V10_50_STAGING_MIGRATION_SAFETY_REPORT.md`
- `apps/api/scripts/staging-migration-safety.ts`
- `apps/api/scripts/migrate-workforce-v64-staging.ts`
- `apps/api/scripts/migrate-resident-v63-staging.ts`
- `apps/api/scripts/migrate-finance-v65-staging.ts`
- `apps/api/scripts/migrate-analytics-v66-staging.ts`
- `apps/api/scripts/database-fingerprint.ts`
- `apps/api/prisma/migrations/20260807112000_staging_migration_ledger/migration.sql`
- `scripts/runtime/prepare_staging_apply_authorization.py`
- `scripts/quality/validate-v1049-staging-migrations.py`
- `release-evidence/v10.50/`

Runtime boundary: Phase 1/PostgreSQL and staging dry-runs are still unexecuted in this environment because pnpm and DATABASE_URL are unavailable.
