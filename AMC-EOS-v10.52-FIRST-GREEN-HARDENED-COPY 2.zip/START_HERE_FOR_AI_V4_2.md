# Start Here — AMC-EOS v4.2

1. Read PROJECT_STATE_V4_2.json and PMO_DASHBOARD_V4_2.md.
2. Run the dependency-free pilot tests in pilot-runtime.
3. Review migration 011 before production migration generation.
4. Use docs/ai-prompts/V4_3_CONTINUATION_PROMPT.md for the next build.
5. Do not claim Node/PostgreSQL production validation without actual logs.
