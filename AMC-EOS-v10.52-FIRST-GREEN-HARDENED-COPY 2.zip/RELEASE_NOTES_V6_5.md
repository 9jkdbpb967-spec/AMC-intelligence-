# AMC-EOS v6.5 Alpha

Commit 0014 adds the production finance and purchasing vertical slice. This release is source-complete and statically validated. It is not approved for accounting, payment, payroll, tax, or protected-data production use until the remaining engineering and domain-review gates pass.
