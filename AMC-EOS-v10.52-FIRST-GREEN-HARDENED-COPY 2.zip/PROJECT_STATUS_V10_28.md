# AMC-EOS Project Status — v10.28

## Executive summary

AMC-EOS now has a real Core Readiness vertical slice rather than a static readiness page. The backend evaluates seven tenant-scoped pilot capabilities and the frontend consumes that live result on both the readiness workspace and executive dashboard.

The repository is structurally advanced and offline validations are green. The main program risk is still runtime proof: the real pnpm install, NestJS semantic build, Prisma client generation, PostgreSQL migrations, Jest and Playwright have not been executed in this environment.

## Completed in this release

| Work line | Completion |
|---|---:|
| Core readiness API module | 100% |
| Authenticated tenant boundary | 100% |
| Database probe | 100% |
| Authentication configuration probe | 100% |
| Referral/admission/resident/daily-service probes | 100% |
| Available-bed capacity probe | 100% |
| Stable readiness response contract | 100% |
| Swagger DTO source | 100% |
| Web readiness workspace integration | 100% |
| Executive dashboard readiness card | 100% |
| Unit-test source | 100% |
| Offline implementation validation | 100% |

## Executed evidence

| Validation | Result |
|---|---:|
| Core readiness implementation contract | Passed |
| Core product release boundary | Passed |
| TypeScript/TSX syntax transpilation | 420 files passed |
| Package graph | 28 packages passed |
| Dependency-free source tests | 17 passed / 0 failed |
| Pilot regression tests | 18 passed / 0 failed |
| Build-readiness preflight | 4 passed / 0 failed |
| New Core Readiness actionable offline errors | 0 |

Two remaining API diagnostic messages are in the authentication integration harness and arise from intentionally incomplete offline constructor stubs for Prisma and JwtService. They require re-evaluation with the real packages installed.

## Current program position

| Area | Evidence-based position |
|---|---:|
| Business/product architecture | 95% |
| Core pilot scope definition | 100% |
| Backend module structure | 90% |
| Backend source hardening | 90% |
| Core readiness vertical slice source | 100% |
| Frontend core navigation and readiness | 85% |
| Offline/static validation | 90% |
| Real dependency-backed compilation | 0% verified |
| Prisma/PostgreSQL runtime validation | 0% verified |
| Jest/Playwright runtime execution | 0% verified |
| Pilot deployment | 0% verified |
| Overall production readiness | 35–45% |

## Smart execution plan

### 1. Freeze the pilot boundary

Do not add finance, AI, advanced analytics or integrations to the pilot. Keep the active product flow limited to authentication, referrals, admissions, bed inventory, residents, daily service and manager readiness.

### 2. Build vertical slices, not layers

Complete one user outcome through database, API, UI and tests before starting another. The next slice should be referral intake through eligibility review.

### 3. Use one canonical data model per pilot capability

The schema contains multiple versioned models. The pilot must explicitly choose the canonical Referral, Admission, Resident and Daily Service records and stop adding new version-suffixed duplicates.

### 4. Prioritize runtime proof over more scaffolding

The next environment-enabled milestone is a real lockfile, frozen install, NestJS build, Prisma validation and PostgreSQL migration. No source-completion percentage should substitute for those gates.

### 5. Treat readiness as an operational release gate

Core readiness should be called during deployment smoke tests, before user acceptance testing and before every pilot shift. A blocked database or authentication check must prevent pilot promotion.

### 6. Reduce the first pilot workflow to one golden path

Automate exactly one path first: login → create referral → record eligibility → accept referral → reserve bed → complete admission → open resident → submit daily note → verify dashboard.

## Next commit

### Commit 0077 — Referral Intake Golden Path

- Create a concise referral intake wizard.
- Standardize referral create and eligibility DTOs.
- Add idempotency to referral submission.
- Add duplicate-candidate review without automatic merging.
- Emit audit and outbox events.
- Add a tenant-isolation integration-test contract.
- Add the first form-complete Playwright segment from login through accepted referral.
