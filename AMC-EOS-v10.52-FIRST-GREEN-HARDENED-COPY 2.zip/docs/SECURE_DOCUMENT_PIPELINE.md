# Secure Document Pipeline

This release adds the document lifecycle model but not cloud-provider credentials.

1. API creates metadata record in `PENDING_UPLOAD`.
2. Storage adapter issues a short-lived presigned upload URL to a private bucket.
3. Client uploads directly to object storage.
4. Event queues malware scan.
5. Scanner reports `AVAILABLE` or `QUARANTINED`.
6. Downloads use short-lived signed URLs only when status is `AVAILABLE`.
7. Every create, scan, access, download, retention change, and delete is audited.

Required controls: encryption, private buckets, object versioning, checksum verification, MIME allowlist, file-size limits, malware scanning, retention holds, tenant-prefixed keys, no public URLs, and tested deletion workflows.
