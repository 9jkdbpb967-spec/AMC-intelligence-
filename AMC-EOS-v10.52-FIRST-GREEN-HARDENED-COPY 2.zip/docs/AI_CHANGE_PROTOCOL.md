# AI Change Protocol

Use this protocol whenever another AI service changes the repository.

## Before Changes
- Create a new branch.
- State the story, files expected to change, and assumptions.
- Confirm no real sensitive data is used.
- Read the relevant module spec and architecture decisions.

## During Changes
- Make small, reviewable commits.
- Do not weaken authentication, authorization, validation, auditing, or logging.
- Keep schemas, APIs, UI, tests, and documentation synchronized.
- Add comments only for non-obvious decisions.

## After Changes
Provide:
1. Summary
2. File list
3. Schema/API changes
4. Tests executed and results
5. Security/privacy review
6. Known limitations
7. Migration and rollback steps
8. Suggested next story

## Prohibited AI Actions
- Claiming legal, regulatory, security, or HIPAA compliance without independent evidence.
- Introducing third-party assets without license documentation.
- Storing secrets in source code.
- Disabling tests or guards to make a feature pass.
- Deleting audit history or operational records without an approved retention rule.
