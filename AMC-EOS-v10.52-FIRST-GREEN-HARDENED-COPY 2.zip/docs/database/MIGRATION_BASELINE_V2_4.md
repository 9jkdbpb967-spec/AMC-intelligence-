# Migration Baseline — v2.4

## Status

- Schema structural preflight: implemented.
- Schema inventory generation: implemented.
- Reviewed migration SQL: **not generated in this environment**.
- Production migration gate: enforced in CI.

## Why no fabricated SQL is included

The repository has evolved through several conceptual schema releases without a verified predecessor database snapshot. Generating a single destructive baseline without that state could lose data or create false confidence. The correct procedure is to restore the actual prior database, generate a create-only migration, inspect it, run it against disposable copies, and document rollback or restore evidence.

## Exit criteria

- `package-lock.json` committed.
- Prisma format and validation pass.
- Reviewed migration directory committed.
- Forward migration passes on a clean database and a restored predecessor database.
- Backup restoration is tested.
