# v2.2 Migration Blueprint
1. Back up and restore-test the database.
2. Add new enums and tables as nullable/non-destructive additions.
3. Seed readiness rules by tenant and role.
4. Backfill no data automatically without HR review.
5. Generate migration with Prisma against the actual v2.1 database.
6. Inspect indexes, constraints, enum changes, and rollback SQL.
7. Run two-tenant and schedule-conflict tests.
8. Deploy behind feature flags.
