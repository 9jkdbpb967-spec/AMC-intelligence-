# v1.8 Migration Blueprint

1. Back up and restore-test the current database.
2. Generate Prisma client and run `prisma validate`.
3. Create a reviewed migration in a clean branch.
4. Add the new enums and service-plan records without removing existing data.
5. Backfill current ServicePlan/ResidentGoal rows where they exist: planNumber, createdByUserId, servicePlanId and lifecycle status.
6. Add non-null constraints only after backfill verification.
7. Verify tenant IDs on every new record and index.
8. Run two-tenant isolation tests, lifecycle tests and activation concurrency tests.
9. Deploy to staging and test revision, approval, activation, progress and reminder workflows.
10. Prepare rollback SQL before production approval.

Do not apply this schema directly to a database containing protected information without reviewed migration SQL.
