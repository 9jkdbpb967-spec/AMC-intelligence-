# v2.1 Migration Blueprint

1. Back up PostgreSQL and verify restore.
2. Run `npx prisma format` and `npx prisma validate`.
3. Generate a named migration in a disposable environment.
4. Review enum additions, EmployeeProfile expansion, Shift replacement, indexes, and nullable-column backfill.
5. Backfill firstName/lastName for legacy employee rows before making them required in production.
6. Translate legacy Shift.status into Shift.lifecycleStatus.
7. Run two-tenant isolation, scheduling overlap, credential expiration, and training deadline tests.
8. Rehearse rollback from backup before production deployment.
