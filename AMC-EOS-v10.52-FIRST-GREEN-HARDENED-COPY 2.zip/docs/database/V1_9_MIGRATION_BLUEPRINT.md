# v1.9 Migration Blueprint

1. Back up the development database.
2. Run `npx prisma format` and `npx prisma validate`.
3. Generate a named migration with `npx prisma migrate dev --name daily_documentation_v1_9`.
4. Review enum creation and ProgressNote alterations for existing rows.
5. Backfill existing ProgressNote.status to DRAFT and lateEntry to false.
6. Verify indexes for resident/date and status/submittedAt queries.
7. Run tenant-isolation and lifecycle tests.
8. Test rollback in a disposable database before production promotion.
