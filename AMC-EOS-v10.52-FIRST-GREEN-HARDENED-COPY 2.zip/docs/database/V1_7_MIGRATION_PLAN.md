# v1.7 Resident Foundation Migration Plan

## New models
- ResidentGuardian
- ResidentFunding
- ResidentPreference
- ResidentRiskFlag
- ResidentNote
- ResidentTimelineEvent
- ResidentStatusHistory
- ResidentTag

## Resident changes
Adds bed assignment, resident number, pronouns, preferred communication, primary language, and risk level.

## Safe migration sequence
1. Back up and restore-test the target database.
2. Generate a draft Prisma migration against the actual v1.6 schema.
3. Review unique indexes, especially `(tenantId, residentNumber)`.
4. Backfill `bedId` and `admissionId` from admissions where unambiguous.
5. Create initial admission timeline events for existing resident records.
6. Run two-tenant isolation tests.
7. Run admission idempotency tests to prevent duplicate residents.
8. Deploy API before enabling resident UI navigation.
9. Verify rollback using a restored database copy rather than destructive production rollback.
