# V1.4 Migration Plan

Adds `IntakeChecklistItem`, `ReferralActivity`, `IdempotencyKey`, and `Bed.notes`.

1. Back up the development database.
2. Run `npm run db:generate`.
3. Create a named Prisma migration.
4. Inspect unique keys, tenant indexes, and foreign-key delete behavior.
5. Apply it to a disposable database.
6. Seed two tenants and run isolation tests.
7. Document rollback using database restore; Prisma migrations are forward-only.
