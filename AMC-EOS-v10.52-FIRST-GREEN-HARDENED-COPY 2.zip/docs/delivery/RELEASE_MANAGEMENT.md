# Release Management

## Branches
- `main`: releasable code.
- short-lived feature branches.
- protected release tags.

## Environments
Development → Integration → Staging → Controlled Pilot → Production.

## Release evidence
Every release must contain test reports, dependency and security scan results, migration plan, rollback plan, known limitations, updated documentation, and approval record.

## Versioning
Use semantic versioning. Pre-production releases retain `0.x`; the current package is a **v1 architecture foundation**, not a claim of production readiness.
