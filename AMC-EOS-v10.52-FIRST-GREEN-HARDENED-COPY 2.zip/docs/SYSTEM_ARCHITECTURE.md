# System Architecture

## Current Architecture
- Monorepo
- Web: Next.js / React
- API: NestJS
- Database: PostgreSQL
- ORM: Prisma
- Local orchestration: Docker Compose
- Authentication: JWT development foundation

## Target Architecture
```text
Browser / Mobile
       |
API Gateway / Web Application Firewall
       |
Identity Provider + MFA
       |
NestJS Domain Modules
       |
PostgreSQL | Object Storage | Queue/Workflow Engine
       |
Audit Store | Analytics Warehouse | Search / Knowledge Index
```

## Domain Module Boundaries
- Identity and Access
- Organizations and Contacts
- Referral Development CRM
- Client Referral and Intake
- Assessments and Admissions
- Homes, Beds, and Capacity
- Tasks and Notifications
- Documents and Records
- Knowledge Base and Document Control
- HR and Credentials
- Training and Competencies
- Quality, Incidents, Complaints, and CAPA
- Finance, Grants, and Procurement
- Reporting and Executive Intelligence

## Integration Rules
- Use versioned APIs.
- Use idempotency keys for externally triggered mutations.
- Prefer events for cross-module side effects.
- Never expose database models directly as public API contracts.
- Maintain audit events for create, read of sensitive records, update, export, delete, permission change, and login events.
