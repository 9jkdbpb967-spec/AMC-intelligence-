# AMC-EOS Enterprise v1.1 Platform Services

## Release objective
Convert the v1.0 architecture foundation into reusable platform services that business modules can safely consume.

## Implemented platform capabilities
1. **Central authorization policy package** — controllers can require named permissions instead of duplicating role lists.
2. **Private object storage** — S3-compatible signed PUT/GET URLs with tenant-prefixed object keys.
3. **Document trust lifecycle** — uploaded objects remain unavailable until a malware scanner marks them AVAILABLE.
4. **Reliable background jobs** — atomic claims, exponential retry, maximum attempts, and dead-letter state.
5. **Transactional outbox foundation** — business transactions can record events in PostgreSQL for later publication.
6. **Typed API client** — a shared client boundary for web, admin, and future mobile applications.
7. **Containerized local services** — PostgreSQL, API, worker, web, and private MinIO storage.

## Non-negotiable boundaries
- Every business record is tenant scoped.
- Object keys begin with `tenants/{tenantId}/`.
- No download URL is issued unless document status is `AVAILABLE`.
- Workers never trust tenant identifiers supplied only inside job payloads; the database job row is authoritative.
- Outbox consumers must be idempotent.
- Permissions are additive and reviewed centrally.

## Still required before production
- Enable the PostgreSQL Testcontainers suite after migration automation is available.
- Use row-level security or a tenant-aware repository abstraction as defense in depth.
- Integrate an actual malware scanning service.
- Add OpenTelemetry export, secret management, backup restoration tests, and penetration testing.
