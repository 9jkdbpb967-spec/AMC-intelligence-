# Phase 2C Resident Consolidation Mapping

Status: preparation only.

## Canonical pilot path

The supported-living pilot keeps the unsuffixed resident ecosystem canonical:

- `Client`
- `Resident`
- `ResidentContact`
- `ResidentGuardian`
- `ResidentFunding`
- `ResidentPreference`
- `ResidentRiskFlag`
- `ResidentNote`
- `ResidentTimelineEvent`
- `ResidentStatusHistory`
- `ResidentTag`
- `ResidentGoal`
- `ResidentDailySummary`
- `ResidentDailyTask`
- `ResidentAppointment`

The V63 resident generation is not the target for pilot writes.

## V63 migration/disposition mapping

| V63 model | Canonical target | Disposition |
|---|---|---|
| `ResidentV63` | `Client` + `Resident` | migrate/match |
| `ResidentContactV63` | `ResidentContact` | migrate |
| `ResidentFundingAuthorizationV63` | `ResidentFunding` | migrate with explicit authorization-field mapping |
| `ResidentRiskV63` | `ResidentRiskFlag` | migrate |
| `ResidentServicePlanV63` | canonical service-plan capability | compatibility/extension required |
| `ResidentGoalV63` | `ResidentGoal` | migrate |
| `ResidentDailyNoteV63` | `ResidentNote` + timeline | migrate |
| `ResidentAppointmentV63` | `ResidentAppointment` | migrate |
| `ResidentCommunicationV63` | resident timeline / future communication model | compatibility/extension required |
| `ResidentTimelineV63` | `ResidentTimelineEvent` | migrate |
| `ResidentDischargeV63` | resident status/discharge lifecycle | migrate with status/history mapping |

## Identity policy

The canonical resident identity remains:

`Tenant + Client -> Resident`

Do not create a second canonical resident merely because a V63 row exists.

V63 migration should first attempt to resolve an existing canonical resident using deterministic identifiers. Ambiguous matches are blocked, not guessed.

## Cutover policy

The V63 production-residents route family may only be retired after:

1. Phase 1 runtime proof passes.
2. Live V63/canonical census exists.
3. V63 resident identity dry-run has zero ambiguous matches.
4. All directly mapped V63 child records reconcile.
5. Service-plan and communication capabilities have explicit compatibility/extension dispositions.
6. Resident golden-path integration still passes using canonical `Resident`.
