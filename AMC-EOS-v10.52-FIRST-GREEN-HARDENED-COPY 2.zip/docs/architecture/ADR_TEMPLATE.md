# ADR-NNNN: Decision title

- Status: Proposed
- Date: YYYY-MM-DD
- Owners:

## Context

## Decision

## Alternatives considered

## Consequences

## Security, privacy, tenant, and compliance impact

## Rollback / migration implications
