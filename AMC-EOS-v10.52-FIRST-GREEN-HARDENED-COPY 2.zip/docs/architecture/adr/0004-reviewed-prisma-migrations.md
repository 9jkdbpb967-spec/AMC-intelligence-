# ADR 0004: Reviewed Prisma Migrations Only

- Status: Accepted
- Date: 2026-08-05

## Decision
Production environments use committed, reviewed `prisma migrate deploy` migrations. `prisma db push` is development-only and is not an acceptable production deployment mechanism.

## Required evidence
Migration SQL, backfill plan, rollback/forward-fix plan, test database execution, and tenant-isolation regression results.
