# ADR 0003: Node 22, npm Workspaces, and Turbo

- Status: Accepted
- Date: 2026-08-05

## Decision
Use Node.js 22, npm workspaces, and Turbo for the production monorepo baseline.

## Consequences
One dependency graph and reproducible task graph cover web, API, workers, E2E tests, and shared packages. A committed lockfile is required before production release; this package does not include one because the build environment could not resolve every dependency from its internal registry.
