# ADR 0005: OpenAPI-First Public Contract

- Status: Accepted
- Date: 2026-08-05

## Decision
Externally consumed REST operations must be represented in OpenAPI 3.1. Generated clients are treated as build artifacts and checked for breaking changes in CI before release.
