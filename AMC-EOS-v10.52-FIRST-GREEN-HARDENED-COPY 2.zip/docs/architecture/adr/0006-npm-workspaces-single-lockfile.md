# ADR-0006: npm workspaces and a single lockfile

Status: Accepted

AMC-EOS uses npm workspaces with one root `package-lock.json`. CI must use `npm ci`; releases are blocked when the lockfile is absent or out of date. This keeps dependency resolution reproducible across the API, web, mobile, worker, and shared packages.
