# ADR-0007: Shared observability contract

Status: Accepted

Applications emit structured logs with tenant, user, request, and correlation identifiers where available. Health, readiness, version, and metrics endpoints are distinct. Protected data must not be placed in logs or metric labels.
