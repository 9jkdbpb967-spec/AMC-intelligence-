# AMC-EOS Architecture Principles

1. **Tenant isolation by default** — every tenant-owned record and query is scoped explicitly.
2. **Least privilege** — users and services receive only required access.
3. **Auditability** — security-relevant and business-critical changes emit immutable audit events.
4. **API contracts first** — DTO validation, OpenAPI documentation, and typed clients remain synchronized.
5. **Modular monorepo** — modules own their domain logic and communicate through explicit contracts.
6. **Human-reviewed AI** — AI outputs are suggestions until approved by an authorized person.
7. **Private data by design** — files are private, encrypted, scanned, and released through expiring links.
8. **Reversible delivery** — migrations and deployments include rollback plans.
9. **Observable operations** — request IDs, structured logs, metrics, traces, and health checks are standard.
10. **Configuration over duplication** — future jurisdictions and service lines extend controlled configuration rather than fork core code.
