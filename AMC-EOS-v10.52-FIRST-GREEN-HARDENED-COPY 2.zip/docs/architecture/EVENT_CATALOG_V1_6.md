# Event Catalog v1.6

## admission.created
Emitted transactionally after a successful admission.
Payload: admissionId, referralId, homeId, bedId.
Potential consumers: notifications, occupancy dashboards, resident onboarding, finance authorization, training assignments.
