# Target Platform Architecture

## Applications
- `apps/web`: staff and manager web application.
- `apps/api`: NestJS domain API and workflow services.
- `apps/admin`: future tenant and platform administration console.
- `apps/mobile`: future field and residential staff application.
- `apps/docs`: future technical and product documentation site.

## Shared packages
- `packages/ui`: accessible design system.
- `packages/auth`: reusable identity and authorization primitives.
- `packages/contracts`: API schemas, events, and shared types.
- `packages/config`: validated configuration.
- `packages/observability`: logging, tracing, and metrics.
- `packages/ai-sdk`: governed interfaces for AI agents and knowledge retrieval.

## Infrastructure
- Local: Docker Compose and MinIO-compatible storage.
- Production target: container orchestration, managed PostgreSQL, private object storage, secrets manager, centralized telemetry, and protected CI/CD environments.

## Domain roadmap
Platform foundation → Referral CRM → Intake/Admissions → Knowledge Base → HR/Training → Quality/Risk → Resident Operations → Finance/Grants → Analytics/AI.
