# Phase 2B Workforce Consolidation Mapping

Status: preparation only. No workforce route cutover is authorized until Phase 1 runtime proof passes and a live workforce census has been reconciled.

## Canonical target

`production-workforce` using V64 models:

- `EmployeeV64`
- `EmployeeCredentialV64`
- `EmployeeTrainingV64`
- `WorkShiftV64`
- `WorkforceCallOutV64`
- `WorkforceTimeEntryV64`
- `WorkforceLeaveRequestV64`
- `WorkforcePerformanceGoalV64`

## Legacy source

Primary legacy models include:

- `EmployeeProfile`
- `Credential`
- `TrainingAssignment`
- `EmployeeAvailability`
- `EmployeeEmploymentHistory`
- `Shift`
- `TimeEntry`
- `LeaveRequest`
- `CallOut`
- `CoverageRequest`
- `Timesheet`
- `PerformanceGoal`
- `RecurringShiftSeries`
- `ShiftSwapRequest`
- `ScheduleConflict`
- `ScheduleApproval`
- `CoachingSession`

## Direct migration mapping

| Legacy | Canonical V64 | Rule |
|---|---|---|
| `EmployeeProfile` | `EmployeeV64` | preserve tenant, employee number, names, email/home; explicit employment status/type mapping |
| `Credential` | `EmployeeCredentialV64` | resolve employee ID through durable employee ID map |
| `TrainingAssignment` | `EmployeeTrainingV64` | resolve employee ID; map course/title/status/due/completion |
| `Shift` | `WorkShiftV64` | resolve employee ID; preserve home, start/end, status |
| `TimeEntry` | `WorkforceTimeEntryV64` | resolve employee/shift IDs; preserve clock in/out |
| `CallOut` | `WorkforceCallOutV64` | resolve shift/employee IDs; preserve reason/status |
| `LeaveRequest` | `WorkforceLeaveRequestV64` | resolve employee ID; preserve dates/type/review status |
| `PerformanceGoal` | `WorkforcePerformanceGoalV64` | resolve employee ID; preserve title/target/progress/status |

## Legacy capabilities without a direct V64 persistence equivalent

These are not safe to drop merely because the core V64 employee/shift models exist:

- employee availability
- employment-history records
- recurring shift series
- shift swap requests
- schedule conflicts
- schedule approvals
- timesheets
- coaching sessions
- coverage requests separate from call-out records

These capabilities need one of three dispositions before workforce cutover:
1. add a V64 canonical equivalent;
2. retain a compatibility read/write adapter temporarily;
3. explicitly retire the capability with product approval and data archive.

## Cutover rule

The 31 legacy workforce routes must not be disabled as one batch until:
- all write paths are inventoried;
- every legacy capability above has a disposition;
- live data census is complete;
- migration dry-run reconciles;
- staging apply passes;
- V64 integration tests cover employee, shift, time, call-out, leave, training, and credential operations.
