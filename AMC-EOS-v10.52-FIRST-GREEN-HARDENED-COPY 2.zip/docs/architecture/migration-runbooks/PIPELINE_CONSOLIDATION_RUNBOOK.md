# Pipeline Consolidation Runbook

Use this process for referrals/admissions first, then workforce, finance, analytics. Residents require a separate mapping because the canonical pilot path intentionally uses the unsuffixed `Client`/`Resident` models.

## Gate A — runtime proof
Do not disable legacy routes until a clean dependency-backed run has passed:
- install
- Prisma generate/validate/migrate
- semantic typecheck
- core pilot integration
- manager operations integration

## Gate B — census
Run:
`pnpm architecture:pipelines:census`

If all losing legacy tables for the domain have zero rows, document the zero-row census and proceed to route cutover.

If legacy rows exist, create an idempotent migration program that:
1. maps tenant IDs and natural identifiers;
2. maps enums/statuses explicitly;
3. records old ID -> new ID;
4. never overwrites a canonical row without a deterministic match policy;
5. emits a reconciliation JSON report;
6. can be rerun safely;
7. leaves legacy rows intact during the first cutover.

## Gate C — route cutover
Set the domain flag to false:
- `LEGACY_REFERRALS_ENABLED=false`
- `LEGACY_ADMISSIONS_ENABLED=false`
- `LEGACY_WORKFORCE_ENABLED=false`

Run the complete core-pilot test suite and inspect logs.

## Gate D — schema retirement
Only after a stable observation period should old tables be archived or dropped in a separate reviewed migration.
