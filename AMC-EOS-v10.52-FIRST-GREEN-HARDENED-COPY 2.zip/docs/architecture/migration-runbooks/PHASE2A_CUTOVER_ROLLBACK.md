# Phase 2A Cutover, Observation, and Rollback Runbook

## Preconditions

Do not start cutover unless:
1. Phase 1 runtime proof is PASS.
2. Live pipeline census exists.
3. Phase 2A dry-run reconciliation is valid.
4. Staging apply has completed without blocked rows.
5. Core-pilot and manager-operations PostgreSQL tests pass after migration.

## Route cutover

Referrals and admissions are independent.

Disable only the domain whose validated cutover decision says `canDisableLegacyRoute: true`.

Referrals:
`LEGACY_REFERRALS_ENABLED=false`

Admissions:
`LEGACY_ADMISSIONS_ENABLED=false`

Do not drop legacy tables.

## Observation window

For at least one release observation window, capture:
- 404/legacy-disabled requests;
- canonical create/update error rates;
- referral-to-admission conversion rate;
- admission completion failures;
- tenant-isolation failures;
- row-count drift between reconciliation report and canonical tables.

## Rollback

Rollback is route-level first:

Set the affected flag back to `true`.

Because Phase 2A migration does not delete legacy rows, the legacy route can be remounted without restoring tables.

Do not automatically copy canonical post-cutover writes back into legacy tables. If rollback requires data convergence, create a reviewed reverse-migration plan based on the observation-window writes.

## Schema retirement

Dropping legacy `Referral`/`Admission` tables is a separate later change and is explicitly outside Phase 2A.
