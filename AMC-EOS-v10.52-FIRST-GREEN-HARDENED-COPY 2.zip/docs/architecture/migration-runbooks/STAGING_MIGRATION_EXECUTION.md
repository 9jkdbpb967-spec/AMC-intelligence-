# Staging Migration Execution

These commands are intended for a disposable or staging PostgreSQL database after Phase 1 reports `status: passed`.

## Dry-run commands

```bash
pnpm migration:phase2b:staging:dry-run
pnpm migration:phase2c:staging:dry-run
pnpm migration:phase2d:staging:dry-run
pnpm migration:phase2e:staging:dry-run
```

## Apply authorization

Apply is never implicit. Each domain requires an explicit environment acknowledgement:

```bash
PHASE2B_ALLOW_APPLY=YES pnpm migration:phase2b:staging:apply
PHASE2C_ALLOW_APPLY=YES pnpm migration:phase2c:staging:apply
PHASE2D_ALLOW_APPLY=YES pnpm migration:phase2d:staging:apply
PHASE2E_ALLOW_APPLY=YES pnpm migration:phase2e:staging:apply
```

## Current implemented migration scope

- Workforce: employee identities, credentials, and training. Shift/time/call-out/leave/goal migration remains deferred until real generated Prisma types and a live census validate all enum/state mappings.
- Residents: matches V63 residents to existing canonical residents, then migrates contacts, funding authorizations, and risk flags. It intentionally does not create new canonical residents from V63 rows. Service plans, goals, notes, appointments, communications, timeline, and discharge records remain deferred because they require stronger provenance or canonical dependencies.
- Finance: vendors and operating budgets. Transactional purchase/invoice chains remain deferred until their relationship mapping is proven in staging.
- Analytics: report definitions and report runs. Certifications, layouts/widgets, subscriptions, schedules, delivery history, and executive briefings remain deferred.

## Safety requirements

- no legacy rows are deleted or updated;
- apply scripts are idempotent through canonical matching where implemented;
- blocked rows produce a nonzero exit code;
- route cutover remains a separate decision;
- table deletion is outside this phase.
