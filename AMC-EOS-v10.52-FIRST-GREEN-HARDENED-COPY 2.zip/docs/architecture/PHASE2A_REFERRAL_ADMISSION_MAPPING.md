# Phase 2A Referral & Admission Consolidation Mapping

Status: preparation only. No data migration or legacy route cutover is authorized until Phase 1 runtime proof passes and the live census has been captured.

## Referral mapping: legacy `Referral` -> canonical `ReferralV61`

| Legacy concept | Canonical target | Rule |
|---|---|---|
| `tenantId` | `tenantId` | exact |
| client name | `firstName`, `lastName` | copy from related legacy `Client`; reject if missing |
| phone | `phone` | normalize empty -> null |
| email | `email` | lowercase/trim when present |
| organization/source | `sourceName` / related metadata | preserve source name when deterministically available |
| urgency | `urgency` | explicit enum/string mapping; unknown -> `ROUTINE` only if migration policy approves |
| status | `status` | use status mapping table below |
| requested service/support needs/funding | canonical referral detail fields or migration metadata | never silently drop; record unmapped values in reconciliation report |
| timestamps | created/updated equivalents | preserve where writable; otherwise record in migration metadata |

### Referral status mapping

| Legacy `ReferralStatus` | Canonical `ReferralV61` migration status |
|---|---|
| `NEW` | `NEW` |
| `INFORMATION_NEEDED` | `INFORMATION_NEEDED` |
| `SCREENING` | `SCREENING` |
| `ASSESSMENT` | `ASSESSMENT` |
| `FUNDING_VERIFICATION` | `FUNDING_VERIFICATION` |
| `MANAGEMENT_REVIEW` | `MANAGEMENT_REVIEW` |
| `APPROVED` | `ACCEPTED` |
| `DECLINED` | `DECLINED` |
| `ADMITTED` | `CLOSED` |

Any value not listed is a hard migration error.

## Admission mapping: legacy `Admission` -> canonical `AdmissionV62`

| Legacy concept | Canonical target | Rule |
|---|---|---|
| `tenantId` | `tenantId` | exact |
| `referralId` | canonical V61 referral ID | must resolve through migration ID map |
| `homeId` | admission/home fields | exact after tenant ownership validation |
| `bedId` | bed reservation / completion state | only migrate if bed belongs to tenant/home and no conflicting active reservation exists |
| `decisionNotes` | decision/notes field | preserve |
| `admittedAt` | completion/admission timestamp | preserve where supported |
| legacy admission status implied by fields | explicit V62 status | derive deterministically and record derivation |

## Identity policy

Migration must create a durable ID map:

`legacy table + legacy id -> canonical table + canonical id`

The migration may match an existing canonical row only when all configured natural-key checks agree. Ambiguous matches are not auto-resolved.

## Safety policy

- dry-run is default;
- no destructive deletes;
- no legacy updates;
- canonical upserts must be idempotent;
- ambiguous rows go to `blockedRows`;
- every skipped/unmapped field is reported;
- post-run reconciliation must include legacy count, canonical count, migrated count, matched count, blocked count, and tenant coverage.
