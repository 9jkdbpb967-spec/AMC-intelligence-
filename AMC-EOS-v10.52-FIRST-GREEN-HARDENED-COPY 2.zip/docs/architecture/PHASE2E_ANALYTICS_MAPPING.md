# Phase 2E Analytics Consolidation Mapping

Status: preparation only. V66 is the canonical target for production analytics writes after runtime proof.

## Canonical V66 scope

- `AnalyticsMetricCertificationV66`
- `AnalyticsDashboardLayoutV66`
- `AnalyticsDashboardWidgetV66`
- `AnalyticsReportDefinitionV66`
- `AnalyticsReportSubscriptionV66`
- `AnalyticsReportRunV66`

## Legacy-only analytics capabilities

- report schedules
- report delivery history
- executive briefings

These require compatibility or canonical extensions before legacy tables can be retired.

## Mapping

| Legacy | V66 target | Disposition |
|---|---|---|
| `AnalyticsMetricCertification` | `AnalyticsMetricCertificationV66` | migrate |
| `AnalyticsDashboardLayout` | `AnalyticsDashboardLayoutV66` | migrate |
| `AnalyticsDashboardLayoutWidget` | `AnalyticsDashboardWidgetV66` | migrate |
| `AnalyticsReportDefinition` | `AnalyticsReportDefinitionV66` | migrate |
| `AnalyticsReportSubscription` | `AnalyticsReportSubscriptionV66` | migrate |
| `AnalyticsReportRun` | `AnalyticsReportRunV66` | migrate |
| `AnalyticsReportSchedule` | compatibility/extension | retain temporarily |
| `AnalyticsReportDeliveryHistory` | compatibility/extension | retain temporarily |
| `AnalyticsExecutiveBriefing` | compatibility/extension | retain temporarily |

## Cutover rule

Do not disable legacy analytics routes until Phase 1 passes, live census exists, directly mapped rows reconcile, and the three legacy-only capabilities have explicit transition owners.
