# Workforce Compatibility Surface

The goal is to retire duplicate core employee/shift/time write paths without prematurely removing useful legacy-only scheduling and HR capabilities.

## Core V64 cutover scope

The following must move to V64 before legacy core workforce routes are disabled:

- employees
- credentials
- training
- shifts
- clock-in / clock-out
- call-outs
- leave requests
- performance goals

## Temporary compatibility scope

The following may continue to use legacy persistence behind clearly labeled compatibility endpoints/services during the transition:

- employee availability
- recurring schedules
- shift swaps
- schedule conflicts
- schedule approvals
- timesheets
- coverage requests

These compatibility capabilities must not create or update legacy `EmployeeProfile`, `Shift`, or `TimeEntry` core records except where strictly required by the legacy feature and documented by the adapter.

## V64 extension scope

These should be migrated into new canonical V64 extension models rather than left indefinitely in legacy tables:

- employment history
- coaching sessions

## Exit criteria

The compatibility surface is temporary. Each capability needs its own canonical model/workflow and integration test before the corresponding legacy table can be retired.
