# Phase 2D Finance Consolidation Mapping

Status: preparation only. V65 is the canonical target for production finance writes after runtime proof.

## Canonical V65 scope

- `FinanceVendorV65`
- `FinanceVendorComplianceV65`
- `FinancePurchaseRequestV65`
- `FinancePurchaseRequestItemV65`
- `FinancePurchaseOrderV65`
- `FinanceReceivingRecordV65`
- `FinanceReceivingItemV65`
- `FinanceVendorInvoiceV65`
- `FinanceVendorInvoiceItemV65`
- `FinanceInvoiceMatchV65`

## Legacy finance capabilities

Legacy finance also contains capabilities that do not have direct V65 equivalents:
- vendor contacts
- vendor contracts
- purchase-request attachments
- invoice discrepancy records
- budget transactions
- reminders

## Mapping

| Legacy | V65 target | Disposition |
|---|---|---|
| `FinanceVendor` | `FinanceVendorV65` | migrate/match |
| `FinanceVendorCompliance` | `FinanceVendorComplianceV65` | migrate |
| `FinancePurchaseRequest` | `FinancePurchaseRequestV65` | migrate |
| `FinancePurchaseRequestItem` | `FinancePurchaseRequestItemV65` | migrate |
| `FinancePurchaseOrder` | `FinancePurchaseOrderV65` | migrate |
| `FinanceReceivingRecord` | `FinanceReceivingRecordV65` | migrate |
| `FinanceReceivingItem` | `FinanceReceivingItemV65` | migrate |
| `FinanceVendorInvoice` | `FinanceVendorInvoiceV65` | migrate |
| `FinanceVendorInvoiceItem` | `FinanceVendorInvoiceItemV65` | migrate |
| `FinanceInvoiceDiscrepancy` | `FinanceInvoiceMatchV65` or compatibility | explicit mapping required |
| Vendor contacts/contracts/attachments/budget/reminders | compatibility/extension | retain until canonical replacement exists |

## Cutover rule

Do not disable legacy finance routes until:
- Phase 1 passes;
- live finance census exists;
- directly mapped entities reconcile;
- all unsupported legacy capabilities have dispositions;
- V65 integration tests cover vendor -> purchase request -> PO -> receipt -> invoice -> match.
