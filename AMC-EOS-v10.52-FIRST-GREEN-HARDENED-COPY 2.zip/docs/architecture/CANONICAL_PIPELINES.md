# AMC-EOS Canonical Domain Pipelines

Status: Phase 0 architecture decision.
Cutover state: preparation only. Legacy routes remain enabled by default until Phase 1 runtime verification succeeds.

## Canonical choices

| Domain | Canonical write/read pipeline | Legacy pipeline to retire after runtime proof |
|---|---|---|
| Referrals | `production-referrals` / `ReferralV61` | legacy `referrals` / `Referral` |
| Admissions | `production-admissions` / `AdmissionV62` | legacy `admissions` / `Admission` |
| Workforce | `production-workforce` / V64 workforce models | legacy `workforce` / `EmployeeProfile`, `Shift`, `TimeEntry`, related legacy models |
| Finance | `production-finance` / V65 finance models | legacy finance pipeline |
| Analytics | `production-analytics` / V66 analytics models | legacy analytics pipeline |
| Residents | canonical `Client`, `Resident`, `ResidentNote`, `ResidentTimelineEvent` | V63 resident pipeline for pilot writes |

## Frozen core-pilot path

`ReferralV61 -> AdmissionV62 -> Client -> Resident -> ResidentNote/Daily Service -> Manager Operations -> Workforce V64`

No new version-suffixed generation is permitted for these pilot domains without an architecture decision record.

## Cutover rule

Legacy routes are controlled by domain-specific environment switches and remain ON by default during Phase 0/1.

- `LEGACY_REFERRALS_ENABLED=true`
- `LEGACY_ADMISSIONS_ENABLED=true`
- `LEGACY_WORKFORCE_ENABLED=true`

After the real Phase 1 build and integration suite pass, each legacy domain may be disabled independently by setting its flag to `false`.

Disabling a legacy route is not permission to drop its database table. A database census and, when required, an idempotent data migration must be completed first.

## Database retirement rule

1. Census both generations.
2. Reconcile identifiers and row counts.
3. Migrate real legacy rows if present.
4. Compare post-migration counts and tenant coverage.
5. Disable legacy routes.
6. Observe runtime.
7. Archive/drop old schema only in a later migration after explicit approval.
