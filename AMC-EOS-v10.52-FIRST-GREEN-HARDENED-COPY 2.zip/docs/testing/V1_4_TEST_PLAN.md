# Version 1.4 Test Plan

## Required gates
1. Generate Prisma client and migration.
2. Run API type checks and unit tests.
3. Start two isolated tenants in PostgreSQL test fixtures.
4. Verify every new checklist, activity, task, home, and bed query rejects cross-tenant identifiers.
5. Run Playwright pilot smoke tests.
6. Generate the typed API client from OpenAPI.
7. Confirm audit records include tenant, user, request, action, and entity identifiers.

## Protected-data gate
No protected data may be used until the complete security, backup, tenant-isolation, and deployment review is approved.
