# Two-Tenant Validation Matrix

Every tenant-owned endpoint must prove:

| Test | Expected result |
|---|---|
| Tenant A reads A record | 200 |
| Tenant A reads B record | 404 or 403 without existence disclosure |
| Tenant A updates B record | 404 or 403 |
| Tenant A attaches B child to A parent | rejected |
| Tenant A searches | only A results |
| Audit event | tenant and actor IDs recorded |
| Background job | claims and writes only inside its tenant |
| Signed file link | object key remains tenant-prefixed |

Domains required before pilot: organizations, referrals, applicants, admissions, residents, service plans, daily notes, incidents, employees, credentials, shifts, tasks, notifications, and documents.
