# Commit 0044 — Repair Branch Promotion & Merge Evidence

Adds a cryptographically identified merge-candidate manifest, verifies the approved base branch has not changed, requires dependency-backed validation when requested, rejects stale or superseded candidates, and generates post-merge verification plus rollback evidence.

The tooling prepares auditable promotion evidence; it does not push branches or merge changes by itself.
