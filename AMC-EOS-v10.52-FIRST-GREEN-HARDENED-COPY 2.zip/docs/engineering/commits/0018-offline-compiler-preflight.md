# Commit 0018 — Offline Compiler Preflight

**Commit:** `chore(validation): add offline TypeScript and package-script preflight`

## Purpose

Increase executed validation coverage without misrepresenting unavailable dependency, PostgreSQL, browser, or container gates.

## Added

- TypeScript compiler-API syntax transpilation across application, package, and test source.
- Package-manifest and local-script target audit.
- Unified offline compiler preflight command.
- Machine-readable evidence for syntax, package scripts, and combined results.

## Executed evidence

- 381 TypeScript/TSX files transpiled successfully with TypeScript 5.8.3.
- 27 non-root package manifests passed script auditing.
- 28 workspace packages passed graph validation.
- 19 repository/domain validators passed.
- 17 dependency-free Node source tests passed.
- 18 runnable pilot regression tests passed.

## Limits

This commit does not claim dependency installation, semantic TypeScript type checking, Prisma CLI validation, PostgreSQL migrations, Jest, Playwright, Docker, or staging deployment.
