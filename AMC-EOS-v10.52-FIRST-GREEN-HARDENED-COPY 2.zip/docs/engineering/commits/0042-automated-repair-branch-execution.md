# Commit 0042 — Automated Repair Branch Execution

Adds a safe, dry-run-first workflow for converting evidence-linked repair plans into package-scoped Git branches and ready-to-open pull-request bundles.

## Controls

- Branch execution is dry-run unless `--execute` is supplied.
- The Git working tree must be clean unless `--allow-dirty` is explicitly supplied.
- Patch files must remain inside the plan's approved package paths.
- Protected runtime/governance paths cannot be changed unless the plan explicitly owns them.
- Targeted validation must pass before the repair is considered merge-ready.
- Commits reference the generated plan title and repair IDs remain in the PR evidence.
- No remote push or pull-request creation occurs without a separately authenticated Git workflow.

## Evidence

Each executed plan produces a binary Git patch, changed-file inventory, validation logs, PR description, reviewer checklist, merge-readiness decision, and optional commit SHA.
