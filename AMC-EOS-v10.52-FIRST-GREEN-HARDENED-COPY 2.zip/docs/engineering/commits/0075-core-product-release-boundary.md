# Commit 0075 — Core Product Release Boundary

Defines the first AMC-EOS pilot product around authentication, referrals, admissions, residents, daily service, and basic workforce visibility. Unfinished modules are removed from the core navigation, a role-aware release contract is introduced, and the synthetic demonstration and Playwright acceptance paths are documented.
