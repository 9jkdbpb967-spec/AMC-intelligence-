# Commit 0054 — API Service & Query Integrity

This commit adds a reusable tenant-owned record assertion contract, bounded-query constants, and a static query-integrity audit for the NestJS API. High-confidence list endpoints were capped to prevent accidental unrestricted reads, and a remaining untyped request helper in the service-plan controller was replaced with `AuthenticatedRequest`.

## Added
- `apps/api/src/common/query-integrity.ts`
- `scripts/toolchain/validate-api-query-integrity.py`
- root command `api:queries:check`

## Validation
The audit currently inventories 117 `findMany` calls, 80 with an explicit `take`, 52 ID-only mutations, and 48 service payloads still typed as `any`. Remaining findings are warnings and form the next repair queue; they are not represented as resolved.
