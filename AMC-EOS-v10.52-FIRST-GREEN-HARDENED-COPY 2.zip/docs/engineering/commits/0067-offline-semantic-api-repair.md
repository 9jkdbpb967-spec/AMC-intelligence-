# Commit 0067 — Offline Semantic API Repair

## Summary

This commit used the repository's diagnostic TypeScript projects to repair concrete API source defects discovered after the v10.18 build-gate work.

## Repairs

- Made `AuthenticatedRequest.tenantId` required at authenticated controller boundaries.
- Corrected typed required-field access in the AI knowledge-source service.
- Removed duplicate `class-validator` imports in daily-service delivery.
- Replaced two remaining DTO `any` fields with strings.
- Corrected the authenticated-request import path in the import controller.
- Added the missing reminder-title field to the background-job payload contract.
- Replaced production-finance controller body `any` types with existing finance DTOs.
- Added the missing `MaxLength` diagnostic declaration.

## Evidence

The offline diagnostic compile now reports zero actionable diagnostics for API and web. Two mobile diagnostics remain classified as contextual dependency cascades. Source-contract tests and pilot regression tests remain green.
