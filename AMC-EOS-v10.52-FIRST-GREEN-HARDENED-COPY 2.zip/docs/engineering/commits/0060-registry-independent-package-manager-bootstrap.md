# Commit 0060 — Registry-independent package-manager bootstrap

This commit does not fabricate a lockfile. It adds three safe paths for using the exact
`pnpm@10.15.0` required by the repository:

1. A verified repository-local portable pnpm executable.
2. A `PNPM_PORTABLE_BINARY` supplied by a trusted CI artifact or administrator.
3. Corepack in an environment with a complete npm registry.

It also adds package-level registry probing so an incomplete mirror is detected before
an install attempt. Credentials are never written to evidence files.
