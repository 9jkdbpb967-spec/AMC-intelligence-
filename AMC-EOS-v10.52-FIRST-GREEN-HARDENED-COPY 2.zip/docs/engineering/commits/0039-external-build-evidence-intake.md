# Commit 0039 — External Build Evidence Intake

## Purpose

Accept a first-green-build evidence bundle from GitHub Codespaces, GitHub Actions, or another approved public-registry environment and convert it into a verified, traceable repair session.

## Added

- External evidence provenance policy.
- Bundle provenance and required-file validator.
- End-to-end external evidence intake orchestrator.
- GitHub Actions workflow that runs the first-green build and exports evidence.
- Regression tests for valid and invalid provenance.

## Defect repaired during execution

The first controlled intake exposed a path mismatch between `release-evidence/runtime-imports` and the importer’s actual `release-evidence/runtime/imports` destination. The intake runner now reads the importer’s returned path and initializes the repair session in that exact directory.

## Safety

Bundles are rejected when they contain unsafe archive paths, links, unsupported providers, missing commit SHA/run ID, or missing `first-green-build.json`.
