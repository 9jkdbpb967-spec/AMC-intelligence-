# Commit 0057 — Internal Query & Prisma Contract Hardening

This commit closes the five unbounded query findings from v10.7 and replaces high-confidence transaction callback `any` types with `Prisma.TransactionClient` in admissions, finance, and AI services.

## Changes

- Bounded admissions lists with the shared maximum page size.
- Bounded finance vendor lists.
- Bounded AI retrieval sources, collection grants, and usage rows.
- Removed a duplicated `take` property in AI knowledge retrieval.
- Added explicit finance DTO contracts.
- Formatted and clarified the production finance service.
- Added a regression gate for unbounded target-domain queries and `tx: any` callbacks.

## Validation boundary

These checks validate source contracts without claiming that the generated Prisma client or NestJS dependency graph has compiled. Real semantic validation still requires dependency installation and `prisma generate`.
