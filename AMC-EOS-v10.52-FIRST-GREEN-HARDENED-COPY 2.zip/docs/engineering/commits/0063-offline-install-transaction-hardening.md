# Commit 0063 — Offline Install Transaction Hardening

The offline pnpm installer now treats lockfile replacement as a transaction. A failed installation restores the repository's prior lockfile or removes the newly imported lockfile when none existed. This prevents failed or incomplete offline installs from leaving the source tree in a misleading state.

The installer also records lockfile digests, bundle provenance, restoration status, and the exact pnpm command in machine-readable evidence.
