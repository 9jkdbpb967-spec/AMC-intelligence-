# Commit 0014 — Production Finance & Purchasing

Implements a tenant-scoped finance operations vertical slice covering vendors, compliance, budgets, purchase requests, approvals, purchase orders, receiving, invoice matching, assets, maintenance, grants, dashboards, API contracts, UI workspaces, and source tests.

Money is represented as integer cents. The module is an operational-control layer and does not replace a certified general ledger, payroll, tax, banking, or grant-compliance system.

## Validation boundary
Static and source-contract validation can run without dependencies. Prisma CLI, PostgreSQL migration deployment, TypeScript builds, Jest, Playwright, accounting review, and security review remain execution gates.
