# Commit 0064 — Offline Dependency Build Pipeline

Adds one resumable, evidence-producing command that consumes a verified offline pnpm bundle and executes the first dependency-backed API gates in order: frozen install, NestJS typecheck, Prisma format/generate/validate, API foundation tests, API build, and optional PostgreSQL migration deployment.

The runner is intentionally blocked when the real bundle is absent. It never treats fixture or diagnostic declarations as production evidence.
