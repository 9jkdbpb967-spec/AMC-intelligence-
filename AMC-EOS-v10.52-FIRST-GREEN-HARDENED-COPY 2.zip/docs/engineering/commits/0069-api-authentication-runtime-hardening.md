# Commit 0069 — API Authentication Runtime Hardening

This commit hardens the API authentication runtime without claiming dependency-backed execution.

## Implemented

- JWT issuer, audience, algorithm, and lifetime configuration.
- Required access-token `jti`, tenant, session, and subject claims.
- Active session, user, membership, and tenant checks during JWT validation.
- Configurable login throttling with stable error codes and retry timing.
- Login success/failure history and authentication audit records.
- Atomic refresh-token rotation and refresh-token reuse detection.
- Tenant-wide session revocation after detected refresh-token reuse.
- No-store authentication responses.
- Password-reset invalidation, single-use consumption, expiry enforcement, audit records, and session revocation.
- Development reset-token disclosure disabled by default and forbidden in staging/production.

## Validation boundary

The source and offline contracts are validated here. Real NestJS boot, JWT verification, Prisma transactions, PostgreSQL behavior, and Jest execution still require installed dependencies.
