# Commit 0011 — Production Admissions Vertical Slice

Implements accepted-referral conversion, configurable admission checklist, funding and guardian readiness, temporary bed reservations, PostgreSQL row locking, compatibility review, signature evidence, transactional resident creation, initial task generation, events, audit, API routes, and Next.js workspaces.

## Safety boundary
Compatibility scores assist human review and never make an automatic placement decision. Final migration SQL and concurrency behavior require PostgreSQL execution before pilot approval.
