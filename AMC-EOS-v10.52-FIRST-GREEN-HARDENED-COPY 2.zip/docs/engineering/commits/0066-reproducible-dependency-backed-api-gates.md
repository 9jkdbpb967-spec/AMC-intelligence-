# Commit 0066 — Reproducible Dependency-Backed API Gates

## Purpose

Strengthen the first real API build so a successful CI run proves both dependency resolution and frozen-lockfile reproducibility before TypeScript, Prisma, migrations, tests, and the NestJS production build are accepted.

## Changes

- Split dependency installation into a resolver pass and a frozen-lockfile verification pass.
- Added lockfile structure, package-manager version, size, and SHA-256 checks.
- Added Prisma-format drift detection. The gate fails when `prisma format` changes the committed schema.
- Added `prisma migrate status` after migration deployment.
- Added workflow run-attempt provenance and a `reproducibleInstallVerified` attestation field.
- Added regression coverage for successful frozen installation, failed compiler stages, and Prisma formatting drift.

## Runtime boundary

The dependency-backed workflow is ready for GitHub Actions with public npm access. It was not possible to execute the real package installation in the current environment, so no TypeScript, Prisma, migration, Jest, or NestJS build pass is claimed.
