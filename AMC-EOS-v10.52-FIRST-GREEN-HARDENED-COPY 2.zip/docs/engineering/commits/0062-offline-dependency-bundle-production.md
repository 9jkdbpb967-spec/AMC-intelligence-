# Commit 0062 — Offline Dependency Bundle Production

Adds the producer side of the verified offline dependency workflow. A trusted environment with registry access can now export the real `pnpm-lock.yaml`, pnpm content-addressable store, and optional exact pnpm executable into a signed-by-digest archive that the air-gapped AMC-EOS build environment can safely import.

The bundle creator never generates a lockfile. It requires a lockfile produced by pnpm and records SHA-256, size, package-manager version, commit identity, timestamp, and file inventory.
