# Commit 0009 — Enterprise Workflow Engine

Implements a tenant-scoped, versioned workflow foundation with state transitions, tasks, approvals, SLA monitoring, escalation records, history, event publication, API contracts, and operator workspaces.

## Key safety properties
- Published definitions are versioned.
- Instances retain the definition version used at start.
- Transitions are validated against current state and permissions.
- Terminal states close instances without deleting history.
- Tenant ID is required for definition, instance, task, approval, history, comment, and escalation records.
- Workflow changes publish transactional outbox events.

## Runtime gates still required
Prisma CLI validation, PostgreSQL migration deployment, TypeScript compilation, Jest, browser tests, concurrent transition tests, and security review.
