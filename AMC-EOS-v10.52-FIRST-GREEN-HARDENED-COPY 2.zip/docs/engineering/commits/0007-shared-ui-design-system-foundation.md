# Commit 0007 — Shared UI Design-System Foundation

**Commit title:** `feat(ui): establish shared accessible design-system foundation`

## Scope

Creates `@amc-eos/ui` with design tokens, accessible React primitives, light/dark theme contracts, responsive layout utilities, cross-platform native tokens, source-contract tests, and a live Next.js showcase.

## Decisions

- Keep the foundation dependency-light and semantic.
- Share tokens with React Native without importing browser APIs.
- Require visible focus styles and minimum 44–48 px interactive targets.
- Treat formal WCAG testing, dialog focus trapping, visual regression testing, and screen-reader verification as release gates rather than assumed outcomes.

## Follow-up

Generate the lockfile, install dependencies, compile web/mobile/UI packages, execute tests, and add Storybook or an equivalent documentation environment.
