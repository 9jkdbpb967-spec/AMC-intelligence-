# Commit 0001 — Root workspace foundation

## Purpose

Establish one authoritative package-manager, build-orchestration, TypeScript, linting, formatting, and CI contract for the AMC-EOS monorepo.

## Files added or replaced

- `package.json`
- `pnpm-workspace.yaml`
- `turbo.json`
- `tsconfig.base.json`
- `tsconfig.node.json`
- `tsconfig.react.json`
- `eslint.config.mjs`
- `.github/workflows/ci-root.yml`
- `scripts/root/validate-workspace.mjs`
- `scripts/root/clean.mjs`

## Key decisions

1. pnpm is the authoritative package manager.
2. Node.js 22 is the repository runtime baseline.
3. Turbo provides task orchestration and cache boundaries.
4. The repository remains private and unpublished by default.
5. CI fails when `pnpm-lock.yaml` is absent.
6. Existing Python structural validators remain part of the static gate.

## Validation performed in the artifact environment

- JSON parsing for root configuration files.
- YAML parsing for workspace and CI files.
- Workspace-name uniqueness validation.
- Presence validation for all required root files.

Dependency installation, TypeScript compilation, Prisma CLI execution, tests, and application builds require a public package registry and remain separate gates.
