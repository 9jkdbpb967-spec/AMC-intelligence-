# Commit 0055 — Tenant-Safe Mutation Hardening

This commit classifies every API `update({ where: { id } })` mutation and removes unreviewed tenant-boundary ambiguity.

## Source changes

- Workflow instance transitions now use tenant-constrained `updateMany` and verify exactly one record changed.
- Analytics remediation updates now use tenant-constrained mutation and retrieval.
- Finance approvals, budget commitments, and invoice matching now constrain mutations by tenant inside their transactions.
- Workforce assignment, call-out, and schedule-approval mutations now constrain by tenant.
- User administration verifies the tenant membership before changing the shared user record and stores tenant activation on membership rather than globally deactivating the user.
- Internal outbox/job mutations and cryptographic token-bound auth/reset operations are documented as explicit exceptions.

## Validation

`python3 scripts/toolchain/validate-tenant-safe-mutations.py` inventories every ID-only update and fails when an unclassified mutation remains.
