# Commit 0068 — API Runtime Configuration & Health Hardening

This commit separates application construction from process startup, validates runtime configuration instead of casting unchecked values, and makes platform health endpoints safer and more operationally useful.

## Changes

- Added `createApplication()` for dependency-backed smoke tests without opening a network port.
- Kept `main.ts` as a minimal process entrypoint.
- Validated CORS origins as HTTP(S) origins and rejected wildcard credentialed CORS.
- Validated log levels and boolean environment values.
- Added a bounded database readiness timeout.
- Added readiness latency and stable error codes.
- Disabled the metrics endpoint when configured off.
- Expanded environment and health-controller test contracts.
