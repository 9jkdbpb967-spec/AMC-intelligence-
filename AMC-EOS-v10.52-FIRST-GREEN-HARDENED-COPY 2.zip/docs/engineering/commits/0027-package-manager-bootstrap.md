# Commit 0027 — Package Manager Bootstrap and Install Readiness

Adds an evidence-producing package-manager bootstrap, validates the pinned pnpm version, distinguishes registry blockage from source failure, and checks lockfile/install prerequisites before dependency-backed CI runs.

The bootstrap does not generate a synthetic lockfile. A real `pnpm-lock.yaml` must be created by pnpm against an accessible registry.
