# Commit 0031 — Workspace Export & Import Integrity

Audits package export targets and cross-package imports. Unsupported deep imports and direct imports from another package's `src/` tree fail validation. Generated `dist/` targets that do not exist before build are reported as warnings.

Safe export maps were added to source-first packages that already exposed `src/index.ts` through `main` or `types`. No application imports required rewriting: the audit found no unsupported deep imports or cross-package source imports.

Semver guidance:
- Adding an export path is additive (minor).
- Removing or renaming an export is breaking (major).
- Changing implementation without public type changes is patch-level.
