# Commit 0066 — Dependency-Backed API Build CI

This commit adds a public-registry GitHub Actions job that executes the first real API build gates directly, without requiring the dependency bundle to be downloaded and re-imported first.

The workflow installs exactly pnpm 10.15.0, starts PostgreSQL 15, generates the legitimate lockfile, runs API TypeScript and Prisma gates, applies migrations, executes foundation and unit tests, and builds the NestJS application. Every stage writes an independent raw log and SHA-256 digest.

The offline bundle workflow remains available for environments without public registry access. The new direct CI workflow is the shortest path to genuine compiler and Prisma evidence.
