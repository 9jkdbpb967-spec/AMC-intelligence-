# Commit 0052 — API Provider Dependency & Export Integrity

## Purpose

Validate the NestJS dependency graph after removal of the legacy API boundary and prevent accidental duplicate infrastructure providers.

## Changes

- Removed duplicate registrations of `PrismaService`, `AuditService`, `OutboxService`, `IdempotencyService`, and `NotificationService` from feature modules.
- Kept those process-wide services exclusively in `CoreInfrastructureModule`.
- Added `SecuritySessionsModule` to `AuthModule` so `AuthController` can resolve `PasswordResetService` through an explicit exported module contract.
- Added static validation for constructor dependencies, module exports, provider ownership, controllers, and circular module imports.
- Added a dependency-backed `AppModule` smoke-test source for later Jest execution.

## Validation boundary

The static dependency audit is executed in this release. The NestJS smoke test is source-complete but remains unexecuted until workspace dependencies are installed.
