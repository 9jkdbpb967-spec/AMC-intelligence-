# Commit 0074 — Authentication Coverage & Evidence Aggregation

Adds authentication-specific Jest coverage thresholds, required-suite skip detection, consolidated unit/integration/HTTP/abuse evidence, a release-gate aggregator, and expanded Playwright abuse and revoked-session scenarios.

The gate remains blocked until all dependency-backed suites, including Playwright, execute successfully.
