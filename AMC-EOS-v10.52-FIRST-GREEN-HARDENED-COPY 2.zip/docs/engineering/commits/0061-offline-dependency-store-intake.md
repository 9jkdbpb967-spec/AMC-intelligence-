# Commit 0061 — Offline Dependency Store Intake

Adds a safe, evidence-backed path for importing a real `pnpm-lock.yaml` and pnpm content-addressable store into environments without registry access.

## Safety controls

- SHA-256 verification for every imported file.
- Exact `pnpm@10.15.0` requirement.
- Archive traversal and link rejection.
- Explicit replacement required for an existing destination.
- Diagnostic evidence written under `release-evidence/runtime-install/`.
- No hand-written or synthesized lockfile.

## Commands

```bash
python3 scripts/runtime/import_offline_dependency_store.py bundle.tar.gz
python3 scripts/runtime/verify_offline_dependency_store.py
python3 scripts/runtime/run_offline_pnpm_install.py
```
