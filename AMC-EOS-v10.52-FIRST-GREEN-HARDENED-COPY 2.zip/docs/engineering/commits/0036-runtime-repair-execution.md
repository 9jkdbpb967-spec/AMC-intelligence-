# Commit 0036 — Runtime Repair Execution Framework

This commit converts imported runtime diagnostics into a durable repair session. Each diagnostic receives a stable repair ID, owner, stage, state, attempt history, and evidence links.

## Workflow

1. Import and classify runtime logs.
2. Generate the prioritized repair queue.
3. Initialize a repair session.
4. Select a repair ID, package owner, or all open items.
5. Run the mapped validation command.
6. Preserve per-command logs and attempts.
7. Reclassify fresh runtime logs.
8. Compare before and after fingerprints.
9. Generate owner-level progress.

Passing diagnostic-only commands do not replace a dependency-backed build. Repair items are only marked fixed when their mapped command executes successfully; dry runs remain in progress.
