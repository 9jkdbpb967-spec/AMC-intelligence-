# Commit 0047 — Runtime Evidence Manifest Generation

## Purpose

Convert actual first-green-build and external verification outputs into the exact, hash-verified manifest consumed by the release-candidate gate.

## Guarantees

- Every mandatory release gate receives a distinct evidence artifact.
- Missing execution results are marked `blocked`; they are never inferred as passed.
- Dependency-backed status is explicit.
- Every artifact contains the Git commit, workflow run ID, execution time, source-log hashes, and stage results.
- The top-level manifest carries a SHA-256 digest for every gate artifact.
- Manifest validation detects duplicates, missing gates, missing artifacts, and digest mismatches.

## Commands

```bash
pnpm release-candidate:manifest
pnpm release-candidate:manifest:check
```

## Release-candidate handoff

```bash
python3 scripts/release-candidate/aggregate_release_candidate.py \
  release-evidence/runtime/release-manifest/release-evidence-manifest.json
```
