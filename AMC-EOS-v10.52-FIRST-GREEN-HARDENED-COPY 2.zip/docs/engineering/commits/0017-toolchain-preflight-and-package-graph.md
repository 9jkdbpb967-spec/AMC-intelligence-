# Commit 0017 — Toolchain Preflight and Package Graph

This commit adds evidence-producing diagnostics before dependency installation. It validates all workspace package references, records available development tools, runs dependency-free repository/domain contracts, and preserves raw logs under `release-evidence/v6.8/`.

## Release claim

This commit does not claim successful dependency installation, TypeScript compilation, Prisma CLI execution, PostgreSQL migrations, Jest, Playwright, or container startup. Those remain blocked until the pinned pnpm release can be obtained from an accessible package registry.
