# Commit 0015 — Production Analytics & Executive Reporting

Adds tenant-scoped KPI definitions, immutable snapshots, metric certification, role-based dashboard records, report subscriptions and run history, CSV export, provider-neutral Excel/PDF contracts, and data-quality remediation tasks.

## Safety and governance
Metrics must identify an owner, methodology, and source system before certification. Snapshots are append-only. Reports and exports remain tenant scoped. Financial dashboards are operational and do not replace certified accounting reports.
