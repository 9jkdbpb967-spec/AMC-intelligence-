# Commit 0049 — API Module Registration & Dependency Integrity

## Summary

This commit reduces `AppModule` to composition-root responsibilities and establishes explicit ownership for the original API controllers and shared infrastructure providers.

## Changes

- Added global `CoreInfrastructureModule` for Prisma, audit, outbox, idempotency, and notification services.
- Added transitional `LegacyApiModule` for original vertical-slice controllers and their feature-specific providers.
- Registered the previously orphaned `ReferralIntakeOperationsController`.
- Removed the duplicate `GET /homes` route from `AppController`; `HomesController` is now the sole owner.
- Added `api:modules:check` to audit module ownership, controller registration, root-provider leakage, and duplicate routes.

## Executed evidence

- 22 Nest modules inspected.
- 51 controllers inspected and registered exactly once.
- 304 route contracts inspected with zero duplicate routes.
- 17 dependency-free source tests passed.
- 18 pilot regression tests passed.
- TypeScript syntax and build-readiness preflights passed.

## Remaining runtime gates

Dependency-backed NestJS compilation, Prisma generation, PostgreSQL migrations, Jest, Playwright, and application startup remain blocked until the pinned pnpm toolchain can access a package registry.
