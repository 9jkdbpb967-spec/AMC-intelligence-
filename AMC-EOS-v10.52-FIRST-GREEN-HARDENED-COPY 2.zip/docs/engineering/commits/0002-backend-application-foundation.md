# Commit 0002 — Backend Application Foundation

## Purpose
Standardize the NestJS runtime and operational contract before additional business-domain changes.

## Added
- Validated environment loader and global configuration service.
- Request and correlation IDs using AsyncLocalStorage context.
- Structured JSON logger.
- In-memory HTTP metrics with Prometheus text export.
- Dedicated liveness, readiness, version, and metrics endpoints.
- Standard global validation, exception responses, CORS, security headers, shutdown hooks, and Swagger bootstrap.
- Shared request/tenant context interfaces.
- Unit-test sources for environment, metrics, and health behavior.

## Endpoint contract
- `GET /health` — process liveness.
- `GET /ready` — PostgreSQL readiness.
- `GET /version` — build/runtime metadata.
- `GET /metrics` — Prometheus text metrics.
- `GET /api/docs` — interactive OpenAPI documentation.
- `GET /api/docs-json` — machine-readable OpenAPI.

## Security notes
Staging and production require `DATABASE_URL` and a JWT secret of at least 32 characters. Development defaults are explicitly non-production values.

## Validation status
Source and structural validation completed. Dependency installation, TypeScript compilation, Jest, Prisma CLI, and runtime endpoint checks require the Node toolchain and committed lockfile.
