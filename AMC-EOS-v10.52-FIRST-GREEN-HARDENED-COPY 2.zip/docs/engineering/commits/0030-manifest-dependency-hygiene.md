# Commit 0030 — Manifest & Dependency Hygiene

Audits imports against workspace manifests, distinguishes runtime and test usage, reports possibly unused declarations, and blocks high-confidence undeclared runtime dependencies.

## High-confidence fixes applied

- Added workspace dependencies from API to admissions, feature flags, referrals, and push notifications.
- Added workspace dependencies from mobile to offline sync and encrypted drafts.
- Added direct Express dependency to API because API source imports Express request/response types and middleware contracts.

No dependencies were removed automatically. Low-confidence unused declarations remain recommendations until dependency-backed builds and tests are available.
