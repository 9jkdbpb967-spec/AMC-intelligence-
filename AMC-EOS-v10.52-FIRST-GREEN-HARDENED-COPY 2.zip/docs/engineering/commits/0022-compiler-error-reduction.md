# Commit 0022 — Compiler Error Reduction

## Scope

This commit executes targeted semantic compilation against the API, web, and mobile applications using the globally available TypeScript compiler. It fixes source defects that can be confirmed without installing external packages and separates production typechecking from test-global typechecking.

## Confirmed fixes

- Renamed the injected AI provider registry to remove a class member/method name collision.
- Corrected the browser SDK environment property from `apiBaseUrl` to `apiUrl`.
- Replaced the mobile Expo-base `tsconfig` dependency with a repository-local React configuration for offline compiler preflight.
- Added explicit mobile JSX, target, library, and module-resolution options.
- Added type-only imports required by `verbatimModuleSyntax`.
- Removed the mobile API client's direct dependency on the Node `process` global type.
- Added application test `tsconfig` files and excluded test sources from production application typechecks.

## Evidence

Raw compiler logs and a machine-readable summary are under `release-evidence/v7.3/`.

## Limitations

React, NestJS, Prisma, Expo, and related type packages are not installed in this environment. Missing-module cascades remain and must be re-evaluated after dependency installation.
