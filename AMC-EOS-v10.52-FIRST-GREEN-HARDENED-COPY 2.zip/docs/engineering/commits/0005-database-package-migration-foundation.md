# Commit 0005 — Database Package & Migration Foundation

Adds a shared Prisma lifecycle package, tenant-scoped repository contracts, transaction helpers, database health diagnostics, deterministic fixtures, migration registry, rollback-plan generator, PostgreSQL integration harness, and CI database gates.

## Definition of done
Source and static contract validation are complete. Official Prisma, PostgreSQL migration, and integration execution remain gated on dependency/toolchain availability.
