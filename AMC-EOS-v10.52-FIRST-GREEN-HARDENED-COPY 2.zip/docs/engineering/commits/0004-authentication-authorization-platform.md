# Commit 0004 — Authentication and Authorization Platform

Adds tenant-slug authentication contracts, revocable session restoration, current-session identity, password recovery endpoints, permission-aware web route protection, forbidden state, session workspace, and shared web auth client.

## Security decisions
- Tenant selection is explicit at login.
- Access tokens remain short-lived and reference a persisted revocable session.
- Refresh tokens are opaque and stored as hashes.
- Password reset revokes active sessions.
- Route visibility is not authorization; NestJS guards remain authoritative.
