# Commit 0023 — Dependency-Cascade Isolation

This commit separates root missing-package failures from downstream TypeScript cascades. It adds diagnostic-only declarations, project-specific diagnostic tsconfigs, root-cause grouping, contextual-typing classification, and a prioritized package/file repair queue.

## Safety boundary

`diagnostic-stubs/` is for offline compiler diagnosis only. Production `tsconfig.json` files do not include these declarations. The stubs must not be shipped, bundled, or used to claim runtime compatibility.

## Executed result

The prior API/web/mobile logs contained 3,871 diagnostics. Diagnostic isolation reduced the total to 164, a 95.8% reduction. The classifier identified 92 prioritized actionable diagnostics after separating contextual typing and missing dependency cascades.
