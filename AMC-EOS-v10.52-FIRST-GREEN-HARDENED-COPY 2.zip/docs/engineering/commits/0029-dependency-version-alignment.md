# Commit 0029 — Dependency Version Alignment

## Summary

Aligned safe dependency ranges across workspace manifests and introduced a central dependency-version policy. React and React DOM peer ranges in `@amc-eos/ui` remain intentional documented compatibility exceptions.

## Changes

- Unified Prisma packages on `^6.2.1`.
- Unified TypeScript on `^5.7.3`.
- Unified Node type definitions on `^22.10.0`.
- Unified application React and React DOM ranges on `^19.0.0`.
- Added `config/dependencies/version-policy.json`.
- Added policy validation and alignment reporting scripts.
- Added a pull-request CI gate for dependency drift.

## Validation

The version policy audit passed with zero unapproved drift findings. The dependency inventory dropped from six multi-range findings to two documented React peer compatibility exceptions.
