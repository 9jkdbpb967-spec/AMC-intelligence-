# Commit 0070 — Authentication Integration-Test Foundation

## Scope

This commit adds dependency-backed test source for the authentication lifecycle without claiming that PostgreSQL, Jest, or Playwright ran in the current restricted environment.

## Added

- PostgreSQL-backed AuthService integration suite.
- Concurrent refresh-token rotation and reuse detection test.
- Login success/failure history and audit assertions.
- Password-reset single-use, expiry, and session-revocation tests.
- Login rate-limit unit tests.
- JWT issuer, audience, algorithm, and expiration contract tests.
- Playwright login, session restoration, logout, and password-reset request workflow.
- GitHub Actions PostgreSQL authentication workflow.
- Static regression validator and root workspace commands.

## Runtime requirements

The PostgreSQL suite runs only when `AUTH_INTEGRATION_DATABASE_URL` or `DATABASE_URL` is configured. The Playwright suite runs only when E2E authentication credentials are supplied.
