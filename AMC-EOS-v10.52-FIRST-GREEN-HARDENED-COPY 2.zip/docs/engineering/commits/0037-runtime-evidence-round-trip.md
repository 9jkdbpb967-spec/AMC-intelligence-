# Commit 0037 — Runtime Evidence Round Trip

Adds a portable, integrity-checked handoff between Codespaces/CI and the AMC-EOS repair tooling.

## Capabilities
- Export runtime evidence as a tar.gz bundle.
- Generate a SHA-256 manifest for every included file.
- Reject archive path traversal during verification.
- Verify file size and digest before import.
- Feed verified bundles into the existing classifier and repair-queue pipeline.
- Exercise the full round trip with controlled TypeScript, Prisma, and test fixtures.

Diagnostic bundles may contain sensitive logs. Review and redact them before external sharing.
