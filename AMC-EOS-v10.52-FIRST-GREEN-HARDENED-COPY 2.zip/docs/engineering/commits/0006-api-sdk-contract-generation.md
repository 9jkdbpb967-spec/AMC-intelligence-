# Commit 0006 — API SDK & Contract Generation Foundation

## Intent
Establish one normalized OpenAPI contract and a reusable TypeScript SDK for web, mobile, tests, and future external clients.

## Guarantees
- Tenant, request, and correlation headers are propagated centrally.
- Idempotency keys are supported for mutation retries.
- Timeouts and bounded retries are standardized.
- API errors retain HTTP status and machine-readable payloads.
- Generated contracts are checked for source drift in CI.

## Commands
```bash
pnpm sdk:normalize
pnpm sdk:generate
pnpm sdk:drift
```

Generated files must be committed. CI rejects undocumented OpenAPI changes or stale SDK output.
