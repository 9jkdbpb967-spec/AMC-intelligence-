# Commit 0058 — Legacy Controller Query & Payload Cleanup

## Scope

This commit closes the remaining public list-query and controller payload warnings identified by the broad API query-integrity audit.

## Changes

- Added validated analytics DTOs for briefing generation, subscriptions, remediation updates, and KPI certification.
- Removed the final analytics controller `any` request bodies.
- Added bounded results to legacy list endpoints and nested resource collections.
- Added bounded workforce readiness, scheduling, time-entry, mobile rollout, document, session, assessment, incident, resident, service-plan, and referral-activity queries.
- Made pagination bounds explicit in homes and clients controllers so static analysis can verify them.
- Added typed mobile rollout DTOs.
- Added a regression gate requiring every inventoried `findMany()` call to be bounded and every controller body to avoid `any`.

## Validation boundary

This is dependency-free structural and syntax validation. Real NestJS, Prisma, Jest, Playwright, and PostgreSQL execution remain pending.
