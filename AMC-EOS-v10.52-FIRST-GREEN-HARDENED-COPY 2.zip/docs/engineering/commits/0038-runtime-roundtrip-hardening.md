# Commit 0038 — Runtime Evidence Round-Trip Hardening

This commit fixes repeatability and external-path defects discovered by executing the runtime evidence workflow and its unit tests.

## Changes

- Added explicit `--replace` handling to runtime-evidence imports.
- Propagated `--replace` through the end-to-end import wrapper.
- Made the controlled round-trip preflight repeatable.
- Rejected archive symlinks and hard links during extraction.
- Switched tar extraction to Python's safe data filter.
- Allowed import and repair evidence directories outside the repository root.
- Added automated regression coverage for repeated imports.

## Executed validation

The runtime unit suite and the complete round-trip preflight pass on repeated execution.
