# Commit 0050 — API Feature-Module Extraction

## Purpose

Reduce the transitional `LegacyApiModule` by assigning related controllers and providers to explicit NestJS feature modules.

## Extracted modules

- `DocumentsModule`: document metadata, private storage, and scan-webhook guard.
- `JobsModule`: background jobs and worker metrics.
- `AdmissionsModule`: legacy admission readiness and transaction services.
- `ResidentCareModule`: service plans and daily documentation.
- `SecuritySessionsModule`: password reset, login history, and revocable sessions.
- `ReferralIntakePlatformModule`: referral intake, intake operations, referral activity, and organization activity controllers.

## Results

- Legacy controller ownership reduced from 29 to 16 controllers.
- All 51 API controllers are registered exactly once.
- All 304 inspected routes have a single controller owner.
- No extracted controller or provider remains in `LegacyApiModule`.
- `AppModule` composes the six modules explicitly while keeping global guards, middleware, and request logging at the root.

## Validation boundary

The repository passed dependency-free syntax, module-integrity, source-contract, and pilot regression checks. NestJS dependency-backed compilation, Prisma generation, PostgreSQL migrations, Jest, and Playwright remain unexecuted because workspace dependencies are unavailable in this environment.
