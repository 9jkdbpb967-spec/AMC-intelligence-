# Commit 0035 — Runtime Failure Import & Repair Queue

This commit adds a safe evidence-import and triage workflow for logs produced in GitHub Codespaces, CI, or a local dependency-backed build environment.

## Capabilities

- Imports a directory, text log, ZIP, or TAR archive without unsafe path extraction.
- Records SHA-256 hashes for every imported artifact.
- Classifies TypeScript, Prisma, migration, test, Playwright, Docker, install, and build failures.
- Groups repeated failures by root cause and package owner.
- Separates environment blockers from actionable source failures.
- Generates a prioritized package-by-package repair queue.

## Usage

```bash
python3 scripts/runtime/run-runtime-failure-import.py /path/to/build-logs --label codespaces-run-001
```

Diagnostic outputs remain evidence. They do not mark a gate as passed until the associated command succeeds in a real runtime environment.
