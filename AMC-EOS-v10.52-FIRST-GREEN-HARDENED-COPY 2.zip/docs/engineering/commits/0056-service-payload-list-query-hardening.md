# Commit 0056 — Service Payload & List-Query Hardening

This commit replaces untyped public service/controller payload boundaries in the production referral, admission, resident, analytics, finance, and AI domains with explicit validated DTO contracts. It also adds bounded AI list operations and a regression validator that prevents `body: any` and `dto: any` from returning at those boundaries.

## Safety boundaries

The remaining `any` usage is primarily limited to diagnostic Prisma shims and generated-client callback shapes that require dependency-backed Prisma generation before final typing. The query audit preserves five unbounded internal-query findings for later review rather than silently claiming they are safe.
