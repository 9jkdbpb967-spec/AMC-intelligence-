# Commit 0051 — Remaining Legacy API Extraction

## Commit

`refactor(api): remove the legacy API boundary`

## Summary

The final 16 controllers formerly owned by `LegacyApiModule` were moved into four explicit feature modules. `LegacyApiModule` and its source directory were removed. `AppModule` now composes only dedicated feature modules and platform infrastructure.

## New ownership

- `OrganizationReferralAdminModule`: organizations, referrals, users, contacts
- `ResidentResourcesHousingModule`: clients, residents, homes, beds, checklists
- `QualityAssessmentsModule`: assessments, incidents, audit
- `PlatformAdministrationModule`: tasks, imports, notifications, search

## Executed evidence

- 31 NestJS modules inspected
- 51 controllers registered exactly once
- 304 routes inspected
- 0 duplicate routes
- 0 unregistered controllers
- 393 TypeScript/TSX files passed syntax transpilation
- 17 dependency-free source tests passed
- 18 pilot regression tests passed
- 4 build-readiness checks passed

## Runtime boundary

This commit does not claim dependency-backed NestJS compilation, Prisma generation, PostgreSQL migration execution, Jest, or Playwright. Those gates still require a public package registry and installed workspace dependencies.
