# Commit 0033 — Runtime Build Environment

Adds a reproducible Dev Container, package-manager bootstrap, runtime-readiness verification, and a single command for the first dependency-backed green build.

## Purpose

The repository's primary blocker is environmental: the current internal registry does not expose the pinned pnpm package. This commit gives engineers and AI coding environments a supported path using the public npm registry without fabricating a lockfile.

## Acceptance criteria

- Dev Container configuration exists.
- Bootstrap activates exactly pnpm 10.15.0.
- Bootstrap generates or consumes the real lockfile.
- Runtime readiness produces machine-readable evidence.
- First-green-build script runs workspace, dependency, TypeScript, Prisma, tests, and build gates.
