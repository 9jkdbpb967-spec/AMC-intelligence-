# AMC-EOS v4.6 AI Production Hardening

This release hardens the governed AI layer without enabling unreviewed external model access.

## Controls

- Provider registry with deterministic pilot provider.
- External provider adapter interfaces for OpenAI, Azure OpenAI, and Anthropic.
- Secret references only; raw provider secrets are not stored in application records.
- Timeout, retry, and circuit-breaker orchestration.
- Prompt-injection screening before retrieval or generation.
- Sensitive-data redaction for email, phone, SSN, and selected identifier patterns.
- Collection access by tenant and role.
- Tool permission enforcement per agent.
- Provider health and AI cost dashboards.
- AI security event records.

## Human review

AI outputs remain advisory. Executive drafts and any output affecting residents, employees, compliance, finance, or policy require authorized human review.

## Production gates

External adapters remain disabled until secret resolution, network controls, vendor agreements, privacy review, model-risk review, and production testing are complete.
