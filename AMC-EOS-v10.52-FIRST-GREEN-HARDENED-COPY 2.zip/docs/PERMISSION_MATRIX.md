# AMC-EOS Permission Matrix — v0.5

Roles are deny-by-default for sensitive write operations. Public health endpoints remain unauthenticated.

| Capability | CEO | Admin | Referral Coordinator | House Manager | DSP | HR | Finance | Quality |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| View dashboard | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ | ✓ |
| View referral CRM | ✓ | ✓ | ✓ | limited | — | — | — | ✓ |
| Create/edit organizations | ✓ | ✓ | ✓ | — | — | — | — | — |
| Create referrals | ✓ | ✓ | ✓ | — | — | — | — | — |
| Change referral status | ✓ | ✓ | ✓ | — | — | — | — | ✓ |
| Manage users | ✓ | ✓ | — | — | — | ✓ | — | — |
| Review audit log | ✓ | ✓ | — | — | — | — | — | ✓ |
| Create document metadata | ✓ | ✓ | ✓ | ✓ | — | — | — | ✓ |

This matrix is an engineering baseline, not a final privacy authorization model. Field-level and tenant-level restrictions remain release gates before real protected data is used.
