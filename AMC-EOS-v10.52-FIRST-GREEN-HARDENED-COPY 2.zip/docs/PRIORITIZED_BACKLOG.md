# Prioritized Backlog

## P0 — Make the MVP Safe and Testable
1. Replace development auth with an identity provider and MFA-ready design.
2. Implement permission matrix and authorization tests.
3. Add DTO validation, global exception handling, request IDs, and structured logging.
4. Add database migrations and CI checks.
5. Add automated API and web tests.
6. Add encrypted object storage architecture and malware-scanned uploads.
7. Add tenant/organization boundary for future multi-company use.

## P1 — Referral CRM Completion
1. Contacts CRUD and duplicate detection.
2. Activities, notes, and task automation.
3. CSV/XLSX import mapping, validation, dry run, and error report.
4. Referral source scoring and relationship health.
5. Saved filters, exports, and scheduled follow-up reports.

## P1 — Intake and Admissions
1. Configurable document checklist.
2. Assessment workflow and review approvals.
3. Capacity matching and admission decision log.
4. Consent/release tracking.
5. Referral status history and SLA alerts.

## P2 — Knowledge Base
1. Policy/SOP/form/checklist registry.
2. Document versions, owners, approvals, and review dates.
3. Full-text search and cross-links.
4. Staff acknowledgment and training linkage.

## P2 — HR and Training
1. Employee directory and credentials.
2. Training assignments and expirations.
3. Onboarding workflow and competency validation.

## P3 — Quality and Operations
1. Incident and complaint management.
2. CAPA and audit modules.
3. Resident operations only after security Gate 3.
