# Observability Standard

Version 0.5 introduces request IDs, structured request summaries, standardized API errors, health checks, and database readiness checks.

Minimum production observability:
- Centralized application and audit logs
- Request ID propagation through reverse proxy and automation services
- Availability monitoring for `/health` and `/ready`
- Alerts for 5xx errors, authentication failures, database connectivity, and overdue jobs
- Metrics for API latency, error rate, referral volume, task backlog, and audit-log write failures
- Sensitive fields must never be written to application logs
