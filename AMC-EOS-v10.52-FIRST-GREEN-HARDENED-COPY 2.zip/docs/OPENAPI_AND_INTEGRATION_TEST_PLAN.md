# OpenAPI and Authorization Integration Test Plan

## Next implementation tasks
- Add Swagger/OpenAPI annotations and generated specification.
- Add PostgreSQL-backed integration tests.
- Seed two tenants and users with different roles.
- Prove tenant A cannot list, fetch, modify, link, or delete tenant B records.
- Prove every protected route rejects missing/expired tokens.
- Prove role-restricted routes reject unauthorized memberships.
- Prove refresh-token reuse fails after rotation.
- Prove quarantined documents cannot receive download URLs.
