# Definition of Done

A feature is complete only when all applicable items are satisfied.

## Product
- User story and acceptance criteria approved
- Role and permission behavior defined
- Empty, loading, success, validation, error, and forbidden states implemented

## Engineering
- Schema and migration reviewed
- API uses DTO validation and consistent errors
- UI is typed and accessible
- Unit and integration tests pass
- Build, lint, and type checking pass
- No critical/high dependency vulnerabilities without documented exception

## Security and Privacy
- Threat/privacy review completed
- Sensitive fields classified
- Audit events generated
- Logs contain no secrets or prohibited data
- Authorization tests included

## Operations
- Monitoring and support notes added
- Migration and rollback documented
- Seed/demo data updated
- User and technical documentation updated
