# v2.5 Release Gates

A pilot candidate may not be labeled validated until all items below are evidenced.

- [ ] Public-registry dependency installation succeeds.
- [ ] `package-lock.json` is committed and unchanged by `npm ci`.
- [ ] `prisma format`, `generate`, and `validate` succeed.
- [ ] Baseline or incremental migration SQL is reviewed and committed.
- [ ] API, web, worker, and shared packages compile.
- [ ] Unit tests pass.
- [ ] Two-tenant PostgreSQL tests pass.
- [ ] Playwright pilot workflows pass.
- [ ] Development and production Compose stacks become healthy.
- [ ] Backup and isolated restore test pass.
- [ ] Accessibility and security reviews are completed.
