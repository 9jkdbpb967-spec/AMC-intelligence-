# Mobile Security and Rollout v4.8

1. Encrypted drafts use a device-bound secret stored with SecureStore.
2. Sync actions are idempotent by client action ID.
3. Version mismatches create explicit manual-review conflicts.
4. Revoked devices cannot synchronize.
5. Push providers are disabled by default and store delivery evidence only.
6. Rollout progresses from internal QA to one pilot home before broader activation.
7. Emergency kill switches must be tested before go-live.
8. Use synthetic data until the privacy and security gates are approved.
