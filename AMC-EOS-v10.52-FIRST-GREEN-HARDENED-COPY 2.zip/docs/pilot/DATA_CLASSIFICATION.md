# Pilot Data Classification

| Class | Examples | Pilot rule |
|---|---|---|
| Public | Published marketing copy | Permitted |
| Internal | Synthetic training data, internal procedures | Permitted with access control |
| Confidential | Employee business records, contracts | Prohibited until security gates pass |
| Restricted | Resident, medical, Medicaid, incident, identity, payroll data | Strictly prohibited until formal go-live approval |

The pilot must begin with synthetic data only. Data classification does not replace legal, contractual, or regulatory review.
