# Washington Pilot Blueprint

## Pilot scope
One operating company, one initial home, a controlled staff group, and synthetic records until formal privacy/security approval.

## Minimum workflows
Referral source management; referral intake; document checklist; assessment tracking; management decision; home and bed capacity; admission; resident directory; staff credential tracking; task reminders; audit review; quality issue escalation.

## Four-stage rollout
1. Sandbox: synthetic data, product and security testing.
2. Staff pilot: training and workflow rehearsals without resident data.
3. Controlled go-live: least-privilege users and daily review.
4. Stabilization: KPI review, defects, SOP revisions, and go/no-go for broader use.

## Pilot KPIs
Referral response time, missing-document aging, intake cycle time, user adoption, failed logins, permission denials, overdue tasks, audit-event coverage, backup success, and user-reported defects.
