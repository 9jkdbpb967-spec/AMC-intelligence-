# AMC-EOS v2.7 Pilot Deployment Runbook

## Release position
This package is a **pilot release candidate**, not a production authorization. Protected information is prohibited until every mandatory gate is evidenced.

## Timeline and completion
| Work line | Completion | Typical time |
|---|---:|---:|
| Source hardening | 100% | Complete |
| Offline preflight | 100% | Complete |
| Dependency lockfile | 0% | 1 day |
| Official Prisma validation | 0% | 1–2 days |
| Reviewed migration | 0% | 2–4 days |
| Compile and tests | 0% | 3–7 days |
| Docker pilot startup | 0% | 1–2 days |
| Backup/restore evidence | 0% | 1–2 days |
| Security/accessibility review | 0% | 1–2 weeks |

## Required gates
1. Public npm install completes and `package-lock.json` is committed.
2. `npm run db:format`, `npm run db:validate`, and `npm run db:generate` pass.
3. Migration SQL is reviewed by an engineer and tested on a disposable copy.
4. `npm run typecheck`, `npm test`, and `npm run build` pass.
5. Two-tenant tests prove cross-tenant reads and writes fail.
6. Playwright pilot workflows pass.
7. `docker compose -f compose.pilot.yaml up --build` becomes healthy.
8. Database backup and isolated restore are demonstrated.
9. Security, privacy, accessibility, and Washington operational reviews are signed off.

## Pilot startup
```bash
cp pilot.env.example .env
# replace every secret and URL
npm ci
npm run db:format
npm run db:validate
npm run db:generate
npm run migration:baseline:generate
npm run migration:baseline:review
docker compose -f compose.pilot.yaml up --build -d
API_URL=http://localhost:4000 WEB_URL=http://localhost:3000 npm run pilot:smoke
```

## Rollback
1. Stop traffic and workers.
2. Preserve application, database, and audit logs.
3. Restore the last verified database backup into an isolated environment.
4. Validate tenant counts and high-risk workflows.
5. Deploy the prior signed artifact.
6. Reopen traffic only after formal approval.
