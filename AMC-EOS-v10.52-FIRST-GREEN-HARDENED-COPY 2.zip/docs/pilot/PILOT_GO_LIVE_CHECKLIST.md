# Pilot Go-Live Checklist

## Technical
- [ ] Lockfile committed
- [ ] Official Prisma validation passed
- [ ] Reviewed migration applied successfully
- [ ] API/web/worker builds passed
- [ ] Unit, integration, tenant, and browser tests passed
- [ ] All containers healthy for 24 hours
- [ ] Backup and isolated restore demonstrated
- [ ] Central logs and alerts verified

## Security and privacy
- [ ] Unique production secrets installed
- [ ] MFA or approved compensating control enabled
- [ ] Least-privilege access reviewed
- [ ] File quarantine path tested
- [ ] Audit event sampling verified
- [ ] Security review signed
- [ ] Privacy and records-retention review signed

## Operations
- [ ] Synthetic-data rehearsal completed
- [ ] Staff trained on referral, admission, resident, documentation, incident, and workforce workflows
- [ ] Emergency downtime forms available
- [ ] Support escalation roster confirmed
- [ ] Washington program and reporting rules reviewed by qualified personnel
