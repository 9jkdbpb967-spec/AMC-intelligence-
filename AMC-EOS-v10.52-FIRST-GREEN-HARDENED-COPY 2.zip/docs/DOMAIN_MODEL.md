# Domain Model and Controlled Vocabulary

## Core Entities
- User, Role, Permission
- Organization, Contact, Activity, Task
- Referral, Client, Assessment, Admission
- Home, Bed, Capacity Snapshot
- Document, Document Version, Retention Rule
- Policy, SOP, Form, Checklist, Training Module, Audit Control, KPI
- Employee, Credential, Training Assignment
- Incident, Complaint, CAPA, Risk
- Vendor, Grant, Budget, Purchase Request

## Controlled Referral Stages
`NEW`, `INFORMATION_NEEDED`, `SCREENING`, `ASSESSMENT`, `FUNDING_VERIFICATION`, `MANAGEMENT_REVIEW`, `APPROVED`, `DECLINED`, `ADMITTED`, `CLOSED`

## Controlled Relationship Stages
`PROSPECT`, `CONTACTED`, `MEETING_SCHEDULED`, `ACTIVE_RELATIONSHIP`, `REFERRAL_PARTNER`, `STRATEGIC_PARTNER`, `INACTIVE`

## Controlled Roles
`OWNER`, `ADMIN`, `EXECUTIVE`, `REFERRAL_COORDINATOR`, `OPERATIONS_MANAGER`, `HOUSE_MANAGER`, `DSP`, `HR`, `FINANCE`, `QUALITY_COMPLIANCE`, `READ_ONLY_AUDITOR`

## Modeling Rules
- Use immutable IDs and timestamps.
- Never use free text when a governed enum is required.
- Record actor and reason for critical state changes.
- Soft-delete regulated or operational records unless approved retention rules permit permanent deletion.
- Store sensitive classifications at field/document level where practical.
