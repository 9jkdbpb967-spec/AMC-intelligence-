# Security and Privacy Gates

## Gate 0 — Demonstration Only
No real resident, medical, Medicaid, employee, banking, or confidential partner information. Synthetic data only.

## Gate 1 — Internal Pilot
Required:
- External identity provider or hardened authentication
- MFA
- Strong password and session policies
- Role and permission matrix
- Encryption in transit and at rest
- Secrets manager
- Centralized audit logs
- Automated backups and tested restoration
- Vulnerability and dependency scanning
- Privacy and security policies

## Gate 2 — Limited Sensitive Data
Required in addition:
- Formal risk assessment
- Data classification and retention schedule
- Incident/breach response plan
- Vendor due diligence and agreements
- Field-level access controls
- Export restrictions
- Secure object storage and malware scanning
- Penetration test and remediation
- Legal/compliance review

## Gate 3 — Production Clinical/Service Operations
Required in addition:
- Documented applicable regulatory obligations
- Business continuity and disaster recovery tests
- Security monitoring and alerting
- Periodic access certification
- Immutable or protected audit retention
- Staff security training
- Change-management approvals
- Independent production readiness review

This file is a planning control, not a certification that the application meets any law or regulation.
