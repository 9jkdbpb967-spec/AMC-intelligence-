# v3.2 Timeline and Completion

| Work line | Completion | Remaining validation time |
|---|---:|---:|
| Tenant-slug NestJS authentication source | 100% | Complete |
| Revocable session source | 100% | Complete |
| PostgreSQL idempotency source | 100% | Complete |
| Referral workspace/activity source | 100% | Complete |
| Transactional admission source | 100% | Complete |
| PostgreSQL bed locking source | 100% | Complete |
| Matching Next.js source screens | 100% | Complete |
| Typed client source | 100% | Complete |
| Migration source | 100% | Complete |
| Unit/integration test source | 100% | Complete |
| npm lockfile and dependency install | 0% | 1 day |
| Prisma official validation and migration deploy | 0% | 1–2 days |
| TypeScript/Jest execution | 0% | 2–5 days |
| Two-tenant PostgreSQL and concurrency execution | 0% | 2–4 days |
| Playwright execution | 0% | 1–3 days |
| CI green evidence | 0% | 2–5 days |
