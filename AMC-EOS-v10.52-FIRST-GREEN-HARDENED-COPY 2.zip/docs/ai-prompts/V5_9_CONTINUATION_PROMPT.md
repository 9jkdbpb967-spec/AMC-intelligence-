# AMC-EOS v5.9 Continuation Prompt

Continue from v5.8 without redesigning the monorepo.

Implement Commit 0008: Event, Notification, and Audit Platform Foundation.

Required scope:
1. Shared event envelope and versioned event catalog.
2. Transactional outbox publisher contracts.
3. Notification template/provider abstraction.
4. In-app, email, SMS, and push channel contracts, disabled safely by default.
5. Immutable audit-event service and correlation propagation.
6. NestJS modules and worker handlers.
7. Web notification center using `@amc-eos/ui`.
8. OpenAPI updates, source-contract tests, CI validation, documentation, PMO dashboard, and integrity manifest.

Do not claim dependency installation, compilation, database migration execution, or browser tests passed without raw evidence.
