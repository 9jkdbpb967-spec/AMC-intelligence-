# AMC-EOS v3.5 Continuation Prompt

Read `START_HERE_FOR_AI.md`, `PROJECT_STATE.json`, `RELEASE_V3_4.md`, and `release-evidence/v3.4/release-attestation.json` first.

Goal: execute the blocked Node/PostgreSQL validation gates in an environment with public npm, Docker, and PostgreSQL.

Required work:
1. Generate and commit `package-lock.json` without changing the approved stack.
2. Run Prisma format, generate, validate, and reviewed migrations.
3. Repair all TypeScript builds.
4. Run Jest with coverage and real two-tenant HTTP tests.
5. Run concurrent PostgreSQL bed-locking test.
6. Generate the typed client from enterprise OpenAPI.
7. Run Playwright login-to-admission.
8. Make all CI workflows green.
9. Attach raw logs and update release attestation only from evidence.
10. Never use real protected information.
