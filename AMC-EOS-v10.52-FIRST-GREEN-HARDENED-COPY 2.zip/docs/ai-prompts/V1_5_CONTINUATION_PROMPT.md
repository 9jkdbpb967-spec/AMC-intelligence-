# AMC-EOS Enterprise v1.5 Continuation Prompt

Read all architecture, security, product, database, and release documents before modifying code. Preserve tenant isolation and the existing Next.js/NestJS/PostgreSQL/Prisma architecture.

Implement next:
1. Real PostgreSQL Testcontainers tests for two tenants.
2. Enforce `Idempotency-Key` on referral, task, and import create endpoints.
3. Update OpenAPI for all v1.4 endpoints and generate the typed client.
4. Complete task, activity, and checklist panels inside the referral workspace.
5. Add home create/edit and bed-notes UI.
6. Add automated CI jobs for Playwright and integration tests.
7. Publish outbox events for checklist verification, referral activities, and bed status changes.
8. Add notification jobs for overdue checklist items and referral follow-ups.
9. Provide migration, rollback, tests, security notes, and honest limitations.

Use synthetic data only. Do not claim tests passed unless executed.
