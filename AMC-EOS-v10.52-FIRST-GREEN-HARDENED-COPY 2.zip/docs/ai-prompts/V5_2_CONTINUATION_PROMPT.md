# AMC-EOS v5.2 Continuation Prompt

Use v5.1 as the source of truth. Execute the staging stack in a public npm, Docker, and PostgreSQL environment. Generate the lockfile; compile all workspaces; validate and deploy Prisma migrations; import the deterministic standard-pilot dataset; run referral-to-resident, daily-service, workforce, finance, analytics, AI, and mobile E2E workflows; test backup/restore and rollback; attach raw logs; never mark a gate passed without evidence; keep staging synthetic-data-only.
