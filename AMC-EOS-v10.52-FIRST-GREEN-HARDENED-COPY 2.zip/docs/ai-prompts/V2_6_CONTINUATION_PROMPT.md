# AMC-EOS v2.6 Continuation Prompt

Read `START_HERE_FOR_AI.md`, `PROJECT_STATE.json`, `docs/RELEASE_GATES_V2_5.md`, and the architecture/security documents first.

Primary objective: make the validation pipeline genuinely green in an environment with public npm, Docker, and PostgreSQL.

Required work:
1. Run `npm install` and commit `package-lock.json`.
2. Repair dependency, Prisma, TypeScript, Jest, and Playwright failures.
3. Generate baseline migration SQL using the provided script; review it and commit only after documented approval.
4. Implement executable two-tenant tests for all pilot domains.
5. Start development and production Compose stacks and save health evidence.
6. Execute backup and isolated restore tests.
7. Update release attestation only with facts supported by logs.
8. Do not claim a green gate that did not run successfully.
