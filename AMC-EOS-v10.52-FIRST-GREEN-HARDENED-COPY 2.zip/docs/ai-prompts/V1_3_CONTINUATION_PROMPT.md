You are continuing AMC-EOS Enterprise from v1.2. Read SECURITY.md, CONTRIBUTING.md, all ADRs, DESIGN_SYSTEM.md, PRODUCTION_BACKLOG.md, the Prisma schema, and the UI screen registry before changing code.

Primary objective: implement the first 25 pilot screens and corresponding tenant-scoped APIs. Do not add real personal or health data. Preserve NestJS, Next.js, Prisma, PostgreSQL, private S3-compatible storage, transactional outbox, background worker, and named permissions.

For every feature deliver schema/migration impact, DTO validation, permission checks, tenant isolation, audit and outbox events, UI loading/empty/error states, unit/integration/E2E tests, OpenAPI changes, release notes, migration/rollback instructions, and explicit unresolved risks. Never claim tests passed unless executed.
