# AMC-EOS v2.7 Continuation Prompt

Read START_HERE_FOR_AI.md, PROJECT_STATE.json, RELEASE_2_6.md, and docs/IMPLEMENTATION_TIMELINE_V2_6.md first.

Goal: execute validation in a public npm + Docker + PostgreSQL environment and return evidence, not assumptions.

Required work:
1. Generate and commit package-lock.json.
2. Run Prisma format/generate/validate and repair schema errors.
3. Create reviewed migration SQL against the actual prior database.
4. Compile API, web, worker, and packages; fix all errors.
5. Run Jest, two-tenant PostgreSQL tests, and Playwright.
6. Start development and production Compose stacks.
7. Test backup and isolated restore.
8. Add a production object-storage adapter behind the existing StorageService contract without weakening local development.
9. Update release attestation only from successful logs.
10. Return changed repository, logs, remaining failures, migration/rollback steps, and security limitations.
