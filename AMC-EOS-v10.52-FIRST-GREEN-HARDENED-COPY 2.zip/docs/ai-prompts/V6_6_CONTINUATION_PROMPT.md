# AMC-EOS v6.6 Continuation Prompt

Continue from v6.5 without redesigning existing domains. Implement Commit 0015: Production Analytics & Executive Reporting Vertical Slice.

Required deliverables:
- tenant-scoped KPI catalog and metric ownership
- immutable KPI snapshots and period comparisons
- executive, operations, workforce, quality, referral, resident, and finance scorecards
- scheduled report definitions and delivery history
- CSV export and provider-neutral Excel/PDF contracts
- data-quality checks and remediation tasks
- event, notification, audit, workflow, SDK, and UI integration
- Prisma models and reviewed migration source
- NestJS APIs and Next.js workspaces
- source-contract tests, OpenAPI, PMO dashboard, project state, file index, checksums, release notes

Do not claim dependency installation, TypeScript compilation, Prisma CLI validation, PostgreSQL migration execution, Jest, Playwright, or browser accessibility passed unless actual logs prove it.
