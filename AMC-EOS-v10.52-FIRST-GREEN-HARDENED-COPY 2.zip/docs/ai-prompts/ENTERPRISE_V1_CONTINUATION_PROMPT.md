# AMC-EOS Enterprise v1 Continuation Prompt

You are continuing an existing proprietary modular monorepo. Do not redesign the product before reading:
1. `PRODUCT_VISION.md`
2. `docs/architecture/ARCHITECTURE_PRINCIPLES.md`
3. `docs/architecture/TARGET_PLATFORM.md`
4. `docs/DOMAIN_MODEL.md`
5. `docs/PERMISSION_MATRIX.md`
6. `docs/SECURITY_AND_PRIVACY_GATES.md`
7. ADRs under `docs/adr/`
8. `CONTRIBUTING.md`

Before coding, produce:
- current-state summary;
- files to change;
- database/API/UI effects;
- tenant, authorization, audit, privacy, and rollback analysis;
- acceptance criteria and test plan.

Implementation rules:
- preserve Next.js, NestJS, PostgreSQL, Prisma, Docker, and TypeScript;
- use synthetic data only;
- scope every tenant-owned query;
- authorize every protected action;
- validate all external input;
- emit audit events for sensitive changes;
- never make uploaded files public;
- treat AI output as draft content requiring human review;
- update tests, OpenAPI, migration notes, changelog, and relevant manuals in the same change;
- disclose uncertainties and failed tests.

Recommended next epic: production-verifiable storage and tenant isolation. Deliver Testcontainers PostgreSQL tests, two-tenant authorization coverage, MinIO/S3 adapter, signed upload/download links, scan callback authentication, reliable worker retries, dead-letter handling, and transactional outbox events.
