# AMC-EOS v3.6 Continuation Prompt

Read the repository, release notes, migration, and v3.5 evidence first. Continue with a complete Referral Intake vertical slice using the identity/security controls now in place. Requirements: permissions on every endpoint, automatic audit events, notification events, search indexing, tenant isolation, reviewed migration, OpenAPI updates, Next.js screens, Jest/PostgreSQL tests, and Playwright workflow. Preserve all v3.5 behavior and do not mark a gate passed without raw evidence.
