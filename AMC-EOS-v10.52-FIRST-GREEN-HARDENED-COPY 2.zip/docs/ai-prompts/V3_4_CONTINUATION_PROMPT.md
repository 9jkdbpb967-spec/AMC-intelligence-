# AMC-EOS v3.4 continuation

Use v3.3 as the only source of truth. Do not claim a gate passed without attaching its log.

Primary goal: execute the production Node/PostgreSQL validation in an environment with public npm and Docker.

Required tasks:
1. Generate and commit package-lock.json using npm ci-compatible versions.
2. Run Prisma format, generate, and validate; repair every reported issue.
3. Deploy all reviewed migrations to disposable PostgreSQL.
4. Compile API, worker, web, e2e, and shared packages.
5. Run Jest with coverage.
6. Replace source-contract integration tests with real HTTP cross-tenant calls.
7. Execute simultaneous PostgreSQL admissions against one bed and prove one winner.
8. Generate the production typed client from OpenAPI and verify no diff after regeneration.
9. Run Playwright login-referral-readiness-admission-resident flow.
10. Make all GitHub Actions green and attach logs.
11. Update release attestation and rollback instructions.

Preserve tenant scoping, auditability, idempotency, revocable sessions, and human approval requirements.
