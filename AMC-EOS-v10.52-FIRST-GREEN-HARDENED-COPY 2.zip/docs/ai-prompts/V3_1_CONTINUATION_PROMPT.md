# AMC-EOS v3.1 Continuation Prompt

Read `docs/PRODUCTION_VERTICAL_SLICE_V3.md` and `pilot-runtime/tests/test_vertical_slice.py` first.

Goal: port the validated pilot vertical slice into the existing NestJS/Prisma/Next.js applications without changing its externally observable workflow.

Required deliverables:
1. public-registry `package-lock.json`;
2. official Prisma validation;
3. reviewed PostgreSQL migration;
4. NestJS login/referral/readiness/admission/resident endpoints;
5. transactionally safe admission and bed occupation;
6. tenant-isolation tests;
7. Next.js screens matching the pilot workflow;
8. contract tests proving API parity with the pilot runtime;
9. CI logs, migration evidence, rollback plan, and limitations.

Never use real PHI. Do not claim a gate passed without logs.
