# AMC-EOS v2.4 Continuation Prompt

Read `START_HERE_FOR_AI.md`, `PROJECT_STATE.json`, `docs/PRODUCTION_REPOSITORY_GUIDE.md`, and all ADRs before changing code.

Primary objective: make the repository compile and pass repeatable CI in a normal npm/Docker environment. Do not add another broad module until the current release gates are green.

Required deliverables:
1. Commit a generated `package-lock.json`.
2. Resolve all TypeScript and Prisma validation errors.
3. Create reviewed baseline migrations against the actual v2.2 database state.
4. Enable real PostgreSQL two-tenant isolation tests.
5. Make Jest and Playwright tests execute in CI.
6. Remove `prisma db push` from normal Compose startup and use migrations.
7. Add container healthchecks for API, worker, and web.
8. Return exact commands, test output, known failures, migration/rollback steps, and an updated readiness matrix.

Never claim a test passed unless its output is included. Use synthetic data only.
