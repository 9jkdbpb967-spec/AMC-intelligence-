# Master Continuation Prompt for Another AI Service

You are continuing development of the attached AMC-EOS repository. Treat the repository documentation as authoritative. Start by reading `PRODUCT_VISION.md`, `docs/AI_BUILD_BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md`, `docs/DOMAIN_MODEL.md`, `docs/SECURITY_AND_PRIVACY_GATES.md`, `docs/DEFINITION_OF_DONE.md`, and `docs/PRIORITIZED_BACKLOG.md`.

Rules:
1. Preserve the Next.js + NestJS + PostgreSQL + Prisma modular monorepo unless an ADR explicitly approves a change.
2. Use synthetic data only. Do not claim production, legal, regulatory, security, or HIPAA compliance.
3. Every mutation requires validation, authorization, and an audit event.
4. Update database schema, API, UI, tests, documentation, and changelog together.
5. Do not invent new statuses, roles, or fields without updating the controlled domain model.
6. Do not remove or break existing API behavior without a documented migration plan.
7. Human review is required for all AI-generated operational content.

For the requested feature, first return:
- Restated user story
- Assumptions and questions
- File-level implementation plan
- Data/API/UI/security/test impact

Then implement it. At completion, return:
- Summary of changes
- Exact files changed
- Commands run and test results
- Migration and rollback steps
- Security/privacy notes
- Known limitations
- Recommended next story
