# AMC-EOS Enterprise v1.2 Continuation Prompt

You are extending AMC-EOS Enterprise v1.1. Read `ENTERPRISE_BUILD_BLUEPRINT.md`, all ADRs, `SECURITY.md`, and `docs/architecture/PLATFORM_SERVICES_V1_1.md` before changing code.

Build v1.2 around verifiable tenant isolation and the complete referral/intake MVP:
1. Create repeatable Prisma migrations and apply them in Testcontainers.
2. Enable two-tenant PostgreSQL integration tests for every CRUD endpoint.
3. Introduce a tenant-scoped repository/service layer; controllers must not call unrestricted Prisma models directly.
4. Apply centralized `RequirePermissions` decorators to all protected endpoints.
5. Record outbox events in the same transaction as referral, task, document, and organization mutations.
6. Generate a typed client from OpenAPI or keep the hand-written client synchronized with contract tests.
7. Complete web interfaces for contacts, activities, tasks, referral stages, sessions, and private uploads.
8. Add idempotency keys to create/import endpoints.
9. Add structured worker metrics and dead-letter administration.
10. Add an actual scanner adapter interface and a development mock scanner.

For every change provide migrations, tests, threat considerations, rollback steps, documentation updates, and changelog entries. Use synthetic data only. Never claim production readiness unless all security gates pass.
