# AMC-EOS v0.8 Continuation Prompt

You are continuing AMC-EOS from v0.7. Read PRODUCT_VISION.md, SYSTEM_ARCHITECTURE.md, DOMAIN_MODEL.md, PERMISSION_MATRIX.md, TRUST_BOUNDARY_BLUEPRINT.md, DEFINITION_OF_DONE.md, and CHANGELOG.md before changing code.

Build v0.8 as a verifiable production-readiness sprint:
1. Add Testcontainers-based PostgreSQL integration tests with two tenants.
2. Test every tenant-owned controller for cross-tenant read, create, update, and delete denial.
3. Replace the development signed-storage adapter with a configurable S3-compatible adapter and local MinIO profile.
4. Add a public, HMAC-authenticated malware-scan callback that does not require a user JWT; bind callbacks to document ID, tenant ID, checksum, and timestamp.
5. Add an internal worker process that claims jobs safely with row locking, retries with exponential backoff, and dead-letters failures.
6. Add an outbox table for reliable domain events.
7. Generate OpenAPI DTO schemas and publish a typed API client for the web app.
8. Add session-management UI and document upload/download UI with quarantine messaging.
9. Add CI services for PostgreSQL and MinIO, run migrations, seed two tenants, and execute integration tests.
10. Update migration guides, threat model, test evidence, changelog, and rollback steps.

Constraints: preserve Next.js + NestJS + Prisma + PostgreSQL; use synthetic data only; do not claim HIPAA compliance; never rely on frontend authorization; do not expose quarantined files; document assumptions and unresolved risks.
