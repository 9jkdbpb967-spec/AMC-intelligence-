# AMC-EOS v2.5 Continuation Prompt

Continue from AMC-EOS v2.4. Read `START_HERE_FOR_AI.md`, `PROJECT_STATE.json`, `RELEASE_2_4.md`, `BUILD_VALIDATION_V2_4.md`, and `docs/database/MIGRATION_BASELINE_V2_4.md` first.

Highest priority is validation, not feature expansion:

1. Use a public npm registry to generate and commit `package-lock.json`.
2. Run Prisma format, generate, and validate; repair all schema errors.
3. Restore or establish the real predecessor database state.
4. Generate reviewed create-only migration SQL and test it forward.
5. Run TypeScript checks and repair compilation errors.
6. Run Jest, two-tenant PostgreSQL, and Playwright tests.
7. Validate Docker Compose development and production startup.
8. Test backup restoration and document evidence.
9. Only after these gates pass, begin Finance & Resource Operations.

Do not fabricate successful test results or migration evidence. Return changed files, commands, exact results, known failures, risks, migration instructions, and rollback/restore steps.
