# AMC-EOS v2.8 continuation prompt
Read START_HERE_FOR_AI.md, PROJECT_STATE.json, RELEASE_2_7.md, and docs/pilot/PILOT_DEPLOYMENT_RUNBOOK.md first.

Execute validation in an environment with public npm, Docker, and PostgreSQL. Do not redesign the architecture.

Required work:
1. Generate and commit package-lock.json with npm ci proof.
2. Run Prisma format/generate/validate and repair all failures.
3. Generate a reviewed migration against the true prior database state.
4. Repair all TypeScript compilation errors.
5. Run Jest, two-tenant PostgreSQL, and Playwright suites.
6. Start compose.pilot.yaml and capture health evidence.
7. Perform database backup and isolated restoration.
8. Update release evidence only with actual successful command logs.
9. Do not use protected data; use synthetic fixtures.
10. Return migration, rollback, test, security, and limitation reports.
