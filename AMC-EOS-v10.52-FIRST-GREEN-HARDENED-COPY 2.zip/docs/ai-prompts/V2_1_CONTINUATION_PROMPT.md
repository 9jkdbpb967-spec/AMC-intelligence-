# AMC-EOS v2.1 continuation prompt
Read START_HERE_FOR_AI.md, PROJECT_STATE.json, SECURITY.md, docs/SYSTEM_ARCHITECTURE.md, docs/product/INCIDENT_SAFETY_QUALITY_MODULE.md, and RELEASE_2_0.md before editing.

Implement Workforce Management Foundation without redesigning existing domains:
1. Employee profiles and employment history
2. Credentials and expiration reminders
3. Availability, shifts, assignments, and coverage rules
4. Training assignments and completion records
5. Performance/coaching foundation
6. Tenant isolation, role authorization, audit events, OpenAPI, tests, UI, migrations, rollback notes
Use synthetic data only. Report every failed validation honestly.
