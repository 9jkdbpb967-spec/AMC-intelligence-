# AMC-EOS Version 0.7 AI Sprint Prompt

Read PRODUCT_VISION.md, SYSTEM_ARCHITECTURE.md, TENANCY_AND_SESSION_BLUEPRINT.md, SECURE_DOCUMENT_PIPELINE.md, PERMISSION_MATRIX.md, and DEFINITION_OF_DONE.md before editing.

Build Version 0.7 without changing the stack. Implement:
1. PostgreSQL-backed integration test harness with two tenants.
2. Cross-tenant authorization tests for every CRUD route.
3. Swagger/OpenAPI documentation and exported JSON spec.
4. S3-compatible private storage adapter with presigned upload/download URLs.
5. Malware scan webhook verification and quarantine enforcement.
6. Session management UI and revoke-all action.
7. Background job abstraction for reminders and scans.
8. Update schema migration, tests, docs, changelog, and rollback notes.

Use synthetic data only. Do not claim HIPAA compliance. Return changed files, commands, test output, migration/rollback steps, risks, and remaining gaps.
