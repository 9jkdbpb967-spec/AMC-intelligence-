# AMC-EOS v1.8 Continuation Prompt — Service Plans and Goals

Read START_HERE_FOR_AI.md, PROJECT_STATE.json, RELEASE_1_7.md, docs/product/RESIDENT_MANAGEMENT_SPEC.md, the Prisma schema, permission matrix, threat model, and migration workflow before editing.

Implement v1.8 without redesigning the platform:
1. Versioned person-centered service plans.
2. Goals, measurable objectives, support strategies, responsible roles, and target dates.
3. Draft, review, approval, effective, superseded, and archived states.
4. Electronic approval evidence and immutable revision history.
5. Goal-progress entries linked to daily/progress notes.
6. Review-date reminders and escalation jobs.
7. Tenant isolation and role authorization for every route.
8. OpenAPI, typed client, unit, integration, and Playwright updates.
9. Migration and rollback documentation.
10. No real PHI or unsupported Washington compliance claims.

Return modified source, migrations, commands run, test results, risks, known limitations, completion percentage, and next-sprint recommendation.
