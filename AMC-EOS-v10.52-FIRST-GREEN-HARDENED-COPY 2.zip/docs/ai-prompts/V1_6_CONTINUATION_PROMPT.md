# AMC-EOS Enterprise v1.6 continuation prompt

Read `START_HERE_FOR_AI.md` when present, then architecture, security, tenancy, Version 1.5 release notes, event catalog, idempotency standard, OpenAPI baseline, and test plan.

Build Version 1.6 without changing the stack or weakening tenant isolation.

Priority:
1. Enforce idempotency on task, checklist, assessment, activity, and import creation.
2. Implement two-tenant PostgreSQL integration tests with Testcontainers for all pilot endpoints.
3. Add notification inbox APIs and UI with mark-read behavior.
4. Add an admissions decision workflow tied to home and bed selection.
5. Add a pilot readiness dashboard and blocking-rule engine.
6. Generate the typed client from complete OpenAPI rather than handwritten methods.
7. Add worker/outbox metrics and health checks.
8. Add Playwright coverage for referral creation, checklist verification, assessment, approval, and bed assignment.

Return modified repository, migrations, test results, known failures, security notes, and rollback instructions. Use synthetic data only.
