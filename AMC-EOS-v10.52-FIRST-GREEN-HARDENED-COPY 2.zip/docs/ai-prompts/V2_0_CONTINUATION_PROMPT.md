# AMC-EOS v2.0 Continuation Prompt

Read START_HERE_FOR_AI.md, PROJECT_STATE.json, RELEASE_1_9.md, the architecture and security documents, and the Prisma schema before editing.

Implement Sprint 20: Incident, Safety & Compliance.

Required scope:
1. Incident intake, severity, category, witnesses, evidence, immediate actions, and notifications.
2. Investigation, root-cause analysis, external-reporting checklist, CAPA, approval, closure, and reopening.
3. Resident and home timeline integration.
4. Tenant isolation, role authorization, validation, audit events, transactional outbox events, and human approval.
5. UI for incident reporting, investigation, CAPA, executive alerts, and quality analytics.
6. OpenAPI, typed client, migration plan, unit tests, PostgreSQL two-tenant tests, Playwright contracts, release notes, changelog, and PROJECT_STATE updates.

Do not use real protected information. Do not claim tests passed unless executed. Preserve the existing stack and architecture.
