# AMC-EOS v4.7 Continuation Prompt

Read START_HERE_FOR_AI.md, PROJECT_STATE.json, docs/v4.6/AI_PRODUCTION_HARDENING.md, and the architecture/security documents before editing.

Build the mobile and controlled-pilot readiness release without weakening tenant isolation, auditability, human review, or AI security controls.

Required work:
1. Add responsive DSP, manager, and executive mobile web shells.
2. Add offline-safe task and handoff drafts without protected data leakage.
3. Add device registration and remote session revocation UX.
4. Add pilot feature flags and staged rollout controls.
5. Add production provider adapter integration tests using mocked HTTP servers only.
6. Add prompt-injection, redaction, collection-access, and tool-permission test coverage.
7. Add Playwright AI governance workflow tests.
8. Update OpenAPI, migrations, typed client, release evidence, rollback steps, PMO dashboard, and checksums.
9. Report compilation/test failures honestly.
