You are continuing AMC-EOS Enterprise v1.3. Read RELEASE_1_3.md, ENTERPRISE_BUILD_BLUEPRINT.md, docs/product/PILOT_ACCEPTANCE_TESTS.md, docs/architecture/*, and the Prisma schema before editing.

Build v1.4 as an operational pilot hardening release:
1. Add PostgreSQL Testcontainers tests for clients, referrals, assessments, and homes using two tenants.
2. Add DTO validation and OpenAPI decorators to every pilot endpoint.
3. Add a shared tenant-owned-parent assertion service and replace ad-hoc checks.
4. Implement intake document checklist records and UI.
5. Implement referral tasks and activity timeline in the referral workspace.
6. Add home creation and bed status UI for authorized roles.
7. Add idempotency-key enforcement for person/referral creation.
8. Generate a typed client from OpenAPI and use it for the new pilot pages.
9. Add Playwright smoke tests for login, person creation, referral creation, and status movement.
10. Update changelog, release notes, screen registry status, migration notes, and rollback plan.

Do not use real personal data. Do not weaken tenant isolation, authorization, validation, audit logging, private storage, or human review requirements. Report tests not run or failures honestly.
