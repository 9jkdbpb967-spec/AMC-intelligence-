# AMC-EOS v3.2 continuation prompt

Read `RELEASE_V3_1.md`, `PROJECT_STATE_V3_1.json`, `docs/port-contract/V3_1_TYPESCRIPT_PORT_CONTRACT.md`, and `pilot-runtime/openapi.yaml` first.

Implement the same behavior in the existing NestJS/Prisma/PostgreSQL monorepo without redesigning the domains.

Required work:

1. Tenant-slug login and revocable sessions.
2. Idempotency middleware/service using a unique tenant/user/key constraint.
3. Referral detail and activity endpoints.
4. Transactional admission with row-level locking on the selected bed.
5. Two-tenant PostgreSQL integration tests matching the executable pilot tests.
6. Generated OpenAPI client and matching Next.js screens.
7. Migrations, tests, release notes, rollback instructions, and honest test evidence.

Never claim a test or build passed unless it was executed successfully.
Use synthetic data only.
