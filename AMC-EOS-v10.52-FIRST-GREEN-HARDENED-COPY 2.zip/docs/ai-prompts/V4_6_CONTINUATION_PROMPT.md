# AMC-EOS v4.6 Continuation Prompt

Use the v4.5 repository as the source of truth. Implement AI production hardening without redesigning the architecture.

Required work:
1. Official Prisma migration and validation for all v4.5 AI records.
2. Compile and repair the NestJS AI module and Next.js AI workspaces.
3. Add a provider adapter configuration system with encrypted secret references; never store provider secrets in database JSON.
4. Add prompt-injection screening and sensitive-data redaction before external provider calls.
5. Add collection-level permissions and agent tool authorization tests.
6. Add real PostgreSQL two-tenant retrieval and approval tests.
7. Generate typed client methods from OpenAPI.
8. Add Playwright tests for knowledge search, cited answers, approval, feedback, and usage.
9. Add model health, timeout, retry, and circuit-breaker evidence.
10. Update PMO, migration, rollback, test logs, release evidence, and checksums.

Do not claim production readiness unless compilation, migrations, PostgreSQL tests, browser tests, and security review pass with evidence.
