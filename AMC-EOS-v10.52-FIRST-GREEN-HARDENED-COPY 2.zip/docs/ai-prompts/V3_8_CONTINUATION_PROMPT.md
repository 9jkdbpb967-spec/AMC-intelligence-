# AMC-EOS v3.8 Continuation Prompt

Read START_HERE_FOR_AI.md and PROJECT_STATE.json first. Continue from v3.7. Implement production NestJS/Prisma parity for intake operations, execute PostgreSQL migrations, add organization autocomplete, real private upload intents, malware-scan linkage, scheduled reminder worker, waitlist review jobs, duplicate-resolution controls, and Playwright coverage. Preserve tenant isolation, audit events, immutable history, and human approval gates. Return code, tests, logs, migration/rollback steps, limitations, and updated completion evidence.
