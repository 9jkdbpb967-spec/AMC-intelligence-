# AI Build Blueprint

## Objective
Enable another AI coding service or engineering team to continue AMC-EOS without changing the product's core architecture, terminology, security boundaries, or roadmap.

## Required Starting Context
Before generating code, the next builder must read in this order:
1. `README.md`
2. `PRODUCT_VISION.md`
3. `docs/SYSTEM_ARCHITECTURE.md`
4. `docs/DOMAIN_MODEL.md`
5. `docs/SECURITY_AND_PRIVACY_GATES.md`
6. `docs/DEFINITION_OF_DONE.md`
7. `docs/PRIORITIZED_BACKLOG.md`
8. Relevant module specification under `docs/modules/`
9. Existing Prisma schema and API controllers

## Non-Negotiable Product Rules
- Preserve a modular monorepo with Next.js, NestJS, PostgreSQL, and Prisma unless an approved architecture decision record changes it.
- Every mutation must be authorized, validated, and auditable.
- No real protected health, Medicaid, employee, or financial information is permitted until production security gates are passed.
- AI output is advisory and requires human review before becoming an official record.
- Maintain data isolation, least privilege, audit trails, and version control.
- Do not create undocumented fields, statuses, roles, or workflows. Update the domain model first.
- Do not silently remove existing features or change API contracts.

## Standard AI Work Cycle
1. Restate the requested story and affected modules.
2. Identify assumptions and unresolved compliance questions.
3. Produce a file-level implementation plan.
4. Update schema/API/UI/tests/documentation together.
5. Run lint, type checking, unit tests, integration tests, migrations, and build.
6. Summarize files changed, risks, test results, and rollback instructions.

## Required Output from Another AI
For every feature, require:
- User story and acceptance criteria
- Threat/privacy review
- Data migration impact
- API contract changes
- UI states: loading, empty, validation, error, permission denied
- Automated tests
- Audit events
- Documentation update
- Rollback plan

## Master Continuation Prompt
Copy `docs/ai-prompts/MASTER_CONTINUATION_PROMPT.md` into the other AI service and attach the repository.
