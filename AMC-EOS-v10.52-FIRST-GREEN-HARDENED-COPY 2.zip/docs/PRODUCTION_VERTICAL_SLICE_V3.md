# AMC-EOS v3.0 Production Vertical Slice

## Purpose

Provide an immediately runnable proof of the target architecture while the NestJS/Next.js dependency and migration gates remain unresolved.

## Implemented workflow

Login → tenant context → referral creation → readiness gate → bed selection → admission transaction → resident creation → audit event.

## Architectural relationship

The `pilot-runtime` is deliberately isolated from the enterprise TypeScript applications. It validates business behavior and API shape without replacing the target Next.js/NestJS/PostgreSQL architecture.

## Promotion path

1. Treat the pilot runtime API behavior as executable acceptance criteria.
2. Generate the public npm lockfile in a normal engineering environment.
3. make Prisma and TypeScript CI green.
4. Port the tested vertical slice to NestJS services and PostgreSQL transactions.
5. Run contract tests against both implementations until parity is reached.
6. Retire the Python runtime after the TypeScript production slice passes all release gates.
