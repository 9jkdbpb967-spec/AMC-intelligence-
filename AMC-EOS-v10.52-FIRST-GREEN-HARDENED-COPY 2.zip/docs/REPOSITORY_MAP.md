# Repository Map

```text
apps/web                 Next.js web application
apps/api                 NestJS API
apps/api/prisma          Prisma schema and seed
docs                     Product, architecture, security, and AI handoff documents
docs/modules             Module requirements
docs/adr                 Architecture decision records
docs/ai-prompts          Prompts for another AI coding service
compose.yaml             Local application stack
```

## Naming
- API modules: plural domain nouns
- DTOs: `CreateXDto`, `UpdateXDto`, `XQueryDto`
- Events: past tense, e.g. `ReferralCreated`
- Audit actions: uppercase controlled vocabulary
