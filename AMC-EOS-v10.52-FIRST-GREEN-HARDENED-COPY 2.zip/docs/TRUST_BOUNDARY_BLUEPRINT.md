# AMC-EOS v0.7 Trust Boundary Blueprint

## Release objective
Turn tenancy, sessions, document handling, and automation into explicit trust boundaries that another engineering team or AI service can verify.

## Non-negotiable invariants
1. Every tenant-owned read and mutation includes the authenticated `tenantId`.
2. Parent records are resolved inside the same tenant before child records are created.
3. A document cannot be downloaded until its status is `AVAILABLE`.
4. Scan callbacks require a timestamped HMAC signature and may only clear or quarantine a file.
5. Refresh sessions are revocable individually and per tenant.
6. Background jobs carry a tenant ID and may never process data globally without explicit administrative design.
7. OpenAPI is documentation, not authorization; guards and tenant scoping remain mandatory.

## Production storage adapter
The development storage service emits signed application URLs. Replace it with an S3-compatible adapter that supports private buckets, short-lived presigned URLs, server-side encryption, object versioning, access logs, retention controls, and malware scanning.

## AI continuation rule
A future AI service must not weaken these invariants to simplify implementation. It must provide tests proving tenant isolation and document quarantine behavior before marking work complete.
