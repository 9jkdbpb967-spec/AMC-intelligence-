# v3.1 TypeScript Production Port Contract

The Python/SQLite pilot runtime is the executable behavioral reference for the NestJS/PostgreSQL port.

## Required behavior parity

1. Login requires `tenantSlug`, email, and password.
2. Every authenticated query is tenant scoped.
3. Referral creation supports `Idempotency-Key` replay and conflict behavior.
4. Readiness requires management approval, completed assessment, and verified documents.
5. Admission is transactional: admission + resident + occupied bed + admitted referral + audit/activity.
6. Cross-tenant identifiers return 404 and never disclose record existence.
7. Logout revokes the active session.

## NestJS module mapping

- `AuthModule`: login, logout, session validation, tenant resolution.
- `ReferralsModule`: create/list/detail/activity/readiness.
- `AdmissionsModule`: readiness assertion and transactional admission.
- `ResidentsModule`: tenant-scoped resident directory.
- `HomesModule`: tenant-scoped homes and beds.
- `AuditModule`: immutable audit append.

## PostgreSQL requirements

- Foreign keys and tenant-aware indexes.
- Unique `(tenant_id, user_id, key_value)` idempotency constraint.
- Serializable or explicit row locking for bed assignment.
- No cross-tenant joins without tenant predicates.
