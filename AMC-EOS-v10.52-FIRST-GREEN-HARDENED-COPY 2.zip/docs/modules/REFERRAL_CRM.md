# Referral CRM Module Specification

## Goal
Manage referral-source relationships and convert activity into qualified referrals and admissions.

## Core Features
- Organization and contact records
- Categories, service areas, departments, priorities, and relationship stages
- Calls, emails, visits, meetings, notes, and attachments
- Tasks, reminders, ownership, and overdue queues
- Import, deduplication, search, filters, and export
- Referral attribution and conversion analytics

## Key Measures
- New organizations contacted
- Meetings scheduled
- Follow-up completion
- Active referral partners
- Referrals received
- Referral-to-admission conversion
- Average response and placement time
