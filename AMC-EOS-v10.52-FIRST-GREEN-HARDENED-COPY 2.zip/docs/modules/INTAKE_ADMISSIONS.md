# Intake and Admissions Module Specification

## Goal
Provide a controlled, ethical workflow from referral receipt through assessment, decision, and admission.

## Required Controls
- Unique referral ID
- Assigned coordinator
- Required information/document checklist
- Consent and authorization status
- Funding and eligibility status
- Assessment and compatibility review
- Management decision and rationale
- Status history
- Capacity confirmation
- Follow-up and closure reasons

The system must never auto-approve a placement or present AI recommendations as final decisions.
