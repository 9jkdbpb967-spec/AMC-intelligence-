# Test Strategy

## Required Layers
- Unit tests for business rules
- Authorization tests for every protected route
- API integration tests using a disposable database
- Web component/page tests for critical workflows
- End-to-end tests for login, CRM, intake, status changes, task completion, and audit review
- Migration tests
- Backup/restore tests before production

## Minimum Critical Scenarios
- User cannot access a module without permission.
- User cannot change their own privileged role.
- Referral stage changes create history and audit events.
- Invalid import rows do not partially corrupt records.
- Duplicate organizations/contacts are detected.
- Deleted/deactivated records remain auditable.
- Sensitive exports are authorized and logged.
