# Release Readiness Matrix — v2.3

| Gate | Current status | Required evidence |
|---|---|---|
| Repository structure | Passed | `npm run repo:check` |
| Dependency lockfile | Blocked | Successful `npm install` in normal registry environment and committed `package-lock.json` |
| Prisma validation | Pending | `npx prisma validate` |
| Reviewed migrations | Pending | Committed SQL and migration review |
| TypeScript compilation | Pending | API and web typecheck logs |
| Unit tests | Pending | Jest results and coverage |
| Tenant isolation | Pending | Two-tenant PostgreSQL test results |
| Browser tests | Pending | Playwright report |
| Containers | Pending | Healthy Compose stack |
| Security | Pending | SAST, dependency scan, secrets scan, penetration review |
| Accessibility | Pending | WCAG review results |
| Backup recovery | Pending | Documented restore exercise |
