# AMC-EOS Runtime Build Quickstart

This is the shortest supported path from the repository archive to an executed build.

## Recommended environment

Use GitHub Codespaces or VS Code Dev Containers. Open the repository and choose **Reopen in Container**. The container pins Node 22, pnpm 10.15.0, Python, and Docker support, and uses the public npm registry.

## Local bootstrap

```bash
bash scripts/runtime/bootstrap-development-environment.sh
git add pnpm-lock.yaml
git commit -m "chore(deps): commit reproducible pnpm lockfile"
```

## First green build

```bash
bash scripts/runtime/run-first-green-build.sh
```

Evidence is written to `release-evidence/runtime/`.

## Database validation

Start PostgreSQL and set `DATABASE_URL`, then run:

```bash
pnpm db:format
pnpm db:generate
pnpm db:validate
pnpm db:migrate
```

Never edit `pnpm-lock.yaml` or generated migration SQL by hand merely to make a gate appear green. Resolve the actual dependency or schema issue and preserve raw logs.
