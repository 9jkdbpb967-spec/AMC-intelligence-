# Database Migration Workflow

1. Modify `apps/api/prisma/schema.prisma`.
2. Generate a named development migration with `prisma migrate dev --name <change>`.
3. Inspect generated SQL before commit.
4. Test migration against a disposable database containing synthetic records.
5. Document data backfill and rollback risks.
6. Deploy using `prisma migrate deploy`; never use `db push` in production.
7. Verify `/ready`, application logs, and key queries after deployment.

Destructive changes require an expand-and-contract release: add the replacement field, backfill, update application reads/writes, verify, and remove the old field in a later release.
