# Release Checklist

## Code quality
- [ ] Type checking passes for API and web
- [ ] Unit and integration tests pass
- [ ] Production build succeeds
- [ ] Database migration reviewed and reversible
- [ ] Changelog updated

## Security
- [ ] No secrets committed
- [ ] Default passwords removed
- [ ] JWT secret rotated
- [ ] Authorization tests cover new endpoints
- [ ] Audit events added for sensitive mutations
- [ ] Dependency vulnerability scan reviewed

## Data and operations
- [ ] Synthetic data only outside approved production environment
- [ ] Backup and restore tested
- [ ] Monitoring and alert rules reviewed
- [ ] Rollback instructions documented
- [ ] User documentation updated
