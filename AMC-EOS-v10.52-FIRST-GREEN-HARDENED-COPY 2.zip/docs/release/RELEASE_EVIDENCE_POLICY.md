# AMC-EOS Release Evidence Policy

## Single source of truth

Only `release-evidence/current/` may be used as proof for a current release candidate.

All other `release-evidence/*` folders are historical diagnostic material unless intentionally archived.

## READY requirements

A release candidate is `READY` only when every mandatory command has:

- a current evidence JSON record;
- exit code `0`;
- status `passed`;
- exact command text;
- commit identifier matching the current checkout when available;
- completion timestamp inside the configured freshness window;
- raw log SHA-256.

The aggregate `release-attestation.json` must also report `passed`.

## Default mandatory runtime proof

- workspace semantic typecheck;
- Prisma generate;
- Prisma validate;
- Prisma migrate;
- referrals PostgreSQL integration;
- core-pilot PostgreSQL integration;
- workforce PostgreSQL integration;
- finance PostgreSQL integration;
- analytics PostgreSQL integration;
- manager-operations PostgreSQL integration;
- legacy-pipeline guard Jest behavior;
- authentication HTTP/PostgreSQL suite;
- API production build.

E2E can be made mandatory by using `--require-e2e`.

## Historical evidence

Historical logs may help diagnose regressions, but they must never override a missing or failed current command.

## Release commands

Runtime proof:

`pnpm release:proof`

Strict decision:

`pnpm release:decision`

Full release-candidate gate:

`pnpm release:candidate`

Full release-candidate gate with Playwright:

`pnpm release:candidate:e2e`
