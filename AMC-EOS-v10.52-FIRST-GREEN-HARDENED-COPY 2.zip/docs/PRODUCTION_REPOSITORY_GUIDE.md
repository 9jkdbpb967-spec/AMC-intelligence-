# AMC-EOS Production Repository Guide

## One-command local path
1. Install Node.js 22 and Docker Desktop/Engine with Compose.
2. Copy `.env.example` to `.env` and replace every development secret.
3. Run `make bootstrap`.
4. Run `make dev`.
5. Open web at `http://localhost:3000` and API docs at `http://localhost:4000/api/docs`.

## Release gates
A release is not production-ready until dependency installation, Prisma validation, reviewed migrations, TypeScript compilation, unit tests, PostgreSQL tenant-isolation tests, Playwright tests, container startup, backup restoration, accessibility review, and security review all pass.

## Protected data
The repository remains unsuitable for real protected resident, employee, Medicaid, medical, payroll, or financial data until every release gate is evidenced.
