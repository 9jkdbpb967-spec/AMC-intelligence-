# Synthetic Data Standard

All staging identities use `.test` email domains, deterministic IDs, fictitious names, and `synthetic: true`. The generators must not ingest production exports, real addresses, Medicaid identifiers, diagnoses, or free-text resident notes. Scenario seeds make datasets reproducible. Synthetic datasets are disposable and must never be promoted to production.
