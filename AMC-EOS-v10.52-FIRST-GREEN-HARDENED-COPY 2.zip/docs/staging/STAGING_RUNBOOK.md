# AMC-EOS v5.1 Staging Runbook

Staging is synthetic-data-only. `ALLOW_REAL_PERSON_DATA` must remain `false`.

## Start
1. Copy `.env.staging.example` to `.env.staging` and replace every secret.
2. Run `npm run staging:preflight`.
3. Run `npm run staging:seed:generate`.
4. Start with the base, infrastructure, and staging Compose files.
5. Verify `/health`, `/ready`, `/version`, and Grafana.

## Reset
Run `npm run staging:reset -- standard-pilot`. Never reset an environment containing approved pilot data.

## Promotion gate
Promotion requires scenario validation, repository checks, migration evidence, test evidence, and rollback approval.
