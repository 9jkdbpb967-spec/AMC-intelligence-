# Staging User Acceptance Test Package

## Personas
Administrator, referral coordinator, home manager, DSP, finance reviewer, executive viewer.

## Required scenarios
1. Tenant login and isolation.
2. Referral intake through readiness.
3. Admission into the available synthetic bed.
4. Resident task, appointment, handoff, and documentation.
5. Workforce clock and leave workflow.
6. Purchase request through receiving.
7. KPI snapshot and executive briefing.
8. Device registration and offline sync.

Record expected result, actual result, evidence, severity, owner, and retest outcome for every step.
