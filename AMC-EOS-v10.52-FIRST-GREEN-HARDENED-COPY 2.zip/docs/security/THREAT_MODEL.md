# Initial Threat Model

## Protected assets
Resident and applicant information, employee records, referral relationships, contracts, documents, credentials, audit history, financial and operational data, proprietary manuals and workflows.

## Primary threats
Cross-tenant access, broken role authorization, credential theft, malicious uploads, insecure signed URLs, data export abuse, accidental disclosure, dependency compromise, secret leakage, destructive administrator action, and unreviewed AI output.

## Required controls
Tenant-scoped repositories, centralized authorization, MFA/SSO roadmap, refresh-token rotation, rate limits, private encrypted storage, malware quarantine, export controls, immutable audit records, backups, security scanning, and incident response procedures.
