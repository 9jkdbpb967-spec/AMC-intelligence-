# Workforce Readiness & Scheduling Controls

Readiness is evaluated from active employment, role-specific credentials, training completion, approved exceptions, and warning windows. Blocking requirements prevent shift assignment. Scheduling validation detects overlaps and warns when projected weekly hours exceed configured thresholds. Call-outs automatically reopen shifts and create coverage requests.

## Human controls
Managers retain approval authority. Exceptions require documented review, effective dates, expiration, and audit history.
