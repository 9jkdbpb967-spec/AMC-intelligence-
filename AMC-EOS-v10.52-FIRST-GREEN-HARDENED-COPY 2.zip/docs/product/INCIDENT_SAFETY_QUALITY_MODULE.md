# Incident, Safety & Quality Module

## Purpose
Provide a tenant-isolated, auditable workflow for immediate incident reporting, triage, investigation, external-reporting tracking, corrective/preventive action, verification, closure, and reopening.

## Safety rules
- Record immediate facts separately from investigation conclusions.
- Critical incidents require executive escalation through notification/workflow configuration.
- Original records are retained; later corrections are timeline entries or related records.
- Incident closure is blocked while required CAPAs remain open or unverified.
- External-reporting requirements are configurable and must be reviewed against current contracts and law before pilot use.

## Lifecycle
DRAFT → REPORTED → TRIAGED → UNDER_INVESTIGATION → ACTION_REQUIRED → REVIEWED → CLOSED. Closed incidents may be REOPENED by authorized quality leadership.

## Core records
Incident, IncidentPerson, IncidentWitness, IncidentEvidence, IncidentTimelineEntry, Investigation, InvestigationInterview, InvestigationFinding, ExternalReportingChecklist, Capa, CapaAction, CapaVerification.
