# Admission Readiness Rules

A referral is ready only when all checks pass:
1. Status is APPROVED.
2. At least one assessment is completed.
3. Every non-waived checklist item is VERIFIED.
4. No OPEN or IN_PROGRESS referral tasks remain.
5. No admission already exists.
6. The selected home and bed belong to the active tenant.
7. The selected bed is AVAILABLE.

Admission creation, bed occupation, referral status change, activity creation, and outbox event creation occur in one database transaction.
