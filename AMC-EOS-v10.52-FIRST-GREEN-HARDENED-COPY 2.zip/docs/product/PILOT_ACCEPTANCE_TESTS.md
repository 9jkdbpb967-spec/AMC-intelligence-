# Pilot Acceptance Tests

1. A referral coordinator can create a person and retrieve the record only within the active tenant.
2. A referral can be created for a tenant-owned person.
3. Referral status changes create an audit event.
4. An assessment cannot be created against a referral in another tenant.
5. A home creation request creates exactly the licensed number of bed records.
6. Home capacity screens never disclose another tenant's home or bed records.
7. All unknown API fields are rejected by global validation.
8. Read-only roles cannot perform controlled mutations.
9. The web UI exposes no real-data sample values in source or seed files.
10. Audit entries contain tenant, user, entity, action, and request identifiers.
