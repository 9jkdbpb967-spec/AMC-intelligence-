# Referral Intake Operations v3.7

Implemented capabilities:

- Organization and contact selection
- Program-driven required-document rules
- Secure document metadata linkage using tenant-scoped storage keys
- Task completion, overdue escalation, SLA warnings, and breach notices
- Referral reassignment
- Communication logs and intake meetings
- Screening outcomes: continue, waitlist, decline
- Waitlist tracking and review dates
- Duplicate referral detection by name, DOB, email, and phone
- Intake operations dashboard

The pilot runtime stores document metadata only; production file bytes remain subject to the private-storage and malware-scan architecture.
