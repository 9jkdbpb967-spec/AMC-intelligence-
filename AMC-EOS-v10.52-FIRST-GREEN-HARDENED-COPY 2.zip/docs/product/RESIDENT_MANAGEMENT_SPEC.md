# Resident Management Product Specification

## Purpose
Create one tenant-scoped operational record for each admitted person without duplicating the referral applicant record.

## Source of identity
The `Client` record remains the applicant/person identity source. `Resident` represents active residential-service operations and references `clientId`.

## Required capabilities
1. Admission creates or reactivates one resident record.
2. Home and bed assignment must match the active tenant.
3. Status changes create immutable status-history and timeline records.
4. Contact, guardian, funding, risk, preference, and note records are tenant scoped.
5. Resident detail assembles the current operational view without exposing records from another tenant.
6. Timeline events are append-only through normal application routes.

## Resident workspace
- Overview
- Timeline
- Contacts and guardians
- Funding and authorizations
- Risks and mitigation
- Notes
- Documents (storage integration pending)
- Service plans and goals (v1.8)

## High-level additions needed next
- Confidential-note access classification.
- Resident document associations and retention policies.
- Guardian-document verification.
- Funding renewal reminders.
- Risk-review reminder jobs.
- Service-plan versioning and approval workflow.
