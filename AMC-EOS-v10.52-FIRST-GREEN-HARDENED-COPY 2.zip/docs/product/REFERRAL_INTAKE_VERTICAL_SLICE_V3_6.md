# Referral Intake Vertical Slice v3.6

## Scope
A complete intake workflow from referral creation through demographics, referral-source linking, support-needs screening, funding evidence, coordinator assignment, SLA tracking, tasks, notifications, search, audit, and readiness handoff.

## SLA defaults
- URGENT: 4 hours
- HIGH: 24 hours
- ROUTINE: 72 hours

These are internal pilot defaults, not legal or contractual requirements. Configure them before operational use.

## Admission boundary
The intake module gathers and verifies evidence. It does not autonomously determine eligibility or admission. Human management approval remains required.
