# AMC-EOS v4.5 — AI Knowledge & Executive Assistance

## Purpose
Provide governed assistants that answer from approved AMC sources, retain citations, respect tenant boundaries, and route high-impact drafts to human approval.

## Implemented capabilities
- Provider and model registry
- Specialized agent registry
- Versioned prompt registry
- Approved knowledge-source catalog
- Deterministic chunking and tenant-scoped retrieval
- Source citations in every supported answer
- Knowledge, operations, and executive assistants
- Human approval queue
- AI execution history
- Token, latency, and estimated-cost tracking
- Feedback and correction records
- Audit events for executions and approvals

## Safety rules
1. Answers are grounded only in approved AMC knowledge sources.
2. No source match produces an explicit unsupported-answer response.
3. Executive-agent drafts require human approval.
4. AI output is advisory and cannot independently approve admissions, policies, resident decisions, personnel decisions, or payments.
5. All source, prompt, execution, approval, and feedback records are tenant-scoped.
6. Synthetic data only until production security and privacy gates pass.

## Pilot provider
The runnable pilot uses a deterministic no-network provider. It demonstrates the governed workflow and citations without sending information to an external AI provider.
