# Service Plan & Goal Module

## Purpose
Provide a controlled, versioned, person-centered planning system linked to each resident.

## Lifecycle
DRAFT → IN_REVIEW → APPROVED → EFFECTIVE → SUPERSEDED → ARCHIVED. Rejected or change-requested reviews return a plan to DRAFT. Only one effective plan should exist for a resident. Effective plans are locked; changes require a revision.

## Core records
ServicePlan, ResidentGoal, GoalObjective, SupportStrategy, GoalProgressEntry, ServicePlanApproval and ServicePlanReview.

## Governance rules
- All records are tenant scoped.
- Goals must describe a measurable resident outcome.
- Objective and strategy records remain attached to the approved version.
- Approval decisions identify the approver, role, date and optional signature evidence.
- Progress entries are append-only and update the goal summary.
- Activation supersedes the prior effective version in one transaction.
- Scheduled reviews can generate background reminder jobs.
- AI may draft text but cannot approve or activate a plan.
