# AMC-EOS v4.1 Finance & Resource Operations

The finance layer is an operational control system, not a replacement for a certified general ledger or payroll platform. It provides tenant-scoped vendors, purchase approvals, purchase orders, receiving, assets, maintenance, operating budgets, and grant deadlines.

## Core controls
- Two-stage purchase approval: manager, then finance.
- Budget availability check before finance approval.
- Budget commitments created when a purchase order is issued.
- Receiving records preserve who received an order and when.
- Assets may be linked to vendors, purchase orders, homes, and assignees.
- Grant milestones and reporting deadlines remain visible to leadership.
