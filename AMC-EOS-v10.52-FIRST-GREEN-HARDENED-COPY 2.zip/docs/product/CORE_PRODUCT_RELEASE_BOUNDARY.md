# AMC-EOS Core Product Release Boundary

## Pilot outcome

A supported-living team can securely move one synthetic referral through eligibility, admission, bed reservation, resident creation, and initial daily-service documentation without leaving AMC-EOS.

## Enabled modules

- Authentication and session security
- Dashboard
- Referrals and eligibility
- Admissions and bed reservation
- Residents
- Daily service documentation
- Basic workforce visibility
- Core workflow readiness

Finance, advanced analytics, AI, integrations, and other unfinished modules remain disabled in the core navigation until their dependency-backed gates pass.

## Role boundary

| Role | Core access |
|---|---|
| Administrator | All core modules and readiness checks |
| Manager | Referrals, admissions, residents, daily service, workforce, readiness |
| DSP | Dashboard, assigned residents, daily service |

## Acceptance criteria

1. An authorized administrator or manager signs in to the synthetic demonstration tenant.
2. A referral is created with required identity and source details.
3. Eligibility is reviewed and the referral is accepted.
4. An admission is created from the accepted referral.
5. Exactly one available bed is reserved; concurrent reservations cannot both succeed.
6. Required checklist and signature evidence are completed.
7. Admission completion creates a resident and occupies the reserved bed atomically.
8. A DSP can open the resident and submit initial daily-service documentation.
9. Every transition is tenant-scoped and produces audit evidence.
10. Logout or session revocation prevents further protected API access.

## Pilot release blocker

The pilot must not be promoted until the dependency-backed install, TypeScript, Prisma, migration, authentication, core Playwright workflow, and production build gates have all passed.
