# Workforce Management v2.1

## Capabilities
1. Employee master profile and lifecycle
2. Department and position catalog
3. Immutable employment history
4. Emergency contacts
5. Credential/certification tracking
6. Availability and scheduling
7. Open-shift coverage foundation
8. Training assignment tracking
9. Coaching and performance foundation
10. Workforce readiness dashboard

## Security
Every read and mutation is tenant scoped. HR mutations require CEO, ADMIN, or HR except approved manager-level scheduling/training operations.

## High-level readiness rules
An employee is pilot-ready only when active, required credentials are current, assigned mandatory training is complete, and the employee is eligible for the assigned home/role. Enforcement is scheduled for v2.2 after role-to-credential requirements are configured.
