# AMC-EOS v4.7 Mobile & Controlled Pilot

## Scope
Responsive Expo workspace for DSP users, offline action queue, device registration/revocation, tenant/home feature flags, and controlled rollout records.

## Safety rules
- Offline records are drafts until accepted by the server.
- Revoked devices cannot synchronize.
- Protected health information must not be stored in unencrypted logs.
- Feature kill switches override every rollout target.
- Conflicts require user review; they are never silently discarded.

## Rollout stages
Internal QA → test home → pilot home → regional rollout → organization-wide.
