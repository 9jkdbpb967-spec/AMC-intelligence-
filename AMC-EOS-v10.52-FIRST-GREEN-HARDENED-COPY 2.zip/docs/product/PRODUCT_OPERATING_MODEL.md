# Product Operating Model

## Product lines
1. AMC Supported Living operations.
2. AMC Placement and Referral Network.
3. AMC-EOS software platform.
4. AMC University training and certification.
5. AMC enterprise content library.

## Release train
- Monthly development release.
- Quarterly controlled pilot release.
- Annual supported enterprise release after security and compliance review.

## Prioritization score
Score each initiative from 1–5 for resident/customer value, compliance value, revenue enablement, risk reduction, effort, and dependency risk. Prioritize high-value, high-risk-reduction work with manageable effort.
