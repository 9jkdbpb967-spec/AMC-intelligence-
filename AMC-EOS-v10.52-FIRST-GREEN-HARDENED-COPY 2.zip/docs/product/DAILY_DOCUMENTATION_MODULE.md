# Daily Documentation Module

## Purpose
Capture timely, objective, person-centered evidence of supports, outcomes, goal progress, community participation, appointments, and follow-up needs.

## Lifecycle
DRAFT → SUBMITTED → LOCKED. A supervisor may return a submitted note to DRAFT. Locked records are never overwritten; corrections are recorded as amendments.

## Roles
- DSP: create and submit assigned documentation.
- House Manager: review, return, approve, and monitor completeness.
- Quality/Admin/CEO: audit, review, and report.

## Core controls
- Tenant-scoped queries.
- Immutable amendments.
- Late-entry flagging after 24 hours.
- Goal evidence linked to the resident and service-plan goal.
- Resident timeline entry for note creation and amendment.
- Human approval before locking.

## Pilot KPIs
- Notes due vs submitted.
- Submitted within 24 hours.
- Late-entry rate.
- Supervisor review turnaround.
- Goal-evidence coverage.
- Returned-for-changes rate.
