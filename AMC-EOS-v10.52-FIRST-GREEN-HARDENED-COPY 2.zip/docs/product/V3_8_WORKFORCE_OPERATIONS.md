# AMC-EOS v3.8 Workforce Operations

This vertical slice implements employee time capture, leave workflows, timesheet generation, employee documents, performance goals, recognition, and workforce dashboards.

## Security
All production records are tenant-scoped. Management review endpoints require HR or management roles. Audit and outbox events are produced for time events.

## Pilot limitation
The pilot runtime is synthetic-data-only. Payroll calculations are operational estimates and are not a substitute for a payroll system or legal wage determination.
