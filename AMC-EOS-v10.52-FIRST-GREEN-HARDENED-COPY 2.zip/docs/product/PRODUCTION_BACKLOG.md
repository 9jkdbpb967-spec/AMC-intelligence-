# AMC-EOS Enterprise Production Backlog

## Release 1.2 — Pilot Foundation
1. Generate and review the 50-table migration.
2. Implement tenant repository abstractions for all existing controllers.
3. Enable two-tenant Testcontainers tests.
4. Complete CRUD for CRM, intake, homes, residents, tasks, and documents.
5. Implement screens SCR-001 through SCR-025.
6. Generate a typed client from runtime OpenAPI.
7. Add idempotency to CSV imports and create-referral operations.
8. Emit transactional outbox events for every business mutation.
9. Add worker metrics and dead-letter administration.
10. Add pilot deployment manifests, backup verification, and smoke tests.

## Release gate
No real protected information until tenant isolation, access control, migration, encrypted storage, backup restoration, vulnerability scanning, logging, and incident-response testing pass.
