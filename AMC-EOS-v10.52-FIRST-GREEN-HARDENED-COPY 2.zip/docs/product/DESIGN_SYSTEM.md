# AMC-EOS Design System v1.0

## Principles
Accessible, calm, auditable, efficient, and consistent. Workflows affecting a resident or employee must show context, status, ownership, due dates, and audit history.

## Foundations
- 8px spacing scale
- Minimum 44px touch target
- WCAG 2.2 AA target
- Responsive breakpoints: 640, 768, 1024, 1280, 1536
- System font stack by default
- Semantic tokens rather than raw colors in components

## Core Components
AppShell, Sidebar, TopBar, Breadcrumbs, PageHeader, KPI Card, DataTable, FilterBar, StatusBadge, Timeline, ActivityComposer, KanbanBoard, FormSection, ValidationSummary, Drawer, Modal, ConfirmationDialog, Toast, EmptyState, AuditPanel, DocumentUploader, PermissionGate.

## Page Contract
Every production screen defines: persona, purpose, route, permissions, data sources, empty/loading/error states, audit events, accessibility notes, and acceptance criteria.
