# AMC-EOS v3.3 Release Evidence

## Evidence-backed results

- Runnable pilot tests: 5/5 passed.
- Cross-tenant isolation: passed in the runnable pilot.
- Concurrent admission race: two requests targeted one bed; exactly one returned 201 and one returned 409.
- Referral idempotency replay/conflict: passed.
- Session revocation: passed.
- Pilot SQLite migrations: executed.
- Repository, Prisma-structure, OpenAPI, and private-storage static checks: passed.
- Typed pilot API client: generated from the pilot OpenAPI contract.

## Production-stack blockers

The environment package registry returned HTTP 404 for `@nestjs/cli`, so `package-lock.json` could not be generated. Consequently, the following are not claimed as passed:

- NestJS/Next.js dependency installation
- official Prisma format/generate/validate
- PostgreSQL migration deployment
- TypeScript compilation
- Jest coverage
- PostgreSQL Testcontainers tests
- Playwright browser tests
- full production CI

See `release-evidence/v3.3/npm-lockfile.log` for the exact failure.
