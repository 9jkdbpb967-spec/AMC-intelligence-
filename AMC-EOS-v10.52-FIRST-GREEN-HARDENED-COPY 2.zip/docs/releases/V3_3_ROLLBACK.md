# v3.3 Rollback

## Pilot-runtime rollback

1. Stop the pilot server.
2. Restore the pre-v3.3 SQLite backup.
3. Revert `003_admission_bed_uniqueness.sql` only if no duplicate bed admissions exist.
4. Restore the v3.2 `pilot-runtime/server.py`.
5. Run the vertical-slice tests before restart.

## Production NestJS/PostgreSQL rollback

No production PostgreSQL migration was executed in this environment. Use the v3.2 migration rollback plan and a verified database backup before reverting a deployed environment.
