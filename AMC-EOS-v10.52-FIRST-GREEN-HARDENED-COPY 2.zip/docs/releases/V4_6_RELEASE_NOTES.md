# AMC-EOS v4.6 Release Notes

## AI Production Hardening

Version 4.6 adds governed-provider infrastructure and AI security controls while retaining the deterministic no-network pilot provider.

### Added
- Secret-reference records for provider credentials.
- OpenAI, Azure OpenAI, and Anthropic adapter interfaces, disabled by default.
- Provider timeout, retry, and circuit-breaker orchestration.
- Prompt-injection screening.
- Sensitive-data redaction.
- Collection-level role authorization.
- Agent tool-permission enforcement.
- AI provider health and cost/security dashboards.
- AI security events and provider-health history.
- Three Next.js administration screens.
- OpenAPI supplement and v4.7 continuation prompt.

### Executed validation
- 18 runnable pilot tests passed.
- Repository, Prisma structural, OpenAPI structural, and Python compile checks passed.

### Not yet validated
- Official Prisma CLI format/generate/validate.
- TypeScript compilation.
- Jest/PostgreSQL/Playwright execution.
- External provider network calls.
- Security, privacy, and model-risk approval.
