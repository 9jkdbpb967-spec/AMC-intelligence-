# Background Worker Runbook

The worker polls PostgreSQL for due jobs and outbox events.

## Job states
`PENDING → RUNNING → COMPLETE`

Failures return to `PENDING` with exponential delay until `maxAttempts`; afterward they move to `DEAD_LETTER`.

## Operating requirements
- Run at least two workers in production.
- Handlers must be idempotent.
- Alert on dead-letter count, oldest pending age, and repeated failures.
- Never delete failed rows without an approved retention process.
