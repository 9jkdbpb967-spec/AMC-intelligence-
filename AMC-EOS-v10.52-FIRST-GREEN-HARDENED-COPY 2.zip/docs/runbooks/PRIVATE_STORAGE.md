# Private Storage Runbook

1. Start MinIO using `docker compose up`.
2. The `minio-init` container creates a private bucket and disables anonymous access.
3. Clients request an upload intent from the authenticated API.
4. The client uploads directly using the short-lived signed PUT URL.
5. The client calls `complete-upload`; the API verifies the object exists and changes status to `PENDING_SCAN`.
6. A trusted scanner sends a signed scan result.
7. Clean files become `AVAILABLE`; infected or timed-out files become `QUARANTINED`.
8. Only `AVAILABLE` files receive signed GET URLs.

Never place protected data in object names, logs, notifications, or public bucket metadata.
