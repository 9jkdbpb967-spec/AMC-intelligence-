# Tenancy and Session Blueprint

Version 0.6 establishes explicit tenant isolation. Every business record carries `tenantId`; JWT access tokens carry the active tenant and membership role; API queries must scope by that tenant.

## Non-negotiable rules
1. Never accept tenant IDs from request bodies for ordinary business operations.
2. Resolve tenant context from the authenticated session.
3. Verify parent records belong to the same tenant before linking records.
4. Include tenant context in audit events.
5. Integration tests must prove cross-tenant reads and writes fail.

## Sessions
- Access token: 15 minutes.
- Refresh token: opaque random value, SHA-256 hash stored in database.
- Rotation: every refresh revokes the old session and creates a new one.
- Logout: revokes the supplied session.
- Admin security action: revoke all sessions for a user.

## Future SSO/MFA
Use an external identity provider supporting OIDC, WebAuthn/passkeys, TOTP, recovery codes, conditional access, and session revocation. Do not build custom cryptography.
