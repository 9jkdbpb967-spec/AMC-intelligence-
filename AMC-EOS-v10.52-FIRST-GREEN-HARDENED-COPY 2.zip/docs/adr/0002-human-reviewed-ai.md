# ADR 0002: Human-Reviewed AI

## Status
Accepted

## Decision
AI features are advisory. AI may search approved content and draft material, but may not autonomously approve admissions, modify official records, make clinical decisions, or make employment decisions.

## Consequences
The system must record AI provenance where used and require human confirmation before persistence to official records.
