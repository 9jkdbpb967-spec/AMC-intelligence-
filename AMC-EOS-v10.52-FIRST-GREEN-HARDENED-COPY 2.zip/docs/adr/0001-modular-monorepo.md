# ADR 0001: Modular Monorepo

## Status
Accepted

## Decision
Use a monorepo containing a Next.js web application and NestJS API with PostgreSQL and Prisma.

## Reason
This keeps product, API, schema, and shared release documentation together while maintaining clear module boundaries.

## Consequences
Changes must keep API, UI, migrations, tests, and documentation synchronized.
