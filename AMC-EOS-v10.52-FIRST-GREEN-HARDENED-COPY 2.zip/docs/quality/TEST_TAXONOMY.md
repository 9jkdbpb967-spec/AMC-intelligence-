# AMC-EOS Test Taxonomy

AMC-EOS uses four distinct evidence classes. They must not be described interchangeably.

## Executed unit test

Code is imported and executed by a test framework such as Jest. Assertions evaluate runtime behavior of functions/classes.

## Executed integration test

Application services or HTTP endpoints execute against real collaborators, especially generated Prisma Client and PostgreSQL. These are the primary proof for canonical data pipelines.

## Executed end-to-end test

Playwright or equivalent drives the running product through user-visible workflows.

## Static contract check

A script reads repository files, source text, manifests, schemas, or configuration and asserts that expected structures/strings exist.

Static checks are useful lint/architecture controls. They are **not tests of runtime behavior** and must not be reported as test passes.

## Release language

Allowed:
- "static contract check passed"
- "Jest integration test passed"
- "PostgreSQL integration test passed"
- "Playwright E2E passed"

Not allowed:
- calling a regex/source inspection script an integration test;
- claiming a dependency-backed build passed when dependencies were not installed;
- using historical logs as proof for a current commit.
