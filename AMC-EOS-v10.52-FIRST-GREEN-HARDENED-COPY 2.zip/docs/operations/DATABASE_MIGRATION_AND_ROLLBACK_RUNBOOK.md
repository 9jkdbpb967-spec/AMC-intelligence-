# Database Migration and Rollback Runbook

## Preconditions

1. Freeze schema changes.
2. Generate a verified backup and checksum.
3. Restore the backup into an isolated database.
4. Run the migration against the restored copy.
5. Run tenant-isolation, smoke, and data-count checks.
6. Obtain named engineering and operations approval.

## Deployment

```bash
npm ci
npm run db:generate
npm run migration:check
npm run db:migrate
```

## Rollback model

Prisma migrations are forward-oriented. Rollback must use one of these reviewed methods:

- restore the verified pre-release database backup;
- deploy a reviewed compensating migration;
- disable the affected feature with a feature flag while preserving data.

Never improvise destructive SQL during an incident.
