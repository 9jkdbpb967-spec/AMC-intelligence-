# API Idempotency Standard

Create operations that can produce duplicate records must require `x-idempotency-key`.

Rules:
1. Keys contain 8–200 characters.
2. A key is scoped by tenant and operation.
3. Replaying the same payload returns the stored response.
4. Reusing a key with a different payload returns HTTP 409.
5. Failed handlers remove incomplete reservations so a corrected retry can proceed.
6. Keys expire after 24 hours unless a module specifies a longer period.
