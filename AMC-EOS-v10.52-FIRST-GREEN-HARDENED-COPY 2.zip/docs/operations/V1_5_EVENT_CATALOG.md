# Version 1.5 Event Catalog

| Event | Aggregate | Trigger | Expected consumers |
|---|---|---|---|
| `referral.created` | Referral | Successful idempotent referral creation | dashboard projection, notification, analytics |
| `referral.status_changed` | Referral | Controlled status update | timeline, analytics, quality review |

Events are written in the same PostgreSQL transaction as the business mutation. The worker publishes them asynchronously. Consumers must be idempotent.
