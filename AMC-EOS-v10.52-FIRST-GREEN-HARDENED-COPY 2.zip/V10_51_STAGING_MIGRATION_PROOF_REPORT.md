# AMC-EOS v10.51 — Disposable PostgreSQL Staging Migration Proof

## What changed

v10.51 adds a database-backed proof harness for the hardened v10.50 staging migrations.

The new proof is designed to run only after Phase 1 passes against the same PostgreSQL database fingerprint and Git commit.

It creates deterministic synthetic legacy data across workforce, residents, finance, and analytics, then proves:

1. unsafe workforce mappings fail closed;
2. each domain dry-run completes cleanly on supported synthetic data;
3. the reviewed dry-run is converted into an exact apply-authorization manifest;
4. apply runs with commit/database/dry-run hash binding;
5. a second dry-run + second apply is idempotent;
6. the migration ledger contains one entry per migrated legacy source row;
7. canonical tables contain no duplicate synthetic rows;
8. exact business mappings are preserved;
9. synthetic proof data is cleaned from the disposable database afterward.

## Exact mappings asserted at runtime

- Workforce manager legacy ID -> canonical `EmployeeV64.id`.
- Workforce PART_TIME remains PART_TIME and ACTIVE remains ACTIVE.
- Credential ACTIVE remains ACTIVE.
- Training COMPLETE -> COMPLETED.
- Resident risk MEDIUM -> MODERATE.
- Resident risk MONITORED remains MONITORED.
- Resident funding SUSPENDED remains SUSPENDED.
- Finance vendor SUSPENDED remains SUSPENDED.
- Finance `NET 60` -> `paymentTermsDays = 60`.
- Analytics EXCEL report definition/run remains EXCEL.
- Analytics report-run rerun creates no duplicate.

## New runtime command

`pnpm migration:staging:proof`

The completion chain now includes this proof before live consolidation readiness.

## New CI workflow

`.github/workflows/staging-migration-proof.yml`

It provisions PostgreSQL 15, runs Phase 1, then runs the full staging migration proof.

## Validation performed in this environment

- v10.50 staging semantic validator: PASS — 88/88 checks + 10 required files.
- v10.51 migration proof validator: PASS — 22/22 checks + 6 required files.
- TypeScript syntax: PASS — 456 files.
- Prisma structure: PASS — 259 models / 117 enums.
- API integrity: PASS — 33 modules / 53 controllers / 331 routes / 0 issues.
- Provider integrity: PASS — 0 duplicate providers / unresolved dependencies / cycles / invalid exports.
- Staging proof workflow YAML: PASS.

## Runtime boundary

The actual disposable PostgreSQL staging proof was attempted locally and correctly returned BLOCKED because Phase 1 has not passed in this environment. The proof harness itself refuses to run until `release-evidence/phase1-runtime/phase1-runtime-proof.json` reports `status: passed`.

No staging migration apply is claimed as executed here.
