# Changelog v4.2

- Added migration 011 and finance hardening records.
- Added runnable invoice matching, reminders, asset controls, grant deliverables, and scorecard APIs.
- Added finance operations hardening end-to-end test.
- Added NestJS contracts and five Next.js finance workspaces.
