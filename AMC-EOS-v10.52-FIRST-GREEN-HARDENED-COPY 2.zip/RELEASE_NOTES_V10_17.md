# AMC-EOS v10.17 Release Notes

Added a direct dependency-backed API build workflow with PostgreSQL 15, exact pnpm version enforcement, real lockfile generation, TypeScript, Prisma, migrations, Jest, NestJS build, and per-stage evidence capture.
