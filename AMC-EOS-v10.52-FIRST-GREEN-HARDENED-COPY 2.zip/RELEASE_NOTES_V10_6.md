# AMC-EOS v10.6 Release Notes

- Hardened tenant-owned workflow, analytics, finance, workforce, and user mutations.
- Added a complete ID-only mutation classification gate.
- Documented narrowly scoped internal-worker and cryptographic-token exceptions.
- Prevented tenant administrators from globally deactivating shared user identities; membership activation is now tenant-scoped.
