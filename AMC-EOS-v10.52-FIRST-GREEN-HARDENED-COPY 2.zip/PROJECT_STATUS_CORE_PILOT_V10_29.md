# AMC-EOS Core Pilot Status — Service Loop

## What is now connected

The primary pilot workflow is implemented in source as one continuous path:

Login → Referral intake → Eligibility → Manager acceptance → Admission checklist → Bed reservation → Guardian/coordinator signatures → Admission completion → Canonical resident creation → DSP daily service note → Manager dashboard metric.

## Concrete changes in this build

- Production admissions API now has JWT protection and a tenant-scoped detail endpoint.
- Funding and guardian checklist decisions update admission readiness flags transactionally.
- Admission completion locks the admission row before creating a client/resident.
- Completion explicitly requires guardian and coordinator signature evidence.
- Admission workspace is interactive: checklist, bed reservation, signatures, completion, resident redirect.
- Daily service now has a first-class resident note endpoint with resident timeline, service timeline, outbox event, and audit evidence.
- DSP daily dashboard now lists active residents/tasks and records service notes.
- Manager dashboard now exposes open pilot referrals, active admissions, active residents, and daily notes in the last 24 hours.
- Golden-path Playwright source now extends through daily-service note submission.

## Executed offline evidence

- Core golden-path contract: 20/20 passed.
- TypeScript/TSX syntax transpilation: 420 files passed.
- API module integrity: 32 modules, 52 controllers, 307 routes, 0 issues.
- API provider integrity: 44 providers, 0 duplicates/unresolved/cycles.
- Tenant-safe mutation audit: 58 ID-only mutations, 54 safe, 4 approved internal exceptions, 0 unsafe.
- Dependency-free source tests: 17/17 passed.
- Pilot regression suite: 18/18 passed.
- Build-readiness preflight: 4/4 passed.

## What is not yet proven

A real dependency-backed build has not been executed in this environment. Therefore the following remain unverified: pnpm install, NestJS semantic compilation with actual dependencies, Prisma generation/validation, PostgreSQL migrations, Jest integration execution, and Playwright execution.

## Highest-value next work

1. Make the admission completion endpoint return a dedicated result contract containing resident and next actions.
2. Add PostgreSQL integration tests for the full accepted-referral → resident transaction.
3. Add a concurrent completion test proving one admission cannot create duplicate residents.
4. Add daily-service note HTTP integration tests with tenant isolation.
5. Add synthetic pilot seeding that guarantees an available home/bed and test credentials.
6. Execute the dependency-backed CI workflow and fix the first real compiler/runtime failures.
