# AMC-EOS v3.6 — Complete Referral Intake Vertical Slice

## Completed
- Full applicant demographics and referral source capture
- Requested service, current housing, county, urgency, and SLA due dates
- Automatic coordinator assignment, four blocking intake tasks, notifications, audit, activity, and search indexing
- Structured support-needs domains and funding/authorization checklist
- Intake command center and workspace screen foundations
- NestJS/Prisma/PostgreSQL source port and migration
- Eight executable pilot tests, all passing

## Internal pilot SLA defaults
URGENT 4 hours; HIGH 24 hours; ROUTINE 72 hours. These are configurable internal defaults, not statements of Washington law or contract requirements.
