import { hash } from 'bcryptjs';
import { AuditService } from '../../../src/audit/audit.service';
import { IdempotencyService } from '../../../src/idempotency/idempotency.service';
import { OutboxService } from '../../../src/outbox/outbox.service';
import { PrismaService } from '../../../src/prisma.service';
import { ProductionReferralsService } from '../../../src/production-referrals/production-referrals.service';

const DATABASE_URL = process.env.REFERRAL_INTEGRATION_DATABASE_URL ?? process.env.DATABASE_URL;
const describePostgres = DATABASE_URL ? describe : describe.skip;

describePostgres('production referrals PostgreSQL integration', () => {
  let prisma: PrismaService;
  let service: ProductionReferralsService;
  let tenantId = '';
  let otherTenantId = '';
  let userId = '';
  const runId = `referral-runtime-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;

  beforeAll(async () => {
    if (DATABASE_URL) process.env.DATABASE_URL = DATABASE_URL;
    prisma = new PrismaService();
    await prisma.$connect();
    service = new ProductionReferralsService(
      prisma,
      new IdempotencyService(prisma),
      new OutboxService(prisma),
      new AuditService(prisma),
    );

    const passwordHash = await hash('ReferralRuntime123!', 4);
    const tenant = await prisma.tenant.create({ data:{name:runId,slug:runId} });
    const other = await prisma.tenant.create({ data:{name:`${runId}-other`,slug:`${runId}-other`} });
    const user = await prisma.user.create({
      data:{email:`${runId}@example.test`,name:'Referral Runtime',passwordHash},
    });
    tenantId=tenant.id;
    otherTenantId=other.id;
    userId=user.id;
  });

  afterAll(async () => {
    if (!prisma) return;
    await prisma.$transaction([
      prisma.auditLog.deleteMany({where:{tenantId:{in:[tenantId,otherTenantId]}}}),
      prisma.outboxEvent.deleteMany({where:{tenantId:{in:[tenantId,otherTenantId]}}}),
      prisma.idempotencyKey.deleteMany({where:{tenantId:{in:[tenantId,otherTenantId]}}}),
      prisma.referralDuplicateV61.deleteMany({where:{tenantId}}),
      prisma.referralStatusHistoryV61.deleteMany({where:{tenantId}}),
      prisma.referralEligibilityV61.deleteMany({where:{tenantId}}),
      prisma.referralAssignmentV61.deleteMany({where:{tenantId}}),
      prisma.referralCommunicationV61.deleteMany({where:{tenantId}}),
      prisma.referralDocumentV61.deleteMany({where:{tenantId}}),
      prisma.referralScoreV61.deleteMany({where:{tenantId}}),
      prisma.referralV61.deleteMany({where:{tenantId}}),
      prisma.user.deleteMany({where:{id:userId}}),
      prisma.tenant.deleteMany({where:{id:{in:[tenantId,otherTenantId]}}}),
    ]);
    await prisma.$disconnect();
  });

  it('creates a referral idempotently and emits one audit/outbox record', async () => {
    const body = {
      firstName:'Synthetic',
      lastName:`Person-${runId}`,
      sourceName:'Runtime integration test',
      externalId:`external-${runId}`,
      urgency:'ROUTINE' as const,
    };

    const first = await service.create(tenantId,userId,`${runId}-idem`,body,'request-a');
    const replay = await service.create(tenantId,userId,`${runId}-idem`,body,'request-b');

    expect(replay.id).toBe(first.id);

    const [rows,outbox,audit] = await Promise.all([
      prisma.referralV61.count({where:{tenantId,externalId:body.externalId}}),
      prisma.outboxEvent.count({where:{tenantId,aggregateId:first.id,eventType:'referral.created'}}),
      prisma.auditLog.count({where:{tenantId,entityId:first.id,action:'CREATE'}}),
    ]);

    expect(rows).toBe(1);
    expect(outbox).toBe(1);
    expect(audit).toBe(1);
  });

  it('enforces tenant isolation on referral retrieval', async () => {
    const row = await service.create(tenantId,userId,`${runId}-tenant`,{
      firstName:'Tenant',
      lastName:`Isolation-${runId}`,
      sourceName:'Runtime integration test',
    },'tenant-request');

    await expect(service.get(otherTenantId,row.id)).rejects.toMatchObject({
      response: expect.objectContaining({code:'referral_not_found'}),
    });
  });
});
