export type MobileDashboard={shiftStatus:string;assignedResidents:number;openTasks:number;appointments:number;alerts:number;syncPending:number};
const base=((globalThis as any).process?.env?.EXPO_PUBLIC_API_URL as string | undefined) ?? 'http://localhost:4000/api';
export async function api<T>(path:string, token:string, init?:RequestInit):Promise<T>{const r=await fetch(base+path,{...init,headers:{'content-type':'application/json','authorization':`Bearer ${token}`,...init?.headers}});if(!r.ok)throw new Error(`API ${r.status}`);return r.json() as Promise<T>}
