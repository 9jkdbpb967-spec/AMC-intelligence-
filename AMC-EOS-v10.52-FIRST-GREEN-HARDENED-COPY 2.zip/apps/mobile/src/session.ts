import * as SecureStore from 'expo-secure-store';
const KEY='amc-eos-session';
export type MobileSession={accessToken:string;tenantSlug:string;userId:string};
export const sessionStore={get:async()=>{const v=await SecureStore.getItemAsync(KEY);return v?JSON.parse(v) as MobileSession:null},set:(s:MobileSession)=>SecureStore.setItemAsync(KEY,JSON.stringify(s)),clear:()=>SecureStore.deleteItemAsync(KEY)};
