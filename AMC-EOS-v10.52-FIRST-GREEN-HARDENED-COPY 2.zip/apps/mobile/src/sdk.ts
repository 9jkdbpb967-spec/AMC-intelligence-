import { AmcEosSdk } from '@amc-eos/api-client';
export interface MobileSdkSession {accessToken?:string;tenantId?:string;tenantSlug?:string;deviceId?:string;}
export const createMobileSdk=(baseUrl:string,getSession:()=>MobileSdkSession)=>new AmcEosSdk({
  baseUrl,
  timeoutMs:20_000,
  getAccessToken:()=>getSession().accessToken,
  getContext:()=>({tenantId:getSession().tenantId,tenantSlug:getSession().tenantSlug,correlationId:getSession().deviceId}),
  retry:{attempts:4,baseDelayMs:300,maxDelayMs:2500},
});
