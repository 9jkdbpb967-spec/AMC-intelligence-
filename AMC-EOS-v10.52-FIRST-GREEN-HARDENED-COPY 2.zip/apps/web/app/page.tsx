'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { api } from '../lib/api';

type DashboardData = {
  organizations: number; referrals: number; activeIntakes: number; openTasks: number;
  overdueTasks: number; meetings: number; homes: number; availableBeds: number;
  referralByStatus: Array<{ status: string; _count: { _all: number } }>;
  upcomingTasks: Array<{ id: string; title: string; organization?: { name: string }; referral?: { client: { firstName: string; lastName: string } } }>;
  corePilot: { referrals:number; admissions:number; residents:number; dailyNotesLast24Hours:number };
};
type ReadinessData = { status: 'ready' | 'degraded' | 'blocked'; summary: { ready: number; total: number } };

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [readiness, setReadiness] = useState<ReadinessData | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([api('/dashboard'), api('/core-readiness')])
      .then(([dashboard, core]) => { setData(dashboard); setReadiness(core); })
      .catch((caught) => setError(caught instanceof Error ? caught.message : 'Dashboard unavailable'));
  }, []);

  if (error) return <section><h1>Executive Dashboard</h1><div className="notice">Sign in first: {error}</div></section>;
  if (!data) return <p>Loading dashboard…</p>;

  const cards: Array<[string, number]> = [
    ['Referral organizations', data.organizations], ['Total referrals', data.referrals],
    ['Active intakes', data.activeIntakes], ['Open tasks', data.openTasks],
    ['Overdue tasks', data.overdueTasks], ['Meetings scheduled', data.meetings],
    ['Homes', data.homes], ['Available beds', data.availableBeds],
  ];

  return <>
    <section className="hero"><div><p className="eyebrow">EXECUTIVE COMMAND CENTER</p><h1>AMC Enterprise Operating System</h1><p>Referral relationships, intake activity, capacity, tasks, and operational readiness in one view.</p></div></section>
    <section className="grid">
      <article className="card"><span>Core workflow readiness</span><strong>{readiness ? `${readiness.summary.ready}/${readiness.summary.total}` : '—'}</strong><small>{readiness?.status ?? 'Checking'}</small><Link href="/core-readiness">View readiness details</Link></article>
      {cards.map(([label, value]) => <article className="card" key={label}><span>{label}</span><strong>{value}</strong></article>)}
    </section>
    <section className="columns"><article className="panel"><h2>Core pilot operations</h2><div className="row"><span>Open referrals</span><b>{data.corePilot.referrals}</b></div><div className="row"><span>Active admissions</span><b>{data.corePilot.admissions}</b></div><div className="row"><span>Active residents</span><b>{data.corePilot.residents}</b></div><div className="row"><span>Daily service notes (24h)</span><b>{data.corePilot.dailyNotesLast24Hours}</b></div><Link href="/daily-service/dsp">Open DSP daily dashboard</Link><br/><Link href="/daily-service/manager">Open manager operations</Link></article><article className="panel"><h2>Referral pipeline</h2>{data.referralByStatus.map((item) => <div className="row" key={item.status}><span>{item.status.replaceAll('_', ' ')}</span><b>{item._count._all}</b></div>)}</article></section>
    <section className="panel"><h2>Upcoming tasks</h2>{data.upcomingTasks.length ? data.upcomingTasks.map((item) => <div className="task" key={item.id}><b>{item.title}</b><small>{item.organization?.name ?? `${item.referral?.client.firstName ?? ''} ${item.referral?.client.lastName ?? ''}`}</small></div>) : <p className="muted">No tasks due in the next seven days.</p>}</section>
  </>;
}
