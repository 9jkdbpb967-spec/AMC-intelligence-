export default function Page(){return <main><a href="/finance">← Finance</a><h1>BUDGETS</h1><p>Tenant-scoped budgets workspace for AMC-EOS v4.1.</p></main>}
