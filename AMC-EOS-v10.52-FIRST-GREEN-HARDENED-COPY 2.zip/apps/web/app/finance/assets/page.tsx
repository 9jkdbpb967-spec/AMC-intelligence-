export default function Page(){return <main><a href="/finance">← Finance</a><h1>ASSETS</h1><p>Tenant-scoped assets workspace for AMC-EOS v4.1.</p></main>}
