export default function Page(){return <main><a href="/finance">← Finance</a><h1>GRANTS</h1><p>Tenant-scoped grants workspace for AMC-EOS v4.1.</p></main>}
