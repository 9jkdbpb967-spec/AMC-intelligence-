export default function Page(){return <main><a href="/finance">← Finance</a><h1>PURCHASING</h1><p>Tenant-scoped purchasing workspace for AMC-EOS v4.1.</p></main>}
