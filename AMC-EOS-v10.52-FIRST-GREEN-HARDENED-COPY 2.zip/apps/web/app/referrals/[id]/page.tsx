'use client';

import { FormEvent, useEffect, useState } from 'react';
import { Card, EmptyState, PageHeader, StatusBadge, Tabs } from '@amc-eos/ui';
import { api } from '../../../lib/api';

type Referral = {
  id:string; firstName:string; lastName:string; status:string; urgency:string; sourceName?:string|null;
  statusHistory:Array<unknown>; documents:Array<unknown>; communications:Array<unknown>;
  eligibility?:{ eligible:boolean; confidence:number; notes?:string|null } | null;
  duplicates:Array<{ id:string; candidateReferralId:string; score:number; matchedFields:string[]; status:string }>;
};

const nextStatus: Record<string, string | undefined> = {
  RECEIVED: 'ASSIGNED',
  DUPLICATE_REVIEW: 'ASSIGNED',
  ASSIGNED: 'ELIGIBILITY_REVIEW',
  ELIGIBILITY_REVIEW: 'MANAGER_REVIEW',
  DOCUMENT_COLLECTION: 'MANAGER_REVIEW',
  MANAGER_REVIEW: 'ACCEPTED',
};

export default function ReferralWorkspace({ params }:{ params:{ id:string } }) {
  const [referral, setReferral] = useState<Referral | null>(null);
  const [error, setError] = useState('');
  const [eligibility, setEligibility] = useState({ eligible:true, confidence:80, notes:'' });
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try { setReferral(await api(`/referrals-v61/${params.id}`)); }
    catch (err) { setError(err instanceof Error ? err.message : 'Unable to load referral'); }
  };
  useEffect(() => { void load(); }, [params.id]);

  async function advance(status:string) {
    setBusy(true); setError('');
    try {
      await api(`/referrals-v61/${params.id}/status`, { method:'PATCH', body:JSON.stringify({ status }) });
      await load();
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to update referral'); }
    finally { setBusy(false); }
  }

  async function saveEligibility(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    try {
      await api(`/referrals-v61/${params.id}/eligibility`, { method:'POST', body:JSON.stringify(eligibility) });
      await load();
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to save eligibility'); }
    finally { setBusy(false); }
  }

  if (!referral && !error) return <p>Loading referral…</p>;
  if (!referral) return <EmptyState title="Referral unavailable" description={error || 'The record may not exist or you may not have access.'} />;
  const suggested = nextStatus[referral.status];

  return <main>
    <PageHeader title={`${referral.firstName} ${referral.lastName}`} description="Referral intake and eligibility workspace" />
    {error && <p className="error" role="alert">{error}</p>}
    <Card>
      <StatusBadge>{referral.status}</StatusBadge>
      <p>Urgency: {referral.urgency}</p>
      <p>Source: {referral.sourceName ?? 'Not recorded'}</p>
      {suggested && <button disabled={busy} onClick={() => advance(suggested)}>Advance to {suggested.replaceAll('_',' ')}</button>}
      {referral.status === 'MANAGER_REVIEW' && <button disabled={busy} onClick={() => advance('DECLINED')}>Decline</button>}
      {referral.status === 'ACCEPTED' && <p><a className="button" href={`/referrals/${referral.id}/admission`}>Start admission</a></p>}
    </Card>
    <Card>
      <h2>Eligibility review</h2>
      <form onSubmit={saveEligibility} className="form-grid">
        <label>Decision<select value={eligibility.eligible ? 'yes':'no'} onChange={e => setEligibility({ ...eligibility, eligible:e.target.value === 'yes' })}><option value="yes">Eligible</option><option value="no">Not eligible</option></select></label>
        <label>Confidence<input type="number" min={0} max={100} value={eligibility.confidence} onChange={e => setEligibility({ ...eligibility, confidence:Number(e.target.value) })} /></label>
        <label className="full">Notes<textarea maxLength={2000} value={eligibility.notes} onChange={e => setEligibility({ ...eligibility, notes:e.target.value })} /></label>
        <button disabled={busy}>Save eligibility</button>
      </form>
      {referral.eligibility && <p>Current decision: <b>{referral.eligibility.eligible ? 'Eligible':'Not eligible'}</b> ({referral.eligibility.confidence}% confidence)</p>}
    </Card>
    {referral.duplicates.length > 0 && <Card><h2>Possible duplicates</h2>{referral.duplicates.map(d => <p key={d.id}>Candidate {d.candidateReferralId}: {d.score}% match ({d.matchedFields.join(', ') || 'matched fields pending'})</p>)}</Card>}
    <Tabs tabs={[
      { id:'timeline', label:'Timeline', content:<pre>{JSON.stringify(referral.statusHistory,null,2)}</pre> },
      { id:'documents', label:'Documents', content:<pre>{JSON.stringify(referral.documents,null,2)}</pre> },
      { id:'communications', label:'Communications', content:<pre>{JSON.stringify(referral.communications,null,2)}</pre> },
      { id:'eligibility', label:'Eligibility', content:<pre>{JSON.stringify(referral.eligibility,null,2)}</pre> },
    ]} />
  </main>;
}
