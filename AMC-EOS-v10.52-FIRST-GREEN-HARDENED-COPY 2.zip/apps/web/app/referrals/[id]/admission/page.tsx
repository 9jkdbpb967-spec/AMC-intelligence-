'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '../../../../lib/api';
import { PageHeader } from '../../../../components/PageHeader';

type Bed = { id:string; label:string; status:string };
type Home = { id:string; name:string; beds:Bed[] };
type ChecklistItem = { id:string; key:string; label:string; completed:boolean; required:boolean };
type Signature = { id:string; signerName:string; signerRole:string; signedAt:string };
type Reservation = { id:string; bedId:string; status:string; expiresAt:string };
type Admission = {
  id:string; referralId:string; status:string; residentId?:string|null; fundingVerified:boolean; guardianVerified:boolean;
  checklistItems:ChecklistItem[]; reservations:Reservation[]; signatures:Signature[];
};
type Referral = { id:string; status:string; firstName:string; lastName:string };

function newIdempotencyKey() {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto ? `admission-${crypto.randomUUID()}` : `admission-${Date.now()}`;
}

export default function AdmissionWorkspace({ params }:{ params:{ id:string } }) {
  const [referral,setReferral]=useState<Referral|null>(null);
  const [admission,setAdmission]=useState<Admission|null>(null);
  const [homes,setHomes]=useState<Home[]>([]);
  const [homeId,setHome]=useState('');
  const [bedId,setBed]=useState('');
  const [message,setMessage]=useState('');
  const [busy,setBusy]=useState(false);
  const [signerName,setSignerName]=useState('Pilot Guardian');
  const [signerRole,setSignerRole]=useState('GUARDIAN');
  const completionKey = useMemo(() => newIdempotencyKey(), []);

  async function load() {
    const currentReferral = await api(`/referrals-v61/${params.id}`);
    setReferral(currentReferral);
    const existing = await api('/admissions-v62');
    const summary = existing.find((row:Admission) => row.referralId === params.id) ?? null;
    setAdmission(summary ? await api(`/admissions-v62/${summary.id}`) : null);
    setHomes(await api('/homes'));
  }
  useEffect(() => { void load().catch(error => setMessage(error instanceof Error ? error.message : 'Unable to load admission workspace')); }, [params.id]);

  async function startAdmission() {
    setBusy(true); setMessage('');
    try {
      const row = await api('/admissions-v62',{method:'POST',body:JSON.stringify({referralId:params.id})});
      setAdmission(await api(`/admissions-v62/${row.id}`));
      setMessage('Admission started. Complete the required readiness steps below.');
    } catch(error) { setMessage(error instanceof Error ? error.message : 'Unable to start admission'); }
    finally { setBusy(false); }
  }

  async function toggleChecklist(item:ChecklistItem) {
    if (!admission) return;
    setBusy(true); setMessage('');
    try {
      await api(`/admissions-v62/${admission.id}/checklist/${item.id}`, { method:'PATCH', body:JSON.stringify({ checklistItemId:item.id, completed:!item.completed }) });
      setAdmission(await api(`/admissions-v62/${admission.id}`));
    } catch(error) { setMessage(error instanceof Error ? error.message : 'Unable to update checklist'); }
    finally { setBusy(false); }
  }

  async function reserve(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); if(!admission) return;
    setBusy(true); setMessage('');
    try {
      await api(`/admissions-v62/${admission.id}/reserve-bed`,{method:'POST',body:JSON.stringify({homeId,bedId,reservationMinutes:120})});
      setMessage('Bed reserved for two hours.');
      setAdmission(await api(`/admissions-v62/${admission.id}`));
      setHomes(await api('/homes'));
    } catch(error) { setMessage(error instanceof Error ? error.message : 'Unable to reserve bed'); }
    finally { setBusy(false); }
  }

  async function addSignature(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); if(!admission) return;
    setBusy(true); setMessage('');
    try {
      await api(`/admissions-v62/${admission.id}/signatures`, { method:'POST', body:JSON.stringify({ signerName, signerRole, documentVersion:'pilot-v1', signatureMethod:'ATTESTATION' }) });
      setAdmission(await api(`/admissions-v62/${admission.id}`));
      setSignerRole(signerRole === 'GUARDIAN' ? 'COORDINATOR' : signerRole);
    } catch(error) { setMessage(error instanceof Error ? error.message : 'Unable to record signature'); }
    finally { setBusy(false); }
  }

  async function completeAdmission() {
    if(!admission) return;
    setBusy(true); setMessage('');
    try {
      const completed = await api(`/admissions-v62/${admission.id}/complete`, { method:'POST', headers:{'idempotency-key':completionKey}, body:JSON.stringify({ idempotencyKey:completionKey, decisionNotes:'Core pilot admission completed.' }) });
      setAdmission(await api(`/admissions-v62/${admission.id}`));
      setMessage('Admission completed and resident record created.');
      if (completed.residentId) window.location.assign(`/residents/${completed.residentId}`);
    } catch(error) { setMessage(error instanceof Error ? error.message : 'Admission is not ready to complete'); }
    finally { setBusy(false); }
  }

  if(!referral) return <p>Loading admission workspace…</p>;
  const home=homes.find(row=>row.id===homeId);
  const activeReservation = admission?.reservations.find(row => row.status === 'ACTIVE' && new Date(row.expiresAt) > new Date());
  const signedRoles = new Set(admission?.signatures.map(row => row.signerRole) ?? []);
  const checklistComplete = admission?.checklistItems.filter(row => row.required).every(row => row.completed) ?? false;
  const readyToComplete = Boolean(admission && checklistComplete && admission.fundingVerified && admission.guardianVerified && activeReservation && signedRoles.has('GUARDIAN') && signedRoles.has('COORDINATOR'));

  return <main>
    <PageHeader title={`Admission — ${referral.firstName} ${referral.lastName}`} subtitle="Convert an accepted referral into a resident safely"/>
    {message&&<p role="alert">{message}</p>}
    {referral.status!=='ACCEPTED' && referral.status!=='CLOSED' && <section className="panel"><p>This referral must be accepted before an admission can start.</p></section>}
    {!admission && referral.status==='ACCEPTED' && <section className="panel"><h2>Start admission</h2><p>Create the admission checklist and begin placement review.</p><button disabled={busy} onClick={startAdmission}>Start admission</button></section>}
    {admission && <>
      <section className="panel"><h2>Admission status</h2><p><b>{admission.status}</b></p><h3>Required checklist</h3>{admission.checklistItems.map(item=><div className="list-item" key={item.id}><span>{item.completed?'✓':'○'} {item.label}</span><button disabled={busy||admission.status==='COMPLETED'} onClick={()=>toggleChecklist(item)}>{item.completed?'Mark incomplete':'Mark complete'}</button></div>)}</section>
      <form className="panel spaced" onSubmit={reserve}><h2>Reserve bed</h2><label>Home<select required value={homeId} onChange={e=>{setHome(e.target.value);setBed('')}}><option value="">Select home</option>{homes.map(row=><option key={row.id} value={row.id}>{row.name}</option>)}</select></label><label>Bed<select required value={bedId} onChange={e=>setBed(e.target.value)}><option value="">Select available bed</option>{home?.beds?.filter(row=>row.status==='AVAILABLE').map(row=><option key={row.id} value={row.id}>{row.label}</option>)}</select></label><button disabled={busy||!homeId||!bedId||admission.status==='COMPLETED'}>Reserve bed</button>{activeReservation&&<p>Active reservation expires {new Date(activeReservation.expiresAt).toLocaleString()}.</p>}</form>
      <form className="panel spaced" onSubmit={addSignature}><h2>Signature evidence</h2><label>Signer name<input required value={signerName} onChange={e=>setSignerName(e.target.value)}/></label><label>Signer role<select value={signerRole} onChange={e=>setSignerRole(e.target.value)}><option value="GUARDIAN">Guardian</option><option value="COORDINATOR">Coordinator</option></select></label><button disabled={busy||admission.status==='COMPLETED'}>Record signature</button><p>Guardian: {signedRoles.has('GUARDIAN')?'captured':'required'} · Coordinator: {signedRoles.has('COORDINATOR')?'captured':'required'}</p></form>
      <section className="panel"><h2>Admission readiness</h2><p>Checklist: {checklistComplete?'ready':'incomplete'} · Funding: {admission.fundingVerified?'verified':'required'} · Guardian: {admission.guardianVerified?'verified':'required'} · Bed: {activeReservation?'reserved':'required'} · Signatures: {signedRoles.has('GUARDIAN')&&signedRoles.has('COORDINATOR')?'ready':'required'}</p>{admission.residentId?<p><a className="button" href={`/residents/${admission.residentId}`}>Open resident</a></p>:<button disabled={busy||!readyToComplete} onClick={completeAdmission}>Complete admission and create resident</button>}</section>
    </>}
  </main>;
}
