'use client';
import { useEffect, useState } from 'react';
import { Card, PageHeader, StatusBadge, Table, EmptyState } from '@amc-eos/ui';
import { api } from '../../../lib/api';

type ReferralRow = { id:string; firstName:string; lastName:string; status:string; urgency:string; sourceName?:string|null };

export default function ReferralDashboard() {
  const [rows, setRows] = useState<ReferralRow[]>([]);
  const [error, setError] = useState('');
  useEffect(() => { api('/referrals-v61').then(setRows).catch(err => setError(err.message)); }, []);
  return <main>
    <PageHeader title="Referral Command Center" description="Tenant-scoped intake, eligibility and admission readiness." />
    <div className="amc-grid">
      <Card><strong>{rows.length}</strong><div>Active referrals</div></Card>
      <Card><strong>{rows.filter(r => r.status === 'MANAGER_REVIEW').length}</strong><div>Manager review</div></Card>
      <Card><strong>{rows.filter(r => r.status === 'ACCEPTED').length}</strong><div>Accepted</div></Card>
    </div>
    {error && <p className="error" role="alert">{error}</p>}
    {rows.length ? <Table caption="Referral pipeline"><thead><tr><th>Applicant</th><th>Status</th><th>Urgency</th><th>Source</th></tr></thead><tbody>{rows.map(r => <tr key={r.id}><td><a href={`/referrals/${r.id}`}>{r.firstName} {r.lastName}</a></td><td><StatusBadge>{r.status}</StatusBadge></td><td>{r.urgency}</td><td>{r.sourceName ?? '—'}</td></tr>)}</tbody></Table> : <EmptyState title="No referrals" description="Create a referral to begin the supported-living intake workflow." />}
  </main>;
}
