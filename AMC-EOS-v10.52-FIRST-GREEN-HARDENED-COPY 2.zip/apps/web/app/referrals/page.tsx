'use client';

import { useEffect, useState } from 'react';
import { api } from '../../lib/api';

const stages = ['RECEIVED','DUPLICATE_REVIEW','ASSIGNED','ELIGIBILITY_REVIEW','DOCUMENT_COLLECTION','MANAGER_REVIEW','ACCEPTED','WAITLISTED','DECLINED','CLOSED'];

type ReferralRow = {
  id: string;
  firstName: string;
  lastName: string;
  status: string;
  urgency: string;
  sourceName?: string | null;
};

export default function Referrals() {
  const [rows, setRows] = useState<ReferralRow[]>([]);
  const [message, setMessage] = useState('');

  const load = () => api('/referrals-v61').then(setRows).catch(error => setMessage(error.message));
  useEffect(() => { void load(); }, []);

  return (
    <section>
      <div className="page-header"><div><h1>Referral pipeline</h1><p>Move applicants through intake, eligibility, review and acceptance.</p></div><a className="button" href="/referrals/new">New referral</a></div>
      {message && <p className="error" role="alert">{message}</p>}
      <div className="kanban">
        {stages.map(stage => (
          <div className="lane" key={stage}>
            <h3>{stage.replaceAll('_', ' ')}</h3>
            {rows.filter(row => row.status === stage).map(row => (
              <article className="ticket" key={row.id}>
                <a href={`/referrals/${row.id}`}><b>{row.firstName} {row.lastName}</b></a>
                <small>{row.sourceName || 'Direct / family inquiry'}</small>
                <small>{row.urgency}</small>
              </article>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}
