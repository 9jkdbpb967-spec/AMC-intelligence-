'use client';

import { FormEvent, useState } from 'react';
import { api } from '../../../lib/api';
import { PageHeader } from '../../../components/PageHeader';

function createIdempotencyKey() {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? `referral-${crypto.randomUUID()}`
    : `referral-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export default function NewReferral() {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    email: '',
    phone: '',
    externalId: '',
    sourceName: '',
    urgency: 'ROUTINE',
  });
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setMessage('');
    try {
      const body = Object.fromEntries(
        Object.entries(form).filter(([, value]) => value !== ''),
      );
      const referral = await api('/referrals-v61', {
        method: 'POST',
        headers: { 'X-Idempotency-Key': createIdempotencyKey() },
        body: JSON.stringify(body),
      });
      window.location.href = `/referrals/${referral.id}`;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to create referral');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <PageHeader title="New referral" subtitle="Start the supported-living intake workflow" />
      <form className="panel form-grid" onSubmit={submit}>
        <label>First name<input required maxLength={120} value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} /></label>
        <label>Last name<input required maxLength={120} value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} /></label>
        <label>Date of birth<input type="date" value={form.dateOfBirth} onChange={e => setForm({ ...form, dateOfBirth: e.target.value })} /></label>
        <label>Urgency<select value={form.urgency} onChange={e => setForm({ ...form, urgency: e.target.value })}><option value="ROUTINE">Routine</option><option value="HIGH">High</option><option value="URGENT">Urgent</option></select></label>
        <label>Email<input type="email" maxLength={320} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></label>
        <label>Phone<input maxLength={40} value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></label>
        <label>Referral source<input maxLength={160} value={form.sourceName} onChange={e => setForm({ ...form, sourceName: e.target.value })} /></label>
        <label>External/client ID<input maxLength={120} value={form.externalId} onChange={e => setForm({ ...form, externalId: e.target.value })} /></label>
        <button disabled={submitting}>{submitting ? 'Creating…' : 'Create referral'}</button>
        {message && <p className="error" role="alert">{message}</p>}
      </form>
    </>
  );
}
