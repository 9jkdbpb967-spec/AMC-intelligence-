import { LoadingState } from '../components/states/page-states';
export default function Loading(){return <LoadingState label="Loading AMC-EOS"/>}
