'use client';

import { useEffect, useMemo, useState } from 'react';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/PageHeader';
import { StatusBadge } from '../../components/StatusBadge';

type ReadinessState = 'ready' | 'warning' | 'blocked';
type ReadinessCheck = {
  key: string;
  label: string;
  status: ReadinessState;
  detail: string;
  count?: number;
  code?: string;
  latencyMs?: number;
};
type ReadinessResponse = {
  status: 'ready' | 'degraded' | 'blocked';
  version: string;
  generatedAt: string;
  checks: ReadinessCheck[];
  summary: { ready: number; warning: number; blocked: number; total: number };
};

export default function CoreReadinessPage() {
  const [result, setResult] = useState<ReadinessResponse | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    setLoading(true);
    setError('');
    try {
      setResult(await api('/core-readiness'));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Core readiness could not be loaded.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void refresh(); }, []);

  const headline = useMemo(() => {
    if (!result) return 'Core readiness unavailable';
    return `${result.summary.ready} of ${result.summary.total} checks ready`;
  }, [result]);

  return (
    <section>
      <PageHeader
        title="Core workflow readiness"
        subtitle="Live tenant-scoped checks for the supported-living pilot."
        action={<button type="button" onClick={() => void refresh()} disabled={loading}>{loading ? 'Checking…' : 'Refresh'}</button>}
      />

      {error ? <div className="notice" role="alert">{error}</div> : null}

      <article className="panel" aria-live="polite">
        <StatusBadge value={result?.status ?? 'unknown'} />
        <h2>{loading ? 'Checking the core workflow…' : headline}</h2>
        {result ? <p>API version {result.version}. Generated {new Date(result.generatedAt).toLocaleString()}.</p> : null}
      </article>

      <section className="grid" aria-label="Core readiness checks">
        {(result?.checks ?? []).map((check) => (
          <article className="card" key={check.key}>
            <StatusBadge value={check.status} />
            <h2>{check.label}</h2>
            <p>{check.detail}</p>
            {typeof check.count === 'number' ? <p><strong>{check.count}</strong> records/capacity units detected</p> : null}
            {typeof check.latencyMs === 'number' ? <small>Latency: {check.latencyMs} ms</small> : null}
            {check.code ? <small>Code: {check.code}</small> : null}
          </article>
        ))}
      </section>
    </section>
  );
}
