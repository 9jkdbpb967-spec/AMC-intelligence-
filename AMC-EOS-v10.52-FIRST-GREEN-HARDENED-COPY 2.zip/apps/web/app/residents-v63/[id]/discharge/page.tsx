export default function Discharge(){return <main><h1>Resident Discharge</h1><p>Document reason, effective date, destination, follow-up, and release the occupied bed in one transaction.</p></main>}
