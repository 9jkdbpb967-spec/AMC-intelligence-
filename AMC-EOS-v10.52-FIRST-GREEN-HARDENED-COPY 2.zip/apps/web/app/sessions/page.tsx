'use client';
import {useEffect,useState} from 'react';
import {API_URL} from '../../lib/api';
export default function SessionsPage(){const[rows,setRows]=useState<any[]>([]);const[message,setMessage]=useState('Loading sessions…');
 async function load(){const token=localStorage.getItem('amc_token');const r=await fetch(`${API_URL}/api/sessions`,{headers:{Authorization:`Bearer ${token}`}});const d=await r.json();setRows(Array.isArray(d)?d:d.items||[]);setMessage(r.ok?'':'Unable to load sessions')}
 useEffect(()=>{void load()},[]);return <main><h1>Active sessions</h1><p>{message}</p><div className="card"><table><thead><tr><th>Created</th><th>Last seen</th><th>Device</th><th>Status</th></tr></thead><tbody>{rows.map(x=><tr key={x.id}><td>{x.createdAt}</td><td>{x.lastSeenAt||'—'}</td><td>{x.userAgent||'Unknown'}</td><td>{x.revokedAt?'Revoked':'Active'}</td></tr>)}</tbody></table></div></main>}
