'use client';
import { useEffect } from 'react';
import { ErrorState } from '../components/states/page-states';
export default function GlobalError({error,reset}:{error:Error&{digest?:string};reset:()=>void}){useEffect(()=>{console.error('AMC-EOS web error',{message:error.message,digest:error.digest})},[error]);return <section className="narrow"><ErrorState message={error.message||'The application could not complete this request.'} requestId={error.digest} onRetry={reset}/></section>}
