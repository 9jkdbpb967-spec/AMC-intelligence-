'use client';
import { useEffect, useState } from 'react';
export default function AICostPage(){
 const [d,setD]=useState<any>({});
 useEffect(()=>{fetch('/api/ai/cost-dashboard').then(r=>r.json()).then(setD).catch(()=>setD({}));},[]);
 return <main><h1>AI Cost & Usage</h1><dl><dt>Executions</dt><dd>{d.executions??0}</dd><dt>Input tokens</dt><dd>{d.inputTokens??d.input_tokens??0}</dd><dt>Output tokens</dt><dd>{d.outputTokens??d.output_tokens??0}</dd><dt>Estimated cost</dt><dd>{d.estimatedCost??d.estimated_cost??0}</dd><dt>Security events</dt><dd>{d.securityEvents??0}</dd></dl></main>;
}
