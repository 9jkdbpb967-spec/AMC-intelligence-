'use client';
import { useEffect, useState } from 'react';
export default function AIHealthPage(){
 const [rows,setRows]=useState<any[]>([]);
 useEffect(()=>{fetch('/api/ai/health').then(r=>r.json()).then(setRows).catch(()=>setRows([]));},[]);
 return <main><h1>AI Provider Health</h1><p>Provider availability, circuit state, and readiness.</p><table><thead><tr><th>Provider</th><th>Healthy</th><th>Circuit</th></tr></thead><tbody>{rows.map((r:any)=><tr key={r.providerId}><td>{r.providerKey}</td><td>{String(r.healthy)}</td><td>{r.circuitState}</td></tr>)}</tbody></table></main>;
}
