export default function Page(){return <main><h1>Scheduling & Coverage</h1><p>Assign shifts, detect overlap, process call-outs, and fill coverage gaps.</p></main>}
