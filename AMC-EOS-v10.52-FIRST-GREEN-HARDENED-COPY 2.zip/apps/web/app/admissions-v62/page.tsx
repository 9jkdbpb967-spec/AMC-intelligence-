import Link from 'next/link';
export default async function AdmissionsPage(){
  return <main><header><p>Admissions</p><h1>Admission Command Center</h1><p>Move accepted referrals through checklist, placement, signatures, approval, and resident creation.</p></header><section className="grid"><article><h2>Active admissions</h2><p>Review readiness, overdue checklist items, and expiring reservations.</p></article><article><h2>Bed reservations</h2><p>Reservations are temporary and revalidated under a database lock at completion.</p></article></section><Link href="/referrals-v61">Open accepted referrals</Link></main>;
}
