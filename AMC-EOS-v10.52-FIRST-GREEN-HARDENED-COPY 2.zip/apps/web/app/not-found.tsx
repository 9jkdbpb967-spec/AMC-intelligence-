import Link from 'next/link';
export default function NotFound(){return <section className="state-card narrow"><p className="eyebrow">404</p><h1>Page not found</h1><p className="muted">The requested AMC-EOS workspace does not exist or is unavailable.</p><Link className="button" href="/">Return to dashboard</Link></section>}
