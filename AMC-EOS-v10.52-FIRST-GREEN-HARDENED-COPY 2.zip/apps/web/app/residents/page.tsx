'use client';
import { useEffect, useState } from 'react';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/PageHeader';
import { StatusBadge } from '../../components/StatusBadge';
export default function ResidentsPage(){
 const [rows,setRows]=useState<any[]>([]); const [q,setQ]=useState(''); const [status,setStatus]=useState('');
 const load=()=>api(`/residents?q=${encodeURIComponent(q)}${status?`&status=${status}`:''}`).then(setRows);
 useEffect(()=>{load()},[]);
 return <><PageHeader title="Residents" subtitle="Active resident records, placement, status, risk, and operational history"/>
 <div className="toolbar"><input placeholder="Search resident number or preferred name" value={q} onChange={(e: { target: { value: string } })=>setQ(e.target.value)}/><select value={status} onChange={(e: { target: { value: string } })=>setStatus(e.target.value)}><option value="">All statuses</option><option>ACTIVE</option><option>INACTIVE</option><option>ARCHIVED</option></select><button onClick={load}>Search</button></div>
 <div className="table"><div className="thead resident-table"><span>Resident</span><span>Number</span><span>Status</span><span>Risk</span><span>Updated</span></div>{rows.map(r=><a className="trow resident-table" href={`/residents/${r.id}`} key={r.id}><span><b>{r.preferredName||'Resident profile'}</b><small>{r.id}</small></span><span>{r.residentNumber||'Pending'}</span><span><StatusBadge value={r.status}/></span><span>{r.riskLevel}</span><span>{new Date(r.updatedAt).toLocaleDateString()}</span></a>)}</div></>
}
