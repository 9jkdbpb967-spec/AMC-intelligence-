import type { ReactNode } from 'react';
import './styles.css';
import '@amc-eos/ui/styles.css';
import { ApplicationProviders } from '../providers/application-providers';
import { ApplicationShell } from '../components/shell/application-shell';
export const metadata={title:{default:'AMC-EOS',template:'%s | AMC-EOS'},description:'AMC Enterprise Operating System'};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body><ApplicationProviders><ApplicationShell>{children}</ApplicationShell></ApplicationProviders></body></html>}
