export function newIdempotencyKey(scope:string){
 const uuid=typeof crypto!=='undefined'&&'randomUUID'in crypto?crypto.randomUUID():`${Date.now()}-${Math.random().toString(16).slice(2)}`;
 return `${scope}:${uuid}`;
}
