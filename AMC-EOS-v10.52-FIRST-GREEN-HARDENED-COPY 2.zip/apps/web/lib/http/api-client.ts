import { publicEnvironment } from '../config/public-environment';
import { createRequestId } from './request-id';

export type ApiErrorBody = { message?: string; requestId?: string; code?: string; details?: unknown };
export class ApiError extends Error {
  constructor(public status: number, message: string, public requestId?: string, public code?: string, public details?: unknown) { super(message); }
}

export type SessionSnapshot = { accessToken?: string; tenantId?: string };
export type ApiClientOptions = {
  getSession?: () => SessionSnapshot;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
};

export class ApiClient {
  private readonly fetchImpl: typeof fetch;
  constructor(private readonly options: ApiClientOptions = {}) { this.fetchImpl = options.fetchImpl ?? fetch; }

  async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs ?? publicEnvironment.requestTimeoutMs);
    const headers = new Headers(init.headers);
    const session = this.options.getSession?.() ?? {};
    const requestId = createRequestId();
    headers.set('X-Request-Id', requestId);
    headers.set('X-Correlation-Id', headers.get('X-Correlation-Id') ?? requestId);
    headers.set('Accept', 'application/json');
    if (session.accessToken) headers.set('Authorization', `Bearer ${session.accessToken}`);
    if (session.tenantId) headers.set('X-Tenant-Id', session.tenantId);
    if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json');
    const normalized = path.startsWith('/api/') ? path : `/api${path.startsWith('/') ? path : `/${path}`}`;
    try {
      const response = await this.fetchImpl(`${publicEnvironment.apiUrl}${normalized}`, { ...init, headers, signal: controller.signal, cache: 'no-store' });
      if (!response.ok) {
        const body = await response.json().catch(() => ({ message: response.statusText })) as ApiErrorBody;
        throw new ApiError(response.status, body.message ?? 'Request failed', body.requestId ?? response.headers.get('X-Request-Id') ?? requestId, body.code, body.details);
      }
      return (response.status === 204 ? undefined : await response.json()) as T;
    } catch (error) {
      if (error instanceof ApiError) throw error;
      if (error instanceof DOMException && error.name === 'AbortError') throw new ApiError(408, 'Request timed out', requestId, 'request_timeout');
      throw new ApiError(0, error instanceof Error ? error.message : 'Network request failed', requestId, 'network_error');
    } finally { clearTimeout(timeout); }
  }
}
