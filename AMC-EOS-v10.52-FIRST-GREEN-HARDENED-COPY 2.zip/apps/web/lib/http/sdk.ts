import { AmcEosSdk } from '@amc-eos/api-client';
import { getPublicEnvironment } from '../config/public-environment';
export interface BrowserSdkSession {accessToken?:string;tenantId?:string;tenantSlug?:string;correlationId?:string;}
export const createBrowserSdk=(getSession:()=>BrowserSdkSession)=>new AmcEosSdk({
  baseUrl:getPublicEnvironment().apiUrl,
  getAccessToken:()=>getSession().accessToken,
  getContext:()=>({tenantId:getSession().tenantId,tenantSlug:getSession().tenantSlug,correlationId:getSession().correlationId}),
});
