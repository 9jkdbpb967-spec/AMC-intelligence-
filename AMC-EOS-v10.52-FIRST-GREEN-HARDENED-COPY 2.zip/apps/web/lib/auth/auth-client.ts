import { ApiClient } from '../http/api-client';
export type AuthSession = { accessToken:string; refreshToken:string; expiresInSeconds:number; sessionId:string; user:{id:string;email:string;name:string;role:string;tenantId:string;tenantSlug:string} };
export class AuthClient {
  constructor(private readonly api: ApiClient) {}
  login(input:{tenantSlug:string;email:string;password:string;deviceName?:string}) { return this.api.request<AuthSession>('/api/auth/login',{method:'POST',body:JSON.stringify(input)}); }
  refresh(refreshToken:string) { return this.api.request<AuthSession>('/api/auth/refresh',{method:'POST',body:JSON.stringify({refreshToken})}); }
  logout(refreshToken:string) { return this.api.request<{revoked:boolean}>('/api/auth/logout',{method:'POST',body:JSON.stringify({refreshToken})}); }
  me() { return this.api.request('/api/auth/me'); }
  forgotPassword(email:string,tenantSlug:string) { return this.api.request('/api/auth/password/forgot',{method:'POST',body:JSON.stringify({email,tenantSlug})}); }
  resetPassword(token:string,password:string) { return this.api.request('/api/auth/password/reset',{method:'POST',body:JSON.stringify({token,password})}); }
}
