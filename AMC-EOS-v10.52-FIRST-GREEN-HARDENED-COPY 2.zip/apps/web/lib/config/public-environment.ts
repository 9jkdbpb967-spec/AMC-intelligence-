export type PublicEnvironment = {
  apiUrl: string;
  appName: string;
  appVersion: string;
  environment: 'development' | 'test' | 'staging' | 'production';
  requestTimeoutMs: number;
};

function requireUrl(name: string, value: string): string {
  try { return new URL(value).toString().replace(/\/$/, ''); }
  catch { throw new Error(`${name} must be an absolute URL`); }
}

export function loadPublicEnvironment(source: Record<string, string | undefined> = process.env): PublicEnvironment {
  const environment = (source.NEXT_PUBLIC_APP_ENV ?? 'development') as PublicEnvironment['environment'];
  if (!['development','test','staging','production'].includes(environment)) {
    throw new Error('NEXT_PUBLIC_APP_ENV must be development, test, staging, or production');
  }
  const timeout = Number(source.NEXT_PUBLIC_REQUEST_TIMEOUT_MS ?? 15000);
  if (!Number.isInteger(timeout) || timeout < 1000 || timeout > 120000) {
    throw new Error('NEXT_PUBLIC_REQUEST_TIMEOUT_MS must be between 1000 and 120000');
  }
  return {
    apiUrl: requireUrl('NEXT_PUBLIC_API_URL', source.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000'),
    appName: source.NEXT_PUBLIC_APP_NAME ?? 'AMC-EOS',
    appVersion: source.NEXT_PUBLIC_APP_VERSION ?? '5.4.0-alpha',
    environment,
    requestTimeoutMs: timeout,
  };
}

export const publicEnvironment = loadPublicEnvironment();

export function getPublicEnvironment(): PublicEnvironment {
  return publicEnvironment;
}

