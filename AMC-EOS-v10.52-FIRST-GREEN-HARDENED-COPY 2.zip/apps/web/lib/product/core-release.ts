export type CoreRole = 'ADMIN' | 'MANAGER' | 'DSP' | 'FINANCE' | 'EXECUTIVE';
export type CoreModuleKey =
  | 'dashboard'
  | 'referrals'
  | 'admissions'
  | 'residents'
  | 'dailyService'
  | 'workforce'
  | 'coreReadiness'
  | 'finance'
  | 'analytics'
  | 'ai'
  | 'integrations';

export type CoreModule = {
  enabled: boolean;
  roles: CoreRole[];
};

export const coreRelease = {
  version: '10.27.0-alpha.0',
  modules: {
    dashboard: { enabled: true, roles: ['ADMIN', 'MANAGER', 'DSP'] },
    referrals: { enabled: true, roles: ['ADMIN', 'MANAGER'] },
    admissions: { enabled: true, roles: ['ADMIN', 'MANAGER'] },
    residents: { enabled: true, roles: ['ADMIN', 'MANAGER', 'DSP'] },
    dailyService: { enabled: true, roles: ['ADMIN', 'MANAGER', 'DSP'] },
    workforce: { enabled: true, roles: ['ADMIN', 'MANAGER'] },
    coreReadiness: { enabled: true, roles: ['ADMIN', 'MANAGER'] },
    finance: { enabled: false, roles: ['ADMIN', 'FINANCE'] },
    analytics: { enabled: false, roles: ['ADMIN', 'EXECUTIVE'] },
    ai: { enabled: false, roles: ['ADMIN', 'MANAGER'] },
    integrations: { enabled: false, roles: ['ADMIN'] },
  } satisfies Record<CoreModuleKey, CoreModule>,
} as const;

export function isCoreModuleVisible(
  moduleKey: CoreModuleKey,
  roles: readonly string[],
): boolean {
  const module = coreRelease.modules[moduleKey];
  return module.enabled && module.roles.some((role) => roles.includes(role));
}
