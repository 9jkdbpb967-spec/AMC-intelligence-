export const API_URL=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export function token(){if(typeof window==='undefined')return '';return localStorage.getItem('amc_token')||''}

export async function api(path:string,options:RequestInit={}){
  const headers=new Headers(options.headers);
  const isForm=typeof FormData!=='undefined' && options.body instanceof FormData;
  if(!isForm && options.body) headers.set('Content-Type','application/json');
  const t=token(); if(t) headers.set('Authorization',`Bearer ${t}`);
  const normalized=path.startsWith('/api/')?path:`/api${path.startsWith('/')?path:`/${path}`}`;
  const response=await fetch(`${API_URL}${normalized}`,{...options,headers,cache:'no-store'});
  if(!response.ok){
    const error=await response.json().catch(()=>({message:response.statusText}));
    throw new Error(`${error.message||'Request failed'}${error.requestId?` (request ${error.requestId})`:''}`);
  }
  return response.status===204?null:response.json();
}
