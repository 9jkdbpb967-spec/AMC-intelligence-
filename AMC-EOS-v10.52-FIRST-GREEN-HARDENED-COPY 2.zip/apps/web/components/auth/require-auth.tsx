'use client';
import { useEffect, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useSession } from '../../providers/session-provider';
export function RequireAuth({children,permission}:{children:ReactNode;permission?:string}){
 const {session,hasPermission}=useSession(); const router=useRouter(); const path=usePathname();
 useEffect(()=>{if(!session)router.replace(`/login?next=${encodeURIComponent(path)}`);else if(permission&&!hasPermission(permission))router.replace('/forbidden')},[session,permission,hasPermission,path,router]);
 if(!session||(permission&&!hasPermission(permission))) return <p role="status">Checking access…</p>;
 return <>{children}</>;
}
