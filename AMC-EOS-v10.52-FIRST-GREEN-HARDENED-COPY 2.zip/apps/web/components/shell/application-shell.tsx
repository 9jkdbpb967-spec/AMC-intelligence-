import type { ReactNode } from 'react';
'use client';
import Link from 'next/link';
import { Navigation } from './navigation';
import { useSession } from '../../providers/session-provider';
import { publicEnvironment } from '../../lib/config/public-environment';
export function ApplicationShell({children}:{children:ReactNode}){const{session,signOut}=useSession();return <><a className="skip-link" href="#main-content">Skip to main content</a><header className="app-header"><div className="brand"><Link href="/"><strong>{publicEnvironment.appName}</strong></Link><span className="version">{publicEnvironment.appVersion}</span></div><Navigation/><div className="session-summary">{session?<><span>{session.tenantName??session.tenantId}</span><button className="quiet" onClick={signOut}>Sign out</button></>:<Link href="/login">Sign in</Link>}</div></header><main id="main-content" tabIndex={-1}>{children}</main></>}
