'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from '../../providers/session-provider';
import {
  isCoreModuleVisible,
  type CoreModuleKey,
} from '../../lib/product/core-release';

type Item = {
  href: string;
  label: string;
  module: CoreModuleKey;
  permission?: string;
};

const items: Item[] = [
  { href: '/', label: 'Dashboard', module: 'dashboard' },
  { href: '/referrals', label: 'Referrals', module: 'referrals', permission: 'referral.read' },
  { href: '/admissions-v62', label: 'Admissions', module: 'admissions', permission: 'admission.read' },
  { href: '/residents', label: 'Residents', module: 'residents', permission: 'resident.read' },
  { href: '/daily-service', label: 'Daily Service', module: 'dailyService', permission: 'daily_service.read' },
  { href: '/workforce', label: 'Workforce', module: 'workforce', permission: 'workforce.read' },
  { href: '/core-readiness', label: 'Core Readiness', module: 'coreReadiness' },
];

export function Navigation() {
  const pathname = usePathname();
  const { session } = useSession();
  const roles = session?.user.roles ?? [];
  const permissions = session?.user.permissions ?? [];
  const visible = items.filter(
    (item) =>
      isCoreModuleVisible(item.module, roles) &&
      (!item.permission || permissions.includes(item.permission)),
  );

  return (
    <nav aria-label="Primary navigation">
      {visible.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          aria-current={pathname === item.href ? 'page' : undefined}
          className={pathname === item.href ? 'active' : ''}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
