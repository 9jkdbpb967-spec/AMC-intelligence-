'use client';
import { createContext, useContext, useMemo, type ReactNode } from 'react';
import { ApiClient } from '../lib/http/api-client';
import { useSession } from './session-provider';
const ApiContext=createContext<ApiClient|null>(null);
export function ApiProvider({children}:{children:ReactNode}){const{session}=useSession();const client=useMemo(()=>new ApiClient({getSession:()=>({accessToken:session?.accessToken,tenantId:session?.tenantId})}),[session]);return <ApiContext.Provider value={client}>{children}</ApiContext.Provider>}
export function useApi(){const value=useContext(ApiContext);if(!value)throw new Error('useApi must be used inside ApiProvider');return value}
