import type { ReactNode } from 'react';
'use client';
import { SessionProvider } from './session-provider';
import { ApiProvider } from './api-provider';
export function ApplicationProviders({children}:{children:ReactNode}){return <SessionProvider><ApiProvider>{children}</ApiProvider></SessionProvider>}
