'use client';
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
export type SessionUser = { id: string; email: string; displayName?: string; roles: string[]; permissions: string[] };
export type SessionState = { accessToken: string; tenantId: string; tenantName?: string; user: SessionUser };
type SessionContextValue = { session: SessionState | null; setSession: (value: SessionState | null) => void; signOut: () => void; hasPermission: (permission: string) => boolean; hasRole: (role: string) => boolean };
const SessionContext = createContext<SessionContextValue | null>(null);
const STORAGE_KEY='amc_eos_session';
function readInitial(): SessionState | null { if(typeof window==='undefined') return null; try{return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? 'null')}catch{return null} }
export function SessionProvider({children}:{children:ReactNode}){
 const [sessionState,setSessionState]=useState<SessionState|null>(readInitial());
 const setSession=useCallback((value:SessionState|null)=>{setSessionState(value);if(typeof window!=='undefined'){if(value)localStorage.setItem(STORAGE_KEY,JSON.stringify(value));else localStorage.removeItem(STORAGE_KEY)}},[]);
 const signOut=useCallback(()=>setSession(null),[setSession]);
 const value=useMemo(()=>({session:sessionState,setSession,signOut,hasPermission:(p:string)=>Boolean(sessionState?.user.permissions.includes(p)),hasRole:(r:string)=>Boolean(sessionState?.user.roles.includes(r))}),[sessionState,setSession,signOut]);
 return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}
export function useSession(){const value=useContext(SessionContext);if(!value)throw new Error('useSession must be used inside SessionProvider');return value}
