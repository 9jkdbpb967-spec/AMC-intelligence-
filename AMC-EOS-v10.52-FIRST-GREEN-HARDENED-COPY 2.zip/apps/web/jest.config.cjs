module.exports={testEnvironment:'jsdom',roots:['<rootDir>/app/tests'],transform:{'^.+\\.tsx?$':['ts-jest',{tsconfig:'<rootDir>/tsconfig.json'}]},moduleFileExtensions:['ts','tsx','js','jsx']};
