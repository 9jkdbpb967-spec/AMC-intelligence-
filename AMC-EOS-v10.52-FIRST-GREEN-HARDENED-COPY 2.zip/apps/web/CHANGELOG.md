# Changelog — @amc-eos/web

## 8.3.0-alpha.0

- Public API baseline established; no detected API changes.
