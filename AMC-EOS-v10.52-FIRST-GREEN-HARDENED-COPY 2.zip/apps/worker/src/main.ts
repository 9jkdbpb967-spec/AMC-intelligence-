import {PrismaClient} from '@prisma/client';const prisma=new PrismaClient();
async function run(){const events=await prisma.outboxEvent.findMany({where:{status:'PENDING',availableAt:{lte:new Date()}},orderBy:{createdAt:'asc'},take:25});for(const event of events){try{await prisma.outboxEvent.update({where:{id:event.id},data:{status:'PUBLISHED',publishedAt:new Date(),attempts:{increment:1}}})}catch(error){await prisma.outboxEvent.update({where:{id:event.id},data:{status:'FAILED',lastError:String(error),attempts:{increment:1}}})}}}
run().finally(()=>prisma.$disconnect());
