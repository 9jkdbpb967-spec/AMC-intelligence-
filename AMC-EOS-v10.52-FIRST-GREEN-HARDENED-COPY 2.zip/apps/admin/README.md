# Admin application placeholder
Future platform and tenant administration application. It must remain separate from normal operational administration and require elevated authorization.
