# REVIEW ME FIRST — AMC-EOS v10.52

Start with `V10_52_FIRST_GREEN_EXECUTION_REPORT.md`.

Critical files:

- `.github/workflows/first-green.yml`
- `.github/workflows/phase1-runtime-proof.yml`
- `.github/workflows/staging-migration-proof.yml`
- `.github/workflows/completion-readiness.yml`
- `scripts/runtime/run_phase1_runtime_proof.py`
- `scripts/runtime/run_staging_migration_proof.py`
- `scripts/quality/validate-v1051-staging-migration-proof.py`
- `package.json`
- `release-evidence/v10.52/phase1-local-attempt.log`

The repository is still runtime-unverified locally. The next decisive action is to run **AMC-EOS First Green** in GitHub Actions.
