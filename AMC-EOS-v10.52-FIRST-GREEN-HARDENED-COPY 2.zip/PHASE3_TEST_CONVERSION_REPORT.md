# AMC-EOS v10.44 — Phase 3 Test Conversion

## Goal

Restore meaning to the word PASS.

## Changes

1. Validation assets are now classified as:
   - executed unit test;
   - executed integration test;
   - executed E2E test;
   - static contract check;
   - tooling/runtime check.
2. The old source-text vertical-slice validators remain useful, but are explicitly exposed as `static:domain-contracts`.
3. New real PostgreSQL integration tests cover:
   - V61 referral idempotency, audit/outbox evidence, and tenant isolation;
   - V64 workforce employee readiness, shift assignment, clock-in/out, and tenant isolation.
4. Existing core-pilot PostgreSQL integration remains the real admissions/resident proof source.
5. Existing Playwright core/manager workflows remain E2E proof sources.
6. `release:proof` creates a small command-backed evidence tree with exact commands, exit codes, commit, timestamps, raw-log hashes, and a release attestation.

## Runtime boundary

The new executed test sources cannot be run in this environment without pnpm/PostgreSQL. They are not reported as passing until the release-proof runner actually executes them.


## v10.45 continuation

Additional executed test sources now cover:
- Finance V65: vendor -> budget -> purchase request -> manager approval -> finance approval -> PO -> receipt -> invoice -> match, plus tenant isolation.
- Analytics V66: metric -> certification -> snapshot -> scorecard/CSV, report subscription, and tenant-scoped retrieval.
- Legacy route cutover guard: runtime Jest coverage verifies enabled/disabled behavior of the decorated guard.

These suites are now part of `release:proof`; they remain unverified until a dependency-backed PostgreSQL run executes them.
