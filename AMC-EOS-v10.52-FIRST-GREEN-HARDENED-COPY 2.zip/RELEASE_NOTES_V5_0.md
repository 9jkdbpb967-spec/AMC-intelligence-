# AMC-EOS v5.0 Alpha — Repository Foundation

This release adds shared repository configuration, four platform packages, CI and release workflows, infrastructure profiles, monitoring configuration, release manifests, test-domain folders, and architecture decisions. It does not claim successful dependency installation, TypeScript compilation, Prisma CLI validation, container startup, or production deployment until those commands run in a compatible engineering environment.
