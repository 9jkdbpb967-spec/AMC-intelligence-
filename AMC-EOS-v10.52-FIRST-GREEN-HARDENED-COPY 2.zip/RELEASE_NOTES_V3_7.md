# AMC-EOS v3.7 Release Notes

Sprint 35 implements intake operations and document completion in the runnable pilot runtime, with production-port contracts and handoff documentation.
