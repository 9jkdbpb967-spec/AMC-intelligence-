# AMC-EOS Enterprise v2.2 — Workforce Readiness & Scheduling Controls

## Delivered
- Role-aware readiness rules and evaluations
- Credential and training assignment gates
- Shift overlap and overtime validation
- Recurring shift series
- Call-out and coverage workflow
- Shift swap requests
- Schedule conflict records
- Schedule approvals
- Workforce reminder records
- Readiness and scheduling dashboards

## Release gates
Prisma validation, reviewed migration SQL, TypeScript compilation, Jest, two-tenant PostgreSQL tests, Playwright, Docker startup, accessibility, and security review remain mandatory.
