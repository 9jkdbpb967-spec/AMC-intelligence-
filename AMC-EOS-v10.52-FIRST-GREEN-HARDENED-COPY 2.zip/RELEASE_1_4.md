# AMC-EOS Enterprise v1.4 — Pilot Controls

This release adds:

- Intake document checklist APIs and interface
- Referral activity timeline APIs and interface
- Editable home-bed status controls
- Idempotency persistence foundation
- OpenAPI typed-client generation script
- Playwright smoke-test project
- Tenant-isolation integration-test contracts
- Database migration, testing, and AI handoff blueprints

## Release gate

This is a development release. It is not approved for resident, medical, Medicaid, employee, or financial information until migrations, compilation, two-tenant isolation tests, secure deployment, backup restoration, and formal security review pass.
