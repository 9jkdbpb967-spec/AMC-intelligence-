CREATE TABLE IF NOT EXISTS shift_handoffs (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, shift_id TEXT, home_id TEXT NOT NULL,
 outgoing_employee_id TEXT NOT NULL, incoming_employee_id TEXT, summary TEXT NOT NULL,
 resident_alerts TEXT, outstanding_tasks TEXT, supervisor_notes TEXT,
 status TEXT NOT NULL DEFAULT 'DRAFT', submitted_at TEXT, acknowledged_at TEXT,
 acknowledged_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_shift_handoffs_tenant_home ON shift_handoffs(tenant_id,home_id,created_at);

CREATE TABLE IF NOT EXISTS resident_daily_tasks (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, resident_id TEXT NOT NULL, home_id TEXT NOT NULL,
 title TEXT NOT NULL, task_type TEXT NOT NULL DEFAULT 'GENERAL', scheduled_at TEXT,
 due_at TEXT, recurrence_rule TEXT, priority TEXT NOT NULL DEFAULT 'NORMAL',
 status TEXT NOT NULL DEFAULT 'OPEN', assigned_employee_id TEXT, completed_at TEXT,
 completed_by TEXT, notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_resident_tasks_tenant_due ON resident_daily_tasks(tenant_id,status,due_at);

CREATE TABLE IF NOT EXISTS resident_appointments (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, resident_id TEXT NOT NULL,
 appointment_type TEXT NOT NULL, provider_name TEXT, location TEXT,
 starts_at TEXT NOT NULL, ends_at TEXT, transportation_required INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'SCHEDULED', outcome TEXT, follow_up TEXT,
 created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_resident_appointments_tenant_start ON resident_appointments(tenant_id,starts_at,status);

CREATE TABLE IF NOT EXISTS guardian_communications (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, resident_id TEXT NOT NULL,
 contact_name TEXT NOT NULL, relationship TEXT, channel TEXT NOT NULL,
 direction TEXT NOT NULL, subject TEXT, summary TEXT NOT NULL,
 follow_up_at TEXT, created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_guardian_comms_resident ON guardian_communications(tenant_id,resident_id,created_at);

CREATE TABLE IF NOT EXISTS quick_incidents (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, resident_id TEXT, home_id TEXT NOT NULL,
 category TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'LOW', occurred_at TEXT NOT NULL,
 summary TEXT NOT NULL, immediate_action TEXT, status TEXT NOT NULL DEFAULT 'REPORTED',
 reported_by TEXT NOT NULL, full_incident_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_quick_incidents_tenant_status ON quick_incidents(tenant_id,status,occurred_at);

CREATE TABLE IF NOT EXISTS shift_alerts (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, home_id TEXT NOT NULL, resident_id TEXT,
 alert_type TEXT NOT NULL, message TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'INFO',
 starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at TEXT, acknowledged_at TEXT,
 acknowledged_by TEXT, created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_shift_alerts_active ON shift_alerts(tenant_id,home_id,acknowledged_at,expires_at);
