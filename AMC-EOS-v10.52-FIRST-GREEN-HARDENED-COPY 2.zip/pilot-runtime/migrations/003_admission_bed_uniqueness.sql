PRAGMA foreign_keys = ON;
-- A bed may appear in only one admission in the pilot reference runtime.
-- A future discharge/reassignment model should replace this with active occupancy periods.
CREATE UNIQUE INDEX IF NOT EXISTS uq_admissions_bed ON admissions(bed_id);
