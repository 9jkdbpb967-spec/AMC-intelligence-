CREATE TABLE IF NOT EXISTS vendors (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, name TEXT NOT NULL, category TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE',
 email TEXT, phone TEXT, payment_terms TEXT, preferred INTEGER NOT NULL DEFAULT 0, compliance_status TEXT NOT NULL DEFAULT 'PENDING',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,name), FOREIGN KEY(tenant_id) REFERENCES tenants(id)
);
CREATE TABLE IF NOT EXISTS vendor_contacts (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, vendor_id TEXT NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 title TEXT, email TEXT, phone TEXT, primary_contact INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(vendor_id) REFERENCES vendors(id)
);
CREATE TABLE IF NOT EXISTS vendor_compliance_items (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, vendor_id TEXT NOT NULL, item_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
 reference_number TEXT, expires_at TEXT, document_key TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(vendor_id) REFERENCES vendors(id)
);
CREATE TABLE IF NOT EXISTS budgets (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, name TEXT NOT NULL, scope_type TEXT NOT NULL, scope_id TEXT, fiscal_year INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'DRAFT', approved_amount_cents INTEGER NOT NULL DEFAULT 0, committed_amount_cents INTEGER NOT NULL DEFAULT 0,
 actual_amount_cents INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,name,fiscal_year)
);
CREATE TABLE IF NOT EXISTS purchase_requests (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, request_number TEXT NOT NULL, title TEXT NOT NULL, justification TEXT,
 home_id TEXT, budget_id TEXT, vendor_id TEXT, status TEXT NOT NULL DEFAULT 'SUBMITTED', requested_by_user_id TEXT NOT NULL,
 requested_amount_cents INTEGER NOT NULL DEFAULT 0, approved_amount_cents INTEGER, needed_by TEXT, approved_by_user_id TEXT, approved_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,request_number), FOREIGN KEY(budget_id) REFERENCES budgets(id), FOREIGN KEY(vendor_id) REFERENCES vendors(id)
);
CREATE TABLE IF NOT EXISTS purchase_request_items (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, purchase_request_id TEXT NOT NULL, description TEXT NOT NULL,
 quantity REAL NOT NULL DEFAULT 1, unit_price_cents INTEGER NOT NULL DEFAULT 0, category TEXT,
 FOREIGN KEY(purchase_request_id) REFERENCES purchase_requests(id)
);
CREATE TABLE IF NOT EXISTS purchase_orders (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, po_number TEXT NOT NULL, purchase_request_id TEXT NOT NULL, vendor_id TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'ISSUED', total_cents INTEGER NOT NULL DEFAULT 0, issued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 expected_at TEXT, closed_at TEXT, UNIQUE(tenant_id,po_number), FOREIGN KEY(purchase_request_id) REFERENCES purchase_requests(id)
);
CREATE TABLE IF NOT EXISTS receiving_records (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, purchase_order_id TEXT NOT NULL, received_by_user_id TEXT NOT NULL,
 received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, status TEXT NOT NULL DEFAULT 'RECEIVED', notes TEXT,
 FOREIGN KEY(purchase_order_id) REFERENCES purchase_orders(id)
);
CREATE TABLE IF NOT EXISTS assets (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, asset_tag TEXT NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'ACTIVE', serial_number TEXT, vendor_id TEXT, purchase_order_id TEXT, home_id TEXT,
 purchase_date TEXT, purchase_cost_cents INTEGER, assigned_to_type TEXT, assigned_to_id TEXT, next_maintenance_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,asset_tag)
);
CREATE TABLE IF NOT EXISTS asset_maintenance (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, asset_id TEXT NOT NULL, maintenance_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'SCHEDULED',
 scheduled_at TEXT NOT NULL, completed_at TEXT, cost_cents INTEGER, notes TEXT, FOREIGN KEY(asset_id) REFERENCES assets(id)
);
CREATE TABLE IF NOT EXISTS grants (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, name TEXT NOT NULL, funder TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PROSPECT',
 requested_amount_cents INTEGER, awarded_amount_cents INTEGER, application_due_at TEXT, award_start_at TEXT, award_end_at TEXT,
 reporting_due_at TEXT, owner_user_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS grant_milestones (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, grant_id TEXT NOT NULL, title TEXT NOT NULL, due_at TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'OPEN', completed_at TEXT, FOREIGN KEY(grant_id) REFERENCES grants(id)
);
CREATE INDEX IF NOT EXISTS idx_vendor_tenant_status ON vendors(tenant_id,status);
CREATE INDEX IF NOT EXISTS idx_pr_tenant_status ON purchase_requests(tenant_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_po_tenant_status ON purchase_orders(tenant_id,status,issued_at);
CREATE INDEX IF NOT EXISTS idx_asset_tenant_status ON assets(tenant_id,status,category);
CREATE INDEX IF NOT EXISTS idx_grant_tenant_status ON grants(tenant_id,status,reporting_due_at);
