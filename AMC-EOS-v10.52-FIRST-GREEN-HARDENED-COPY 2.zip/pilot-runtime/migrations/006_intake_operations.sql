
CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  category TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,name)
);
CREATE TABLE IF NOT EXISTS organization_contacts (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  title TEXT,
  email TEXT,
  phone TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS intake_document_rules (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  program_code TEXT NOT NULL,
  item_type TEXT NOT NULL,
  label TEXT NOT NULL,
  required INTEGER NOT NULL DEFAULT 1,
  blocking INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,program_code,item_type)
);
CREATE TABLE IF NOT EXISTS intake_documents (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  item_type TEXT NOT NULL,
  file_name TEXT NOT NULL,
  storage_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING_SCAN',
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  verified_by TEXT REFERENCES users(id),
  verified_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS referral_communications (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  direction TEXT NOT NULL,
  channel TEXT NOT NULL,
  subject TEXT,
  summary TEXT NOT NULL,
  contact_name TEXT,
  contact_value TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS intake_meetings (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  meeting_type TEXT NOT NULL DEFAULT 'INTAKE',
  scheduled_at TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 60,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'SCHEDULED',
  outcome TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS screening_outcomes (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  outcome TEXT NOT NULL,
  reason_code TEXT,
  rationale TEXT,
  decided_by TEXT NOT NULL REFERENCES users(id),
  decided_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS waitlist_entries (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  priority INTEGER NOT NULL DEFAULT 100,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  review_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,referral_id)
);
CREATE TABLE IF NOT EXISTS duplicate_referral_matches (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  possible_duplicate_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  score INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,referral_id,possible_duplicate_id)
);
ALTER TABLE referrals ADD COLUMN source_organization_id TEXT REFERENCES organizations(id);
ALTER TABLE referrals ADD COLUMN source_contact_id TEXT REFERENCES organization_contacts(id);
ALTER TABLE referrals ADD COLUMN disposition TEXT NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE referrals ADD COLUMN disposition_reason TEXT;
ALTER TABLE referrals ADD COLUMN waitlist_status TEXT;
ALTER TABLE referrals ADD COLUMN sla_warning_sent_at TEXT;
ALTER TABLE referrals ADD COLUMN sla_breach_sent_at TEXT;
ALTER TABLE intake_tasks ADD COLUMN escalation_level INTEGER NOT NULL DEFAULT 0;
ALTER TABLE intake_tasks ADD COLUMN escalated_at TEXT;
ALTER TABLE intake_tasks ADD COLUMN completed_by TEXT REFERENCES users(id);
CREATE INDEX IF NOT EXISTS idx_org_name ON organizations(tenant_id,name);
CREATE INDEX IF NOT EXISTS idx_intake_docs_referral ON intake_documents(tenant_id,referral_id,status);
CREATE INDEX IF NOT EXISTS idx_ref_comm_referral ON referral_communications(tenant_id,referral_id,created_at);
CREATE INDEX IF NOT EXISTS idx_meetings_due ON intake_meetings(tenant_id,status,scheduled_at);
