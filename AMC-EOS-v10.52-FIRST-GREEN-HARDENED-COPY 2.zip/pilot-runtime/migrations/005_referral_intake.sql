PRAGMA foreign_keys = ON;
ALTER TABLE referrals ADD COLUMN date_of_birth TEXT;
ALTER TABLE referrals ADD COLUMN phone TEXT;
ALTER TABLE referrals ADD COLUMN email TEXT;
ALTER TABLE referrals ADD COLUMN current_housing TEXT;
ALTER TABLE referrals ADD COLUMN preferred_county TEXT;
ALTER TABLE referrals ADD COLUMN requested_service TEXT;
ALTER TABLE referrals ADD COLUMN urgency TEXT NOT NULL DEFAULT 'ROUTINE';
ALTER TABLE referrals ADD COLUMN assigned_to TEXT;
ALTER TABLE referrals ADD COLUMN sla_due_at TEXT;
ALTER TABLE referrals ADD COLUMN next_action TEXT;
ALTER TABLE referrals ADD COLUMN next_action_at TEXT;

CREATE TABLE IF NOT EXISTS referral_sources (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  category TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,name)
);
CREATE TABLE IF NOT EXISTS referral_support_needs (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  domain TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'UNKNOWN',
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,referral_id,domain)
);
CREATE TABLE IF NOT EXISTS referral_funding_items (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  item_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'REQUIRED',
  reference_number TEXT,
  expires_at TEXT,
  verified_by TEXT REFERENCES users(id),
  verified_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,referral_id,item_type)
);
CREATE TABLE IF NOT EXISTS referral_assignments (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id),
  role TEXT NOT NULL DEFAULT 'COORDINATOR',
  assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at TEXT
);
CREATE TABLE IF NOT EXISTS intake_tasks (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN',
  due_at TEXT,
  assigned_to TEXT REFERENCES users(id),
  blocking INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_referral_sla ON referrals(tenant_id,sla_due_at,status);
CREATE INDEX IF NOT EXISTS idx_intake_tasks_due ON intake_tasks(tenant_id,status,due_at);
