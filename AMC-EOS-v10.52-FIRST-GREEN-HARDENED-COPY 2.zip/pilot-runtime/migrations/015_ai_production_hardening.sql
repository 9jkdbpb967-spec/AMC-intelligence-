CREATE TABLE IF NOT EXISTS ai_provider_secret_refs (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, provider_id TEXT NOT NULL, secret_ref TEXT NOT NULL,
 secret_version TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE', rotated_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,provider_id), FOREIGN KEY(provider_id) REFERENCES ai_providers(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_collection_permissions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, collection_key TEXT NOT NULL, role_key TEXT NOT NULL,
 effect TEXT NOT NULL DEFAULT 'ALLOW', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,collection_key,role_key)
);
CREATE TABLE IF NOT EXISTS ai_security_events (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, user_id TEXT, execution_id TEXT,
 event_type TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'WARNING', details_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ai_provider_health (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, provider_id TEXT NOT NULL, healthy INTEGER NOT NULL,
 latency_ms INTEGER NOT NULL DEFAULT 0, failure_count INTEGER NOT NULL DEFAULT 0,
 circuit_state TEXT NOT NULL DEFAULT 'CLOSED', details TEXT, checked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(provider_id) REFERENCES ai_providers(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_tool_permissions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, agent_id TEXT NOT NULL, tool_key TEXT NOT NULL,
 permission_mode TEXT NOT NULL DEFAULT 'ALLOW', requires_approval INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,agent_id,tool_key),
 FOREIGN KEY(agent_id) REFERENCES ai_agents(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ai_security_events ON ai_security_events(tenant_id,event_type,created_at);
CREATE INDEX IF NOT EXISTS idx_ai_provider_health ON ai_provider_health(tenant_id,provider_id,checked_at);
