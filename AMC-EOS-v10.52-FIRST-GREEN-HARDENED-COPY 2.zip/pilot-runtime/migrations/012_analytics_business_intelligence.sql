
CREATE TABLE IF NOT EXISTS kpi_definitions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, metric_key TEXT NOT NULL, name TEXT NOT NULL,
 domain TEXT NOT NULL, description TEXT, unit TEXT NOT NULL DEFAULT 'COUNT', target_value REAL,
 warning_threshold REAL, critical_threshold REAL, active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id, metric_key)
);
CREATE TABLE IF NOT EXISTS kpi_snapshots (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, metric_key TEXT NOT NULL, snapshot_at TEXT NOT NULL,
 value REAL NOT NULL, dimension_type TEXT, dimension_id TEXT, source TEXT NOT NULL DEFAULT 'SYSTEM',
 metadata_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_kpi_snapshots_tenant_metric_time ON kpi_snapshots(tenant_id,metric_key,snapshot_at);
CREATE TABLE IF NOT EXISTS dashboard_widgets (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, dashboard_key TEXT NOT NULL, widget_key TEXT NOT NULL,
 title TEXT NOT NULL, metric_key TEXT, widget_type TEXT NOT NULL DEFAULT 'METRIC', position INTEGER NOT NULL DEFAULT 0,
 config_json TEXT NOT NULL DEFAULT '{}', active INTEGER NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,dashboard_key,widget_key)
);
CREATE TABLE IF NOT EXISTS report_definitions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, report_key TEXT NOT NULL, name TEXT NOT NULL,
 domain TEXT NOT NULL, format TEXT NOT NULL DEFAULT 'CSV', query_key TEXT NOT NULL,
 parameters_json TEXT NOT NULL DEFAULT '{}', active INTEGER NOT NULL DEFAULT 1,
 created_by_user_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,report_key)
);
CREATE TABLE IF NOT EXISTS report_schedules (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, report_definition_id TEXT NOT NULL,
 cadence TEXT NOT NULL, next_run_at TEXT NOT NULL, recipients_json TEXT NOT NULL DEFAULT '[]',
 status TEXT NOT NULL DEFAULT 'ACTIVE', last_run_at TEXT,
 FOREIGN KEY(report_definition_id) REFERENCES report_definitions(id)
);
CREATE TABLE IF NOT EXISTS report_runs (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, report_definition_id TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'QUEUED', started_at TEXT, completed_at TEXT,
 output_format TEXT, output_key TEXT, row_count INTEGER, error_message TEXT,
 FOREIGN KEY(report_definition_id) REFERENCES report_definitions(id)
);
CREATE TABLE IF NOT EXISTS data_quality_checks (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, check_key TEXT NOT NULL, name TEXT NOT NULL,
 domain TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'WARNING', active INTEGER NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,check_key)
);
CREATE TABLE IF NOT EXISTS data_quality_results (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, check_key TEXT NOT NULL, checked_at TEXT NOT NULL,
 status TEXT NOT NULL, issue_count INTEGER NOT NULL DEFAULT 0, details_json TEXT NOT NULL DEFAULT '{}'
);
