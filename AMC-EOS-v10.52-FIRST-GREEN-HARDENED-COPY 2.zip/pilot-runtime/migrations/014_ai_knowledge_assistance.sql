CREATE TABLE IF NOT EXISTS ai_providers (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, provider_key TEXT NOT NULL, name TEXT NOT NULL,
 provider_type TEXT NOT NULL DEFAULT 'TEST', status TEXT NOT NULL DEFAULT 'ACTIVE',
 config_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,provider_key)
);
CREATE TABLE IF NOT EXISTS ai_models (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, provider_id TEXT NOT NULL, model_key TEXT NOT NULL,
 name TEXT NOT NULL, context_window INTEGER, input_cost_per_million REAL NOT NULL DEFAULT 0,
 output_cost_per_million REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'ACTIVE',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,model_key),
 FOREIGN KEY(provider_id) REFERENCES ai_providers(id)
);
CREATE TABLE IF NOT EXISTS ai_agents (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, agent_key TEXT NOT NULL, name TEXT NOT NULL,
 description TEXT, model_id TEXT, system_prompt_key TEXT, requires_approval INTEGER NOT NULL DEFAULT 0,
 allowed_collections_json TEXT NOT NULL DEFAULT '[]', allowed_tools_json TEXT NOT NULL DEFAULT '[]',
 status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,agent_key),
 FOREIGN KEY(model_id) REFERENCES ai_models(id)
);
CREATE TABLE IF NOT EXISTS ai_prompts (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, prompt_key TEXT NOT NULL, name TEXT NOT NULL,
 owner_user_id TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,prompt_key)
);
CREATE TABLE IF NOT EXISTS ai_prompt_versions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, prompt_id TEXT NOT NULL, version_number INTEGER NOT NULL,
 content TEXT NOT NULL, variables_json TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'DRAFT',
 approved_by_user_id TEXT, approved_at TEXT, effective_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,prompt_id,version_number), FOREIGN KEY(prompt_id) REFERENCES ai_prompts(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_knowledge_sources (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, source_key TEXT NOT NULL, title TEXT NOT NULL,
 collection_key TEXT NOT NULL, source_type TEXT NOT NULL DEFAULT 'POLICY', version TEXT NOT NULL DEFAULT '1.0',
 status TEXT NOT NULL DEFAULT 'APPROVED', owner_user_id TEXT, effective_at TEXT, review_at TEXT,
 content TEXT NOT NULL, checksum TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,source_key,version)
);
CREATE TABLE IF NOT EXISTS ai_knowledge_chunks (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, source_id TEXT NOT NULL, chunk_index INTEGER NOT NULL,
 heading TEXT, content TEXT NOT NULL, token_estimate INTEGER NOT NULL DEFAULT 0,
 metadata_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id,source_id,chunk_index), FOREIGN KEY(source_id) REFERENCES ai_knowledge_sources(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_conversations (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, user_id TEXT NOT NULL, agent_id TEXT NOT NULL,
 title TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(agent_id) REFERENCES ai_agents(id)
);
CREATE TABLE IF NOT EXISTS ai_executions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, conversation_id TEXT, agent_id TEXT NOT NULL,
 user_id TEXT NOT NULL, model_id TEXT, prompt_version_id TEXT, request_text TEXT NOT NULL,
 response_text TEXT, status TEXT NOT NULL DEFAULT 'COMPLETED', citations_json TEXT NOT NULL DEFAULT '[]',
 input_tokens INTEGER NOT NULL DEFAULT 0, output_tokens INTEGER NOT NULL DEFAULT 0,
 estimated_cost REAL NOT NULL DEFAULT 0, latency_ms INTEGER NOT NULL DEFAULT 0,
 error_message TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(conversation_id) REFERENCES ai_conversations(id), FOREIGN KEY(agent_id) REFERENCES ai_agents(id)
);
CREATE TABLE IF NOT EXISTS ai_approvals (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, execution_id TEXT NOT NULL, requested_by_user_id TEXT NOT NULL,
 assigned_to_user_id TEXT, status TEXT NOT NULL DEFAULT 'PENDING', decision_notes TEXT,
 decided_by_user_id TEXT, decided_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(execution_id) REFERENCES ai_executions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_feedback (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, execution_id TEXT NOT NULL, user_id TEXT NOT NULL,
 rating INTEGER, helpful INTEGER, correction_text TEXT, notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(execution_id) REFERENCES ai_executions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ai_chunks_collection ON ai_knowledge_sources(tenant_id,collection_key,status);
CREATE INDEX IF NOT EXISTS idx_ai_exec_user_created ON ai_executions(tenant_id,user_id,created_at);
CREATE INDEX IF NOT EXISTS idx_ai_approval_status ON ai_approvals(tenant_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_ai_usage_created ON ai_executions(tenant_id,created_at);
