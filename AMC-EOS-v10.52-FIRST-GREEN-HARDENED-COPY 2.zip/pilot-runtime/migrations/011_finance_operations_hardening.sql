CREATE TABLE IF NOT EXISTS vendor_contracts (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, vendor_id TEXT NOT NULL, title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'DRAFT', starts_at TEXT, ends_at TEXT, renewal_notice_days INTEGER NOT NULL DEFAULT 30,
 value_cents INTEGER, owner_user_id TEXT, document_key TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(vendor_id) REFERENCES vendors(id)
);
CREATE TABLE IF NOT EXISTS purchase_request_attachments (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, purchase_request_id TEXT NOT NULL, file_name TEXT NOT NULL,
 storage_key TEXT NOT NULL, content_type TEXT, created_by_user_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(purchase_request_id) REFERENCES purchase_requests(id)
);
CREATE TABLE IF NOT EXISTS receiving_items (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, receiving_record_id TEXT NOT NULL, purchase_request_item_id TEXT NOT NULL,
 quantity_received REAL NOT NULL DEFAULT 0, quantity_rejected REAL NOT NULL DEFAULT 0, condition_status TEXT NOT NULL DEFAULT 'ACCEPTED',
 notes TEXT, FOREIGN KEY(receiving_record_id) REFERENCES receiving_records(id), FOREIGN KEY(purchase_request_item_id) REFERENCES purchase_request_items(id)
);
CREATE TABLE IF NOT EXISTS vendor_invoices (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, invoice_number TEXT NOT NULL, vendor_id TEXT NOT NULL, purchase_order_id TEXT,
 status TEXT NOT NULL DEFAULT 'RECEIVED', invoice_date TEXT, due_date TEXT, subtotal_cents INTEGER NOT NULL DEFAULT 0,
 tax_cents INTEGER NOT NULL DEFAULT 0, total_cents INTEGER NOT NULL DEFAULT 0, matched_amount_cents INTEGER NOT NULL DEFAULT 0,
 discrepancy_cents INTEGER NOT NULL DEFAULT 0, resolution_notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,vendor_id,invoice_number), FOREIGN KEY(vendor_id) REFERENCES vendors(id)
);
CREATE TABLE IF NOT EXISTS vendor_invoice_items (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, invoice_id TEXT NOT NULL, description TEXT NOT NULL,
 quantity REAL NOT NULL DEFAULT 1, unit_price_cents INTEGER NOT NULL DEFAULT 0, purchase_request_item_id TEXT,
 FOREIGN KEY(invoice_id) REFERENCES vendor_invoices(id)
);
CREATE TABLE IF NOT EXISTS invoice_discrepancies (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, invoice_id TEXT NOT NULL, discrepancy_type TEXT NOT NULL,
 amount_cents INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'OPEN', details TEXT, resolved_by_user_id TEXT,
 resolved_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(invoice_id) REFERENCES vendor_invoices(id)
);
CREATE TABLE IF NOT EXISTS budget_transactions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, budget_id TEXT NOT NULL, transaction_type TEXT NOT NULL,
 reference_type TEXT, reference_id TEXT, amount_cents INTEGER NOT NULL, transaction_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 notes TEXT, created_by_user_id TEXT, FOREIGN KEY(budget_id) REFERENCES budgets(id)
);
CREATE TABLE IF NOT EXISTS asset_transfers (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, asset_id TEXT NOT NULL, from_type TEXT, from_id TEXT, to_type TEXT NOT NULL,
 to_id TEXT, transferred_by_user_id TEXT NOT NULL, transferred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, notes TEXT,
 FOREIGN KEY(asset_id) REFERENCES assets(id)
);
CREATE TABLE IF NOT EXISTS asset_inspections (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, asset_id TEXT NOT NULL, inspection_type TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'PASS', inspected_by_user_id TEXT NOT NULL, inspected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 next_inspection_at TEXT, findings TEXT, FOREIGN KEY(asset_id) REFERENCES assets(id)
);
CREATE TABLE IF NOT EXISTS asset_disposals (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, asset_id TEXT NOT NULL, method TEXT NOT NULL, reason TEXT,
 proceeds_cents INTEGER NOT NULL DEFAULT 0, approved_by_user_id TEXT NOT NULL, disposed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(asset_id) REFERENCES assets(id)
);
CREATE TABLE IF NOT EXISTS grant_deliverables (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, grant_id TEXT NOT NULL, title TEXT NOT NULL, due_at TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'OPEN', evidence_key TEXT, completed_at TEXT, owner_user_id TEXT, notes TEXT,
 FOREIGN KEY(grant_id) REFERENCES grants(id)
);
CREATE TABLE IF NOT EXISTS finance_reminders (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, reminder_type TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'OPEN', severity TEXT NOT NULL DEFAULT 'NORMAL', message TEXT NOT NULL,
 acknowledged_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_vendor_contracts_due ON vendor_contracts(tenant_id,status,ends_at);
CREATE INDEX IF NOT EXISTS idx_vendor_compliance_expiry ON vendor_compliance_items(tenant_id,status,expires_at);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON vendor_invoices(tenant_id,status,due_date);
CREATE INDEX IF NOT EXISTS idx_budget_tx ON budget_transactions(tenant_id,budget_id,transaction_date);
CREATE INDEX IF NOT EXISTS idx_grant_deliverables_due ON grant_deliverables(tenant_id,status,due_at);
CREATE INDEX IF NOT EXISTS idx_finance_reminders_due ON finance_reminders(tenant_id,status,due_at);
