
ALTER TABLE kpi_definitions ADD COLUMN owner_user_id TEXT;
ALTER TABLE kpi_definitions ADD COLUMN certified_by_user_id TEXT;
ALTER TABLE kpi_definitions ADD COLUMN certified_at TEXT;
ALTER TABLE kpi_definitions ADD COLUMN comparison_period TEXT NOT NULL DEFAULT 'PREVIOUS_PERIOD';

CREATE TABLE IF NOT EXISTS dashboard_layouts (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, role_key TEXT NOT NULL, name TEXT NOT NULL,
 is_default INTEGER NOT NULL DEFAULT 0, created_by_user_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id, role_key, name)
);
CREATE TABLE IF NOT EXISTS dashboard_layout_widgets (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, layout_id TEXT NOT NULL, widget_key TEXT NOT NULL,
 title TEXT NOT NULL, metric_key TEXT, widget_type TEXT NOT NULL DEFAULT 'METRIC', position INTEGER NOT NULL DEFAULT 0,
 width INTEGER NOT NULL DEFAULT 1, height INTEGER NOT NULL DEFAULT 1, config_json TEXT NOT NULL DEFAULT '{}', active INTEGER NOT NULL DEFAULT 1,
 FOREIGN KEY(layout_id) REFERENCES dashboard_layouts(id) ON DELETE CASCADE,
 UNIQUE(tenant_id, layout_id, widget_key)
);
CREATE TABLE IF NOT EXISTS report_subscriptions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, report_definition_id TEXT NOT NULL, subscriber_user_id TEXT,
 delivery_channel TEXT NOT NULL DEFAULT 'IN_APP', cadence TEXT NOT NULL DEFAULT 'DAILY', recipients_json TEXT NOT NULL DEFAULT '[]',
 active INTEGER NOT NULL DEFAULT 1, next_delivery_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(report_definition_id) REFERENCES report_definitions(id)
);
CREATE TABLE IF NOT EXISTS report_delivery_history (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, subscription_id TEXT, report_run_id TEXT,
 channel TEXT NOT NULL, recipient TEXT, status TEXT NOT NULL DEFAULT 'QUEUED', delivered_at TEXT, error_message TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS executive_briefings (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, briefing_type TEXT NOT NULL, briefing_date TEXT NOT NULL,
 title TEXT NOT NULL, summary TEXT NOT NULL, highlights_json TEXT NOT NULL DEFAULT '[]', risks_json TEXT NOT NULL DEFAULT '[]',
 actions_json TEXT NOT NULL DEFAULT '[]', generated_by TEXT NOT NULL DEFAULT 'RULES', approved_by_user_id TEXT,
 approved_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tenant_id, briefing_type, briefing_date)
);
CREATE TABLE IF NOT EXISTS data_quality_remediation_tasks (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, check_key TEXT NOT NULL, result_id TEXT,
 title TEXT NOT NULL, description TEXT, status TEXT NOT NULL DEFAULT 'OPEN', priority TEXT NOT NULL DEFAULT 'NORMAL',
 assigned_user_id TEXT, due_at TEXT, completed_at TEXT, resolution_notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS metric_certifications (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, metric_key TEXT NOT NULL, owner_user_id TEXT,
 certification_status TEXT NOT NULL DEFAULT 'DRAFT', methodology TEXT, source_systems_json TEXT NOT NULL DEFAULT '[]',
 certified_by_user_id TEXT, certified_at TEXT, expires_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id, metric_key)
);
CREATE INDEX IF NOT EXISTS idx_layout_role ON dashboard_layouts(tenant_id,role_key,is_default);
CREATE INDEX IF NOT EXISTS idx_subscription_due ON report_subscriptions(tenant_id,active,next_delivery_at);
CREATE INDEX IF NOT EXISTS idx_delivery_status ON report_delivery_history(tenant_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_briefing_type_date ON executive_briefings(tenant_id,briefing_type,briefing_date);
CREATE INDEX IF NOT EXISTS idx_remediation_status ON data_quality_remediation_tasks(tenant_id,status,due_at);
