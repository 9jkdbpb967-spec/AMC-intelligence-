export interface AdmitReferralRequest { bedId: string }
export interface AdmitReferralResponse { admissionId: string; residentId: string }
