export interface CreateReferralRequest {
  firstName: string;
  lastName: string;
  sourceOrganization?: string;
  supportSummary?: string;
  fundingStatus?: string;
}

export interface ReferralRecord {
  id: string;
  tenant_id: string;
  applicant_first_name: string;
  applicant_last_name: string;
  status: string;
  management_approved: number;
  assessment_complete: number;
  documents_verified: number;
}

export interface ReferralReadinessRequest {
  managementApproved: boolean;
  assessmentComplete: boolean;
  documentsVerified: boolean;
}
