# AMC-EOS Runnable Pilot Vertical Slice

This dependency-free runtime proves the core workflow end to end:

1. Sign in.
2. Create a tenant-scoped referral.
3. Mark management approval, assessment, and documents complete.
4. Admit the applicant to an available bed.
5. Create the resident and occupy the bed atomically.
6. Record immutable audit events.

## Run with Python 3.11+

```bash
cd pilot-runtime
python3 server.py seed
python3 server.py serve --port 8080
```

Open `http://localhost:8080`.

Development login: `admin@amceos.local` / `ChangeMe123!`

## Run tests

```bash
python3 -m unittest discover -s tests -v
```

## Run with Docker

```bash
cd pilot-runtime
docker compose up --build
```

This runtime uses SQLite and Python's standard library so it can be executed without npm. It is a validated pilot slice, not the final NestJS/PostgreSQL production runtime. Use synthetic data only.
