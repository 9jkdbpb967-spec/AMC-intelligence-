#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, hmac, json, os, secrets, sqlite3, sys, uuid
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv('AMC_PILOT_DB', ROOT / 'amc_pilot.sqlite3'))
STATIC = ROOT / 'static'


def uid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 200_000)
    return f"pbkdf2_sha256$200000${salt.hex()}${digest.hex()}"

def verify_password(password: str, encoded: str) -> bool:
    algo, rounds, salt, expected = encoded.split('$')
    actual = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), int(rounds)).hex()
    return hmac.compare_digest(actual, expected)

def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def migrate() -> None:
    with db() as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
        applied={r[0] for r in conn.execute('SELECT name FROM schema_migrations').fetchall()}
        for file in sorted((ROOT/'migrations').glob('*.sql')):
            if file.name in applied: continue
            conn.executescript(file.read_text())
            conn.execute('INSERT INTO schema_migrations(name) VALUES(?)',(file.name,))

def seed() -> None:
    migrate()
    tenants = [
        ('tenant_amc_demo','amc-supported-living','AMC Supported Living Demo','user_admin_demo','admin@amceos.local','AMC Pilot Home'),
        ('tenant_second_demo','second-demo','Second Tenant Demo','user_second_demo','admin@second.local','Second Tenant Home'),
    ]
    with db() as conn:
        for tenant_id, slug, name, user_id, email, home_name in tenants:
            conn.execute("INSERT OR IGNORE INTO tenants(id,slug,name) VALUES(?,?,?)", (tenant_id,slug,name))
            conn.execute("INSERT OR IGNORE INTO users(id,tenant_id,email,password_hash,role) VALUES(?,?,?,?,?)", (user_id,tenant_id,email,hash_password('ChangeMe123!'),'ADMIN'))
            home_id=f'home_{slug}'
            conn.execute("INSERT OR IGNORE INTO homes(id,tenant_id,name,city,state) VALUES(?,?,?,?,?)", (home_id,tenant_id,home_name,'Kent','WA'))
            for n in range(1,4):
                conn.execute("INSERT OR IGNORE INTO beds(id,tenant_id,home_id,label,status) VALUES(?,?,?,?,?)", (f'bed_{slug}_{n}',tenant_id,home_id,f'Bedroom {n}','AVAILABLE'))
            for source_name,category in [('DSHS/DDA','Government'),('Valley Medical Center','Hospital'),('Community Living Connections','Community')]:
                conn.execute('INSERT OR IGNORE INTO referral_sources(id,tenant_id,name,category) VALUES(?,?,?,?)',(f"source_{slug}_{source_name.lower().replace('/','_').replace(' ','_')}",tenant_id,source_name,category))
            for org_name,category,email in [('DSHS/DDA','Government','dda-referrals@example.test'),('Valley Medical Center','Hospital','discharge@example.test'),('Community Living Connections','Community','intake@example.test')]:
                org_id=f"org_{slug}_{org_name.lower().replace('/','_').replace(' ','_')}"
                conn.execute('INSERT OR IGNORE INTO organizations(id,tenant_id,name,category,email,status) VALUES(?,?,?,?,?,?)',(org_id,tenant_id,org_name,category,email,'ACTIVE'))
                conn.execute('INSERT OR IGNORE INTO organization_contacts(id,tenant_id,organization_id,first_name,last_name,title,email) VALUES(?,?,?,?,?,?,?)',(f"contact_{org_id}",tenant_id,org_id,'Public','Intake','Intake Department',email))
            conn.execute("INSERT OR IGNORE INTO employee_profiles(id,tenant_id,employee_number,first_name,last_name,job_title,lifecycle_status) VALUES(?,?,?,?,?,?,?)",(f'emp_{slug}',tenant_id,'EMP-001','Pilot','Employee','Direct Support Professional','ACTIVE'))
            for metric_key,name,domain,unit,target in [
                ('occupancy_rate','Occupancy Rate','OPERATIONS','PERCENT',90),
                ('referral_conversion_rate','Referral Conversion Rate','REFERRAL','PERCENT',60),
                ('documentation_completion_rate','Documentation Completion','QUALITY','PERCENT',95),
                ('credential_compliance_rate','Credential Compliance','WORKFORCE','PERCENT',95),
                ('budget_utilization_rate','Budget Utilization','FINANCE','PERCENT',85),
                ('open_incidents','Open Incidents','QUALITY','COUNT',0)]:
                conn.execute('INSERT OR IGNORE INTO kpi_definitions(id,tenant_id,metric_key,name,domain,unit,target_value) VALUES(?,?,?,?,?,?,?)',(f'kpi_{slug}_{metric_key}',tenant_id,metric_key,name,domain,unit,target))
            for check_key,name,domain,severity in [('missing_resident_home','Residents missing home assignment','RESIDENT','CRITICAL'),('overdue_intake_tasks','Overdue intake tasks','REFERRAL','WARNING'),('expired_vendor_compliance','Expired vendor compliance','FINANCE','WARNING'),('open_quality_issues','Open documentation quality issues','QUALITY','WARNING')]:
                conn.execute('INSERT OR IGNORE INTO data_quality_checks(id,tenant_id,check_key,name,domain,severity) VALUES(?,?,?,?,?,?)',(f'dq_{slug}_{check_key}',tenant_id,check_key,name,domain,severity))
            for role_key,layout_name in [('EXECUTIVE','Executive Command Center'),('OPERATIONS','Operations Command Center'),('FINANCE','Finance Command Center'),('QUALITY','Quality Command Center')]:
                layout_id=f"layout_{slug}_{role_key.lower()}"
                conn.execute('INSERT OR IGNORE INTO dashboard_layouts(id,tenant_id,role_key,name,is_default,created_by_user_id) VALUES(?,?,?,?,1,?)',(layout_id,tenant_id,role_key,layout_name,user_id))
            for metric_key in ['occupancy_rate','referral_conversion_rate','documentation_completion_rate','credential_compliance_rate','budget_utilization_rate','open_incidents']:
                conn.execute('INSERT OR IGNORE INTO metric_certifications(id,tenant_id,metric_key,owner_user_id,certification_status,methodology,source_systems_json) VALUES(?,?,?,?,?,?,?)',(f'cert_{slug}_{metric_key}',tenant_id,metric_key,user_id,'DRAFT','System-calculated pilot metric',json.dumps(['AMC-EOS'])) )
            provider_id=f'ai_provider_{slug}_test'; model_id=f'ai_model_{slug}_grounded'
            conn.execute('INSERT OR IGNORE INTO ai_providers(id,tenant_id,provider_key,name,provider_type,status,config_json) VALUES(?,?,?,?,?,?,?)',(provider_id,tenant_id,'test','AMC Deterministic Test Provider','TEST','ACTIVE',json.dumps({'externalNetwork':False})))
            conn.execute('INSERT OR IGNORE INTO ai_models(id,tenant_id,provider_id,model_key,name,context_window,status) VALUES(?,?,?,?,?,?,?)',(model_id,tenant_id,provider_id,'grounded-test-v1','Grounded Test Model',16000,'ACTIVE'))
            for agent_key,agent_name,description,requires,collections in [
                ('knowledge','Knowledge Assistant','Answers from approved AMC policies and SOPs only',0,['POLICIES','SOPS','TRAINING']),
                ('operations','Operations Assistant','Supports daily operations with approved procedures',0,['SOPS','POLICIES']),
                ('executive','Executive Assistant','Drafts governed executive summaries for approval',1,['MANUALS','POLICIES','SOPS'])]:
                conn.execute('INSERT OR IGNORE INTO ai_agents(id,tenant_id,agent_key,name,description,model_id,requires_approval,allowed_collections_json,allowed_tools_json,status) VALUES(?,?,?,?,?,?,?,?,?,?)',(f'ai_agent_{slug}_{agent_key}',tenant_id,agent_key,agent_name,description,model_id,requires,json.dumps(collections),json.dumps(['knowledge.search']),'ACTIVE'))
                for collection in collections: conn.execute('INSERT OR IGNORE INTO ai_collection_permissions(id,tenant_id,collection_key,role_key,effect) VALUES(?,?,?,?,?)',(f'aicollperm_{slug}_{agent_key}_{collection.lower()}',tenant_id,collection,'ADMIN','ALLOW'))
                conn.execute('INSERT OR IGNORE INTO ai_tool_permissions(id,tenant_id,agent_id,tool_key,permission_mode,requires_approval) VALUES(?,?,?,?,?,?)',(f'aitoolperm_{slug}_{agent_key}',tenant_id,f'ai_agent_{slug}_{agent_key}','knowledge.search','ALLOW',0))
            prompt_id=f'ai_prompt_{slug}_grounded_answer'
            conn.execute('INSERT OR IGNORE INTO ai_prompts(id,tenant_id,prompt_key,name,owner_user_id,status) VALUES(?,?,?,?,?,?)',(prompt_id,tenant_id,'grounded-answer','Grounded Answer',user_id,'ACTIVE'))
            conn.execute('INSERT OR IGNORE INTO ai_prompt_versions(id,tenant_id,prompt_id,version_number,content,variables_json,status,approved_by_user_id,approved_at,effective_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(f'ai_prompt_version_{slug}_1',tenant_id,prompt_id,1,'Answer only from retrieved approved AMC sources. Cite every material statement.',json.dumps(['question','sources']),'APPROVED',user_id,now_iso(),now_iso()))
            policy_content='''Resident safety is the first priority. Staff must report urgent safety concerns immediately to the house manager and document the concern in the approved incident workflow. Shift handoffs must identify outstanding resident tasks, appointments, active alerts, and follow-up needs. Approved records must not be overwritten; corrections use an amendment that preserves the original entry.'''
            source_id=f'ai_source_{slug}_operations_policy'
            checksum=hashlib.sha256(policy_content.encode()).hexdigest()
            conn.execute('INSERT OR IGNORE INTO ai_knowledge_sources(id,tenant_id,source_key,title,collection_key,source_type,version,status,owner_user_id,effective_at,content,checksum) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(source_id,tenant_id,'operations-safety-policy','Operations and Safety Policy','POLICIES','POLICY','1.0','APPROVED',user_id,now_iso(),policy_content,checksum))
            for idx,chunk in enumerate([x.strip() for x in policy_content.split('.') if x.strip()]):
                conn.execute('INSERT OR IGNORE INTO ai_knowledge_chunks(id,tenant_id,source_id,chunk_index,heading,content,token_estimate,metadata_json) VALUES(?,?,?,?,?,?,?,?)',(f'ai_chunk_{slug}_{idx}',tenant_id,source_id,idx,'Operations and Safety',chunk+'.',max(1,len(chunk.split())),json.dumps({'sourceKey':'operations-safety-policy'})))
            for program,item,label in [('SUPPORTED_LIVING','IDENTITY','Identity verification'),('SUPPORTED_LIVING','FUNDING_AUTHORIZATION','Funding authorization'),('SUPPORTED_LIVING','ASSESSMENT','Current assessment'),('SUPPORTED_LIVING','RELEASE_OF_INFORMATION','Release of information'),('SUPPORTED_LIVING','GUARDIANSHIP','Guardianship or decision-making documents')]:
                conn.execute('INSERT OR IGNORE INTO intake_document_rules(id,tenant_id,program_code,item_type,label,required,blocking) VALUES(?,?,?,?,?,?,?)',(f"rule_{slug}_{item.lower()}",tenant_id,program,item,label,1,1))

def rowdict(row): return dict(row) if row else None

class Handler(SimpleHTTPRequestHandler):
    server_version = 'AMC-EOS-Pilot/4.5'
    def translate_path(self, path):
        clean = urlparse(path).path.lstrip('/')
        return str(STATIC / (clean or 'index.html'))
    def log_message(self, fmt, *args):
        sys.stderr.write('[pilot] '+fmt%args+'\n')
    def send_json(self, status, data):
        body=json.dumps(data,default=str).encode()
        self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(body)
    def read_json(self):
        try:
            n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
        except Exception: return None
    def auth(self):
        header=self.headers.get('Authorization','')
        if not header.startswith('Bearer '): return None
        token=header[7:]
        with db() as conn:
            row=conn.execute("SELECT s.token,s.tenant_id,u.id user_id,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>? AND s.revoked_at IS NULL",(token,now_iso())).fetchone()
        return rowdict(row)
    def audit(self, conn, auth, action, entity_type, entity_id, details=None):
        conn.execute("INSERT INTO audit_events(id,tenant_id,actor_user_id,action,entity_type,entity_id,details_json) VALUES(?,?,?,?,?,?,?)",(uid('audit'),auth['tenant_id'],auth['user_id'],action,entity_type,entity_id,json.dumps(details or {})))
    def activity(self, conn, auth, referral_id, activity_type, summary, details=None):
        conn.execute("INSERT INTO referral_activities(id,tenant_id,referral_id,actor_user_id,activity_type,summary,details_json) VALUES(?,?,?,?,?,?,?)",(uid('act'),auth['tenant_id'],referral_id,auth['user_id'],activity_type,summary,json.dumps(details or {})))
    def request_hash(self, data):
        return hashlib.sha256(json.dumps(data or {},sort_keys=True,separators=(',',':')).encode()).hexdigest()
    def ai_retrieve(self, conn, tenant_id, query, allowed_collections=None, limit=4):
        words={w.lower().strip('.,:;!?()[]{}') for w in (query or '').split() if len(w.strip('.,:;!?()[]{}'))>2}
        rows=conn.execute('''SELECT c.id,c.source_id,c.heading,c.content,s.title,s.collection_key,s.version
                             FROM ai_knowledge_chunks c JOIN ai_knowledge_sources s ON s.id=c.source_id
                             WHERE c.tenant_id=? AND s.status='APPROVED' ORDER BY s.updated_at DESC,c.chunk_index''',(tenant_id,)).fetchall()
        scored=[]
        for row in rows:
            if allowed_collections and row['collection_key'] not in allowed_collections: continue
            text=(row['heading'] or '')+' '+row['content']
            tokens={w.lower().strip('.,:;!?()[]{}') for w in text.split()}
            score=len(words & tokens)
            if score: scored.append((score,row))
        scored.sort(key=lambda x:(-x[0],x[1]['title']))
        return [r for _,r in scored[:limit]]
    def ai_screen_prompt(self, text):
        patterns=['ignore previous instructions','ignore all instructions','reveal the system prompt','developer message','bypass policy','unrestricted mode']
        lowered=(text or '').lower()
        return next((p for p in patterns if p in lowered),None)
    def ai_redact(self, text):
        import re
        redactions=[]; out=text or ''
        specs=[('EMAIL',r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b'),('SSN',r'\b\d{3}-\d{2}-\d{4}\b'),('PHONE',r'\b(?:\+?1[-. ]?)?\(?\d{3}\)?[-. ]?\d{3}[-. ]?\d{4}\b')]
        for name,pat in specs:
            out,n=re.subn(pat,f'[REDACTED_{name}]',out,flags=re.I)
            if n:redactions.extend([name.lower()]*n)
        return out,redactions
    def ai_collection_allowed(self, conn, tenant_id, role, collection):
        row=conn.execute('SELECT effect FROM ai_collection_permissions WHERE tenant_id=? AND role_key=? AND collection_key=?',(tenant_id,role,collection)).fetchone()
        return row is None or row['effect']=='ALLOW'
    def idempotency_lookup(self, conn, auth, key, data):
        if not key: return None
        row=conn.execute("SELECT * FROM idempotency_keys WHERE tenant_id=? AND user_id=? AND key_value=?",(auth['tenant_id'],auth['user_id'],key)).fetchone()
        if not row: return None
        if row['request_hash'] != self.request_hash(data):
            return ('conflict',409,{'error':'idempotency_conflict','message':'This idempotency key was already used with different request data.'})
        return ('replay',row['response_status'],json.loads(row['response_json']))
    def idempotency_store(self, conn, auth, key, data, status, response):
        if not key: return
        conn.execute("INSERT INTO idempotency_keys(id,tenant_id,user_id,key_value,request_hash,response_status,response_json) VALUES(?,?,?,?,?,?,?)",(uid('idem'),auth['tenant_id'],auth['user_id'],key,self.request_hash(data),status,json.dumps(response)))
    def permitted(self, auth, permission):
        role_permissions={
            'ADMIN': {'*'},
            'MANAGER': {'referral.read','referral.write','resident.read','admission.write','audit.read','notification.read','search.read'},
            'COORDINATOR': {'referral.read','referral.write','resident.read','notification.read','search.read'},
            'VIEWER': {'referral.read','resident.read','notification.read','search.read'}
        }
        allowed=role_permissions.get(auth['role'],set())
        if '*' in allowed or permission in allowed:return True
        with db() as conn:
            row=conn.execute("SELECT effect FROM user_permissions WHERE tenant_id=? AND user_id=? AND permission=? ORDER BY created_at DESC LIMIT 1",(auth['tenant_id'],auth['user_id'],permission)).fetchone()
        return bool(row and row['effect']=='ALLOW')
    def require(self, auth, permission):
        if not self.permitted(auth,permission):
            self.send_json(403,{'error':'forbidden','permission':permission});return False
        return True
    def notify(self, conn, auth, message, subject=None, user_id=None):
        conn.execute("INSERT INTO notifications(id,tenant_id,user_id,channel,subject,message,status,sent_at) VALUES(?,?,?,?,?,?,?,?)",(uid('note'),auth['tenant_id'],user_id or auth['user_id'],'IN_APP',subject,message,'SENT',now_iso()))
    def index_search(self, conn, tenant_id, entity_type, entity_id, title, body=''):
        conn.execute("INSERT INTO search_documents(id,tenant_id,entity_type,entity_id,title,body,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,entity_type,entity_id) DO UPDATE SET title=excluded.title,body=excluded.body,updated_at=excluded.updated_at",(uid('search'),tenant_id,entity_type,entity_id,title,body,now_iso()))
    def _analytics_scorecard(self, conn, tenant_id):
        def scalar(sql,args=()): return conn.execute(sql,args).fetchone()[0]
        def pct(a,b): return round(a*100.0/b,1) if b else 0.0
        beds=scalar('SELECT COUNT(*) FROM beds WHERE tenant_id=?',(tenant_id,)); residents=scalar("SELECT COUNT(*) FROM residents WHERE tenant_id=? AND status='ACTIVE'",(tenant_id,))
        refs=scalar('SELECT COUNT(*) FROM referrals WHERE tenant_id=?',(tenant_id,)); admitted=scalar("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND status='ADMITTED'",(tenant_id,))
        tasks=scalar('SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=?',(tenant_id,)); done=scalar("SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=? AND status='COMPLETED'",(tenant_id,))
        b=conn.execute('SELECT COALESCE(SUM(approved_amount_cents),0),COALESCE(SUM(actual_amount_cents),0) FROM budgets WHERE tenant_id=?',(tenant_id,)).fetchone()
        return {'occupancy_rate':pct(residents,beds),'referral_conversion_rate':pct(admitted,refs),'documentation_completion_rate':pct(done,tasks),'budget_utilization_rate':pct(b[1],b[0]),'open_incidents':scalar("SELECT COUNT(*) FROM quick_incidents WHERE tenant_id=? AND status NOT IN ('CLOSED','CONVERTED')",(tenant_id,))}

    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Headers','Authorization,Content-Type'); self.send_header('Access-Control-Allow-Methods','GET,POST,PATCH,OPTIONS'); self.end_headers()
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin','*'); super().end_headers()
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/health': return self.send_json(200,{'status':'ok','service':'amc-eos-pilot','database':str(DB_PATH)})
        if p.startswith('/api/'):
            a=self.auth()
            if not a:return self.send_json(401,{'error':'unauthorized'})
            with db() as conn:
                if p=='/api/me':
                    tenant=conn.execute('SELECT id,slug,name FROM tenants WHERE id=?',(a['tenant_id'],)).fetchone()
                    return self.send_json(200,{'user':{'id':a['user_id'],'email':a['email'],'role':a['role']},'tenant':dict(tenant)})
                if p=='/api/sessions':
                    rows=conn.execute('SELECT token,expires_at,created_at,last_seen_at,ip_address,user_agent,device_id FROM sessions WHERE tenant_id=? AND user_id=? AND revoked_at IS NULL ORDER BY created_at DESC',(a['tenant_id'],a['user_id'])).fetchall()
                    return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/notifications':
                    if not self.require(a,'notification.read'):return
                    rows=conn.execute('SELECT * FROM notifications WHERE tenant_id=? AND (user_id=? OR user_id IS NULL) ORDER BY created_at DESC LIMIT 100',(a['tenant_id'],a['user_id'])).fetchall()
                    return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/search':
                    if not self.require(a,'search.read'):return
                    qs=parse_qs(urlparse(self.path).query); q=(qs.get('q') or [''])[0].strip().lower()
                    if not q:return self.send_json(200,[])
                    like=f'%{q}%'
                    rows=conn.execute('SELECT entity_type,entity_id,title,body,updated_at FROM search_documents WHERE tenant_id=? AND (lower(title) LIKE ? OR lower(body) LIKE ?) ORDER BY updated_at DESC LIMIT 50',(a['tenant_id'],like,like)).fetchall()
                    return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/login-history':
                    if a['role']!='ADMIN':return self.send_json(403,{'error':'forbidden'})
                    rows=conn.execute('SELECT * FROM login_history WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100',(a['tenant_id'],)).fetchall()
                    return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/providers':
                    rows=conn.execute('SELECT id,provider_key,name,provider_type,status,created_at FROM ai_providers WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/models':
                    rows=conn.execute('SELECT id,provider_id,model_key,name,context_window,status FROM ai_models WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/agents':
                    rows=conn.execute('SELECT * FROM ai_agents WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[{**dict(r),'allowedCollections':json.loads(r['allowed_collections_json'] or '[]'),'allowedTools':json.loads(r['allowed_tools_json'] or '[]')} for r in rows])
                if p=='/api/ai/prompts':
                    rows=conn.execute('''SELECT p.*,v.id version_id,v.version_number,v.status version_status,v.approved_at
                                         FROM ai_prompts p LEFT JOIN ai_prompt_versions v ON v.prompt_id=p.id
                                         WHERE p.tenant_id=? ORDER BY p.name,v.version_number DESC''',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/knowledge-sources':
                    rows=conn.execute('SELECT id,source_key,title,collection_key,source_type,version,status,effective_at,review_at,checksum,created_at FROM ai_knowledge_sources WHERE tenant_id=? ORDER BY title',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/approvals':
                    rows=conn.execute('''SELECT ap.*,e.request_text,e.response_text,ag.name agent_name FROM ai_approvals ap
                                         JOIN ai_executions e ON e.id=ap.execution_id JOIN ai_agents ag ON ag.id=e.agent_id
                                         WHERE ap.tenant_id=? ORDER BY ap.created_at DESC''',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/executions':
                    rows=conn.execute('''SELECT e.*,ag.agent_key,ag.name agent_name FROM ai_executions e JOIN ai_agents ag ON ag.id=e.agent_id
                                         WHERE e.tenant_id=? ORDER BY e.created_at DESC LIMIT 100''',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/ai/usage':
                    row=conn.execute('''SELECT COUNT(*) executions,COALESCE(SUM(input_tokens),0) input_tokens,COALESCE(SUM(output_tokens),0) output_tokens,
                                        COALESCE(SUM(estimated_cost),0) estimated_cost,COALESCE(AVG(latency_ms),0) average_latency_ms
                                        FROM ai_executions WHERE tenant_id=?''',(a['tenant_id'],)).fetchone(); return self.send_json(200,dict(row))
                if p=='/api/ai/health':
                    rows=conn.execute('SELECT * FROM ai_providers WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall()
                    out=[]
                    for r in rows:
                        healthy=r['provider_type']=='TEST'; state='CLOSED' if healthy else 'DISABLED'
                        hid=uid('aihealth'); conn.execute('INSERT INTO ai_provider_health(id,tenant_id,provider_id,healthy,circuit_state,details) VALUES(?,?,?,?,?,?)',(hid,a['tenant_id'],r['id'],1 if healthy else 0,state,'Deterministic provider healthy' if healthy else 'External provider disabled until secret resolution'))
                        out.append({'providerId':r['id'],'providerKey':r['provider_key'],'healthy':healthy,'circuitState':state})
                    return self.send_json(200,out)
                if p=='/api/ai/cost-dashboard':
                    row=conn.execute('''SELECT COUNT(*) executions,COALESCE(SUM(input_tokens),0) input_tokens,COALESCE(SUM(output_tokens),0) output_tokens,COALESCE(SUM(estimated_cost),0) estimated_cost,COALESCE(AVG(latency_ms),0) average_latency_ms FROM ai_executions WHERE tenant_id=?''',(a['tenant_id'],)).fetchone()
                    security=conn.execute('SELECT COUNT(*) FROM ai_security_events WHERE tenant_id=?',(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{**dict(row),'securityEvents':security})
                if p=='/api/dashboard':
                    q=lambda sql: conn.execute(sql,(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{'referrals':q('SELECT COUNT(*) FROM referrals WHERE tenant_id=?'),'ready':q("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND management_approved=1 AND assessment_complete=1 AND documents_verified=1 AND status!='ADMITTED'"),'overdueSla':q("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND sla_due_at IS NOT NULL AND sla_due_at<CURRENT_TIMESTAMP AND status NOT IN ('ADMITTED','CLOSED')"),'openIntakeTasks':q("SELECT COUNT(*) FROM intake_tasks WHERE tenant_id=? AND status='OPEN'"),'residents':q("SELECT COUNT(*) FROM residents WHERE tenant_id=? AND status='ACTIVE'"),'availableBeds':q("SELECT COUNT(*) FROM beds WHERE tenant_id=? AND status='AVAILABLE'")})
                if p=='/api/referral-sources':
                    rows=conn.execute('SELECT * FROM referral_sources WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/organizations':
                    rows=conn.execute("SELECT * FROM organizations WHERE tenant_id=? AND status='ACTIVE' ORDER BY name",(a['tenant_id'],)).fetchall()
                    out=[]
                    for r in rows:
                        d=dict(r); d['contacts']=[dict(x) for x in conn.execute('SELECT * FROM organization_contacts WHERE tenant_id=? AND organization_id=? ORDER BY last_name,first_name',(a['tenant_id'],r['id'])).fetchall()]; out.append(d)
                    return self.send_json(200,out)
                if p=='/api/intake-operations-dashboard':
                    q=lambda sql: conn.execute(sql,(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{'overdueTasks':q("SELECT COUNT(*) FROM intake_tasks WHERE tenant_id=? AND status='OPEN' AND due_at<CURRENT_TIMESTAMP"),'slaWarnings':q("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND sla_due_at IS NOT NULL AND sla_due_at<=datetime('now','+6 hours') AND sla_due_at>CURRENT_TIMESTAMP AND status NOT IN ('ADMITTED','DECLINED','CLOSED')"),'slaBreaches':q("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND sla_due_at<CURRENT_TIMESTAMP AND status NOT IN ('ADMITTED','DECLINED','CLOSED')"),'waitlisted':q("SELECT COUNT(*) FROM waitlist_entries WHERE tenant_id=? AND status='ACTIVE'"),'duplicateMatches':q("SELECT COUNT(*) FROM duplicate_referral_matches WHERE tenant_id=? AND status='OPEN'"),'scheduledMeetings':q("SELECT COUNT(*) FROM intake_meetings WHERE tenant_id=? AND status='SCHEDULED'")})
                if p=='/api/intake-dashboard':
                    rows=conn.execute("SELECT r.*, (SELECT COUNT(*) FROM intake_tasks t WHERE t.referral_id=r.id AND t.status='OPEN') open_tasks FROM referrals r WHERE r.tenant_id=? AND r.status!='ADMITTED' ORDER BY COALESCE(r.sla_due_at,r.created_at)",(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/dashboard':
                    home_id=parse_qs(urlparse(self.path).query).get('homeId',[None])[0]
                    extra=' AND home_id=?' if home_id else ''; params=(a['tenant_id'],home_id) if home_id else (a['tenant_id'],)
                    q=lambda table,where='1=1': conn.execute(f'SELECT COUNT(*) FROM {table} WHERE tenant_id=?{extra} AND {where}',params).fetchone()[0]
                    return self.send_json(200,{'openTasks':q('resident_daily_tasks',"status IN ('OPEN','IN_PROGRESS')"),'lateTasks':q('resident_daily_tasks',"status IN ('OPEN','IN_PROGRESS') AND due_at IS NOT NULL AND due_at<CURRENT_TIMESTAMP"),'upcomingAppointments':conn.execute("SELECT COUNT(*) FROM resident_appointments WHERE tenant_id=? AND status IN ('SCHEDULED','CONFIRMED') AND starts_at>=CURRENT_TIMESTAMP",(a['tenant_id'],)).fetchone()[0],'activeAlerts':q('shift_alerts','acknowledged_at IS NULL'),'pendingHandoffs':q('shift_handoffs',"status='SUBMITTED'"),'openQuickIncidents':q('quick_incidents',"status IN ('REPORTED','ESCALATED')")})
                if p=='/api/daily-service/handoffs':
                    rows=conn.execute('SELECT * FROM shift_handoffs WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/tasks':
                    rows=conn.execute('SELECT * FROM resident_daily_tasks WHERE tenant_id=? ORDER BY due_at,created_at',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/appointments':
                    rows=conn.execute('SELECT * FROM resident_appointments WHERE tenant_id=? ORDER BY starts_at',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/guardian-communications':
                    rows=conn.execute('SELECT * FROM guardian_communications WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/quick-incidents':
                    rows=conn.execute('SELECT * FROM quick_incidents WHERE tenant_id=? ORDER BY occurred_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/shifts':
                    rows=conn.execute('SELECT * FROM service_shifts WHERE tenant_id=? ORDER BY started_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/daily-service/quality':
                    q=lambda sql: conn.execute(sql,(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{'openIssues':q("SELECT COUNT(*) FROM documentation_quality_issues WHERE tenant_id=? AND status='OPEN'"),'criticalIssues':q("SELECT COUNT(*) FROM documentation_quality_issues WHERE tenant_id=? AND status='OPEN' AND severity='CRITICAL'"),'unacknowledgedHandoffs':q("SELECT COUNT(*) FROM shift_handoffs WHERE tenant_id=? AND status='SUBMITTED'"),'overdueTasks':q("SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=? AND status IN ('OPEN','IN_PROGRESS') AND due_at<CURRENT_TIMESTAMP"),'unconfirmedAppointments':q("SELECT COUNT(*) FROM resident_appointments WHERE tenant_id=? AND status='SCHEDULED' AND starts_at<=datetime('now','+24 hours')")})
                if p=='/api/daily-service/timeline':
                    resident=(parse_qs(urlparse(self.path).query).get('residentId') or [None])[0]
                    if not resident:return self.send_json(422,{'error':'residentId_required'})
                    rows=conn.execute('SELECT * FROM service_timeline_events WHERE tenant_id=? AND resident_id=? ORDER BY created_at DESC',(a['tenant_id'],resident)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/workforce/operations/dashboard':
                    q=lambda sql: conn.execute(sql,(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{'activeEmployees':q("SELECT COUNT(*) FROM employee_profiles WHERE tenant_id=? AND lifecycle_status='ACTIVE'"),'clockedIn':q("SELECT COUNT(*) FROM workforce_time_entries WHERE tenant_id=? AND clock_out_at IS NULL"),'pendingLeave':q("SELECT COUNT(*) FROM leave_requests WHERE tenant_id=? AND status='SUBMITTED'"),'activeGoals':q("SELECT COUNT(*) FROM workforce_goals WHERE tenant_id=? AND status='ACTIVE'")})
                if p=='/api/workforce/employees':
                    rows=conn.execute('SELECT * FROM employee_profiles WHERE tenant_id=? ORDER BY last_name,first_name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/workforce/time-entries':
                    rows=conn.execute('SELECT * FROM workforce_time_entries WHERE tenant_id=? ORDER BY clock_in_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/workforce/leave-requests':
                    rows=conn.execute('SELECT * FROM leave_requests WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/workforce/goals':
                    rows=conn.execute('SELECT * FROM workforce_goals WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/dashboard':
                    q=lambda sql: conn.execute(sql,(a['tenant_id'],)).fetchone()[0]
                    budget=conn.execute("SELECT COALESCE(SUM(approved_amount_cents),0) approved,COALESCE(SUM(committed_amount_cents),0) committed,COALESCE(SUM(actual_amount_cents),0) actual FROM budgets WHERE tenant_id=?",(a['tenant_id'],)).fetchone()
                    return self.send_json(200,{'activeVendors':q("SELECT COUNT(*) FROM vendors WHERE tenant_id=? AND status='ACTIVE'"),'pendingPurchaseRequests':q("SELECT COUNT(*) FROM purchase_requests WHERE tenant_id=? AND status IN ('SUBMITTED','MANAGER_APPROVED')"),'openPurchaseOrders':q("SELECT COUNT(*) FROM purchase_orders WHERE tenant_id=? AND status NOT IN ('CLOSED','CANCELLED')"),'activeAssets':q("SELECT COUNT(*) FROM assets WHERE tenant_id=? AND status IN ('ACTIVE','ASSIGNED')"),'maintenanceDue':q("SELECT COUNT(*) FROM asset_maintenance WHERE tenant_id=? AND status='SCHEDULED' AND scheduled_at<=datetime('now','+30 days')"),'activeGrants':q("SELECT COUNT(*) FROM grants WHERE tenant_id=? AND status IN ('AWARDED','ACTIVE')"),'budget':dict(budget)})
                if p=='/api/finance/vendors':
                    rows=conn.execute('SELECT * FROM vendors WHERE tenant_id=? ORDER BY preferred DESC,name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/purchase-requests':
                    rows=conn.execute('SELECT pr.*,v.name vendor_name,b.name budget_name FROM purchase_requests pr LEFT JOIN vendors v ON v.id=pr.vendor_id LEFT JOIN budgets b ON b.id=pr.budget_id WHERE pr.tenant_id=? ORDER BY pr.created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/purchase-orders':
                    rows=conn.execute('SELECT po.*,v.name vendor_name FROM purchase_orders po LEFT JOIN vendors v ON v.id=po.vendor_id WHERE po.tenant_id=? ORDER BY po.issued_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/assets':
                    rows=conn.execute('SELECT * FROM assets WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/budgets':
                    rows=conn.execute('SELECT *,approved_amount_cents-committed_amount_cents remaining_cents FROM budgets WHERE tenant_id=? ORDER BY fiscal_year DESC,name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/grants':
                    rows=conn.execute('SELECT * FROM grants WHERE tenant_id=? ORDER BY COALESCE(reporting_due_at,application_due_at),name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/contracts':
                    rows=conn.execute('SELECT vc.*,v.name vendor_name FROM vendor_contracts vc JOIN vendors v ON v.id=vc.vendor_id WHERE vc.tenant_id=? ORDER BY COALESCE(vc.ends_at,vc.starts_at),v.name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/invoices':
                    rows=conn.execute('SELECT i.*,v.name vendor_name,po.po_number FROM vendor_invoices i JOIN vendors v ON v.id=i.vendor_id LEFT JOIN purchase_orders po ON po.id=i.purchase_order_id WHERE i.tenant_id=? ORDER BY i.created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/approval-queue':
                    prs=conn.execute("SELECT * FROM purchase_requests WHERE tenant_id=? AND status IN ('SUBMITTED','MANAGER_APPROVED') ORDER BY created_at",(a['tenant_id'],)).fetchall()
                    inv=conn.execute("SELECT * FROM vendor_invoices WHERE tenant_id=? AND status IN ('RECEIVED','DISCREPANCY') ORDER BY due_date",(a['tenant_id'],)).fetchall()
                    return self.send_json(200,{'purchaseRequests':[dict(r) for r in prs],'invoices':[dict(r) for r in inv]})
                if p=='/api/finance/reminders':
                    rows=conn.execute("SELECT * FROM finance_reminders WHERE tenant_id=? AND status='OPEN' ORDER BY due_at",(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/finance/scorecard':
                    b=conn.execute('SELECT COALESCE(SUM(approved_amount_cents),0),COALESCE(SUM(committed_amount_cents),0),COALESCE(SUM(actual_amount_cents),0) FROM budgets WHERE tenant_id=?',(a['tenant_id'],)).fetchone()
                    exp=conn.execute("SELECT COUNT(*) FROM vendor_compliance_items WHERE tenant_id=? AND expires_at IS NOT NULL AND expires_at<=datetime('now','+30 days') AND status<>'EXPIRED'",(a['tenant_id'],)).fetchone()[0]
                    disc=conn.execute("SELECT COUNT(*) FROM invoice_discrepancies WHERE tenant_id=? AND status='OPEN'",(a['tenant_id'],)).fetchone()[0]
                    deliver=conn.execute("SELECT COUNT(*) FROM grant_deliverables WHERE tenant_id=? AND status='OPEN' AND due_at<=datetime('now','+30 days')",(a['tenant_id'],)).fetchone()[0]
                    return self.send_json(200,{'budgetApprovedCents':b[0],'budgetCommittedCents':b[1],'budgetActualCents':b[2],'budgetVarianceCents':b[0]-b[2],'vendorComplianceExpiring':exp,'openInvoiceDiscrepancies':disc,'grantDeliverablesDue':deliver})
                if p=='/api/analytics/catalog':
                    rows=conn.execute('SELECT * FROM kpi_definitions WHERE tenant_id=? AND active=1 ORDER BY domain,name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/scorecard':
                    def pct(n,d): return round((n*100.0/d),1) if d else 0.0
                    residents=conn.execute("SELECT COUNT(*) FROM residents WHERE tenant_id=? AND status='ACTIVE'",(a['tenant_id'],)).fetchone()[0]
                    beds=conn.execute("SELECT COUNT(*) FROM beds WHERE tenant_id=?",(a['tenant_id'],)).fetchone()[0]
                    refs=conn.execute("SELECT COUNT(*) FROM referrals WHERE tenant_id=?",(a['tenant_id'],)).fetchone()[0]
                    admitted=conn.execute("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND status='ADMITTED'",(a['tenant_id'],)).fetchone()[0]
                    tasks=conn.execute("SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=?",(a['tenant_id'],)).fetchone()[0]
                    done=conn.execute("SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=? AND status='COMPLETED'",(a['tenant_id'],)).fetchone()[0]
                    active_emp=conn.execute("SELECT COUNT(*) FROM employee_profiles WHERE tenant_id=? AND lifecycle_status='ACTIVE'",(a['tenant_id'],)).fetchone()[0]
                    budget=conn.execute('SELECT COALESCE(SUM(approved_amount_cents),0),COALESCE(SUM(actual_amount_cents),0) FROM budgets WHERE tenant_id=?',(a['tenant_id'],)).fetchone()
                    open_inc=conn.execute("SELECT COUNT(*) FROM quick_incidents WHERE tenant_id=? AND status IN ('REPORTED','ESCALATED')",(a['tenant_id'],)).fetchone()[0]
                    metrics={'occupancy_rate':pct(residents,beds),'referral_conversion_rate':pct(admitted,refs),'documentation_completion_rate':pct(done,tasks),'credential_compliance_rate':100.0 if active_emp else 0.0,'budget_utilization_rate':pct(budget[1],budget[0]),'open_incidents':open_inc}
                    return self.send_json(200,{'generatedAt':now_iso(),'metrics':metrics})
                if p.startswith('/api/analytics/dashboard-layouts'):
                    role=(parse_qs(urlparse(self.path).query).get('role') or [a.get('role','EXECUTIVE')])[0].upper()
                    layouts=conn.execute('SELECT * FROM dashboard_layouts WHERE tenant_id=? AND role_key=? ORDER BY is_default DESC,name',(a['tenant_id'],role)).fetchall()
                    result=[]
                    for layout in layouts:
                        item=dict(layout); item['widgets']=[dict(x) for x in conn.execute('SELECT * FROM dashboard_layout_widgets WHERE tenant_id=? AND layout_id=? AND active=1 ORDER BY position',(a['tenant_id'],layout['id'])).fetchall()]; result.append(item)
                    return self.send_json(200,result)
                if p=='/api/analytics/comparisons':
                    q=parse_qs(urlparse(self.path).query); key=(q.get('metricKey') or ['occupancy_rate'])[0]
                    rows=conn.execute('SELECT value,snapshot_at FROM kpi_snapshots WHERE tenant_id=? AND metric_key=? ORDER BY snapshot_at DESC LIMIT 2',(a['tenant_id'],key)).fetchall()
                    current=float(rows[0]['value']) if rows else 0.0; previous=float(rows[1]['value']) if len(rows)>1 else None
                    change=None if previous is None else round(current-previous,2); pct=None if previous in (None,0) else round(change*100.0/previous,2)
                    return self.send_json(200,{'metricKey':key,'current':current,'previous':previous,'absoluteChange':change,'percentChange':pct,'direction':'UP' if change and change>0 else 'DOWN' if change and change<0 else 'FLAT'})
                if p=='/api/analytics/briefings':
                    q=parse_qs(urlparse(self.path).query); kind=(q.get('type') or ['EXECUTIVE'])[0]
                    rows=conn.execute('SELECT * FROM executive_briefings WHERE tenant_id=? AND briefing_type=? ORDER BY briefing_date DESC,created_at DESC',(a['tenant_id'],kind)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/report-subscriptions':
                    rows=conn.execute('SELECT s.*,d.name report_name FROM report_subscriptions s JOIN report_definitions d ON d.id=s.report_definition_id WHERE s.tenant_id=? ORDER BY s.created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/report-deliveries':
                    rows=conn.execute('SELECT * FROM report_delivery_history WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/remediation-tasks':
                    rows=conn.execute("SELECT * FROM data_quality_remediation_tasks WHERE tenant_id=? ORDER BY CASE status WHEN 'OPEN' THEN 0 ELSE 1 END,due_at",(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/metric-certifications':
                    rows=conn.execute('SELECT c.*,k.name,k.domain,k.unit FROM metric_certifications c JOIN kpi_definitions k ON k.tenant_id=c.tenant_id AND k.metric_key=c.metric_key WHERE c.tenant_id=? ORDER BY k.domain,k.name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/export':
                    q=parse_qs(urlparse(self.path).query); key=(q.get('reportKey') or ['executive-scorecard'])[0]; fmt=(q.get('format') or ['CSV'])[0].upper()
                    metrics=conn.execute('SELECT d.metric_key,d.name,d.domain,d.unit,s.value,s.snapshot_at FROM kpi_definitions d LEFT JOIN kpi_snapshots s ON s.id=(SELECT id FROM kpi_snapshots x WHERE x.tenant_id=d.tenant_id AND x.metric_key=d.metric_key ORDER BY snapshot_at DESC LIMIT 1) WHERE d.tenant_id=? ORDER BY d.domain,d.name',(a['tenant_id'],)).fetchall()
                    if fmt=='CSV':
                        lines=['metric_key,name,domain,unit,value,snapshot_at']+[','.join(str(r[k] if r[k] is not None else '').replace(',',' ') for k in ['metric_key','name','domain','unit','value','snapshot_at']) for r in metrics]
                        return self.send_json(200,{'reportKey':key,'format':'CSV','fileName':key+'.csv','content':'\n'.join(lines),'rowCount':len(metrics)})
                    return self.send_json(200,{'reportKey':key,'format':fmt,'status':'FOUNDATION','message':'Rendering adapter required for binary output','rowCount':len(metrics)})
                if p=='/api/analytics/trends':
                    qs=parse_qs(urlparse(self.path).query); key=(qs.get('metricKey') or [None])[0]
                    if not key:return self.send_json(422,{'error':'metricKey_required'})
                    rows=conn.execute('SELECT * FROM kpi_snapshots WHERE tenant_id=? AND metric_key=? ORDER BY snapshot_at',(a['tenant_id'],key)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/reports':
                    rows=conn.execute('SELECT * FROM report_definitions WHERE tenant_id=? ORDER BY name',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/analytics/data-quality':
                    latest=[]
                    for c in conn.execute('SELECT * FROM data_quality_checks WHERE tenant_id=? AND active=1 ORDER BY domain,name',(a['tenant_id'],)).fetchall():
                        r=conn.execute('SELECT * FROM data_quality_results WHERE tenant_id=? AND check_key=? ORDER BY checked_at DESC LIMIT 1',(a['tenant_id'],c['check_key'])).fetchone(); d=dict(c); d['latest']=dict(r) if r else None; latest.append(d)
                    return self.send_json(200,latest)
                if p=='/api/referrals':
                    rows=conn.execute('SELECT * FROM referrals WHERE tenant_id=? ORDER BY created_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p.startswith('/api/referrals/'):
                    parts=p.strip('/').split('/')
                    if len(parts)>=3:
                        rid=parts[2]
                        ref=conn.execute('SELECT * FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                        if not ref:return self.send_json(404,{'error':'not_found'})
                        if len(parts)==3:
                            acts=conn.execute('SELECT * FROM referral_activities WHERE tenant_id=? AND referral_id=? ORDER BY created_at DESC',(a['tenant_id'],rid)).fetchall()
                            out=dict(ref);out['activities']=[dict(x) for x in acts]
                            out['supportNeeds']=[dict(x) for x in conn.execute('SELECT * FROM referral_support_needs WHERE tenant_id=? AND referral_id=? ORDER BY domain',(a['tenant_id'],rid)).fetchall()]
                            out['fundingChecklist']=[dict(x) for x in conn.execute('SELECT * FROM referral_funding_items WHERE tenant_id=? AND referral_id=? ORDER BY item_type',(a['tenant_id'],rid)).fetchall()]
                            out['assignments']=[dict(x) for x in conn.execute('SELECT * FROM referral_assignments WHERE tenant_id=? AND referral_id=? AND ended_at IS NULL',(a['tenant_id'],rid)).fetchall()]
                            out['tasks']=[dict(x) for x in conn.execute('SELECT * FROM intake_tasks WHERE tenant_id=? AND referral_id=? ORDER BY due_at',(a['tenant_id'],rid)).fetchall()]
                            out['documents']=[dict(x) for x in conn.execute('SELECT * FROM intake_documents WHERE tenant_id=? AND referral_id=? ORDER BY created_at DESC',(a['tenant_id'],rid)).fetchall()]
                            out['communications']=[dict(x) for x in conn.execute('SELECT * FROM referral_communications WHERE tenant_id=? AND referral_id=? ORDER BY created_at DESC',(a['tenant_id'],rid)).fetchall()]
                            out['meetings']=[dict(x) for x in conn.execute('SELECT * FROM intake_meetings WHERE tenant_id=? AND referral_id=? ORDER BY scheduled_at',(a['tenant_id'],rid)).fetchall()]
                            out['screeningOutcomes']=[dict(x) for x in conn.execute('SELECT * FROM screening_outcomes WHERE tenant_id=? AND referral_id=? ORDER BY decided_at DESC',(a['tenant_id'],rid)).fetchall()]
                            out['waitlist']=[dict(x) for x in conn.execute('SELECT * FROM waitlist_entries WHERE tenant_id=? AND referral_id=?',(a['tenant_id'],rid)).fetchall()]
                            out['duplicateMatches']=[dict(x) for x in conn.execute('SELECT * FROM duplicate_referral_matches WHERE tenant_id=? AND referral_id=?',(a['tenant_id'],rid)).fetchall()]
                            return self.send_json(200,out)
                        if len(parts)==4 and parts[3]=='activities':
                            acts=conn.execute('SELECT * FROM referral_activities WHERE tenant_id=? AND referral_id=? ORDER BY created_at DESC',(a['tenant_id'],rid)).fetchall();return self.send_json(200,[dict(x) for x in acts])
                if p=='/api/homes':
                    homes=[]
                    for h in conn.execute('SELECT * FROM homes WHERE tenant_id=?',(a['tenant_id'],)).fetchall():
                        d=dict(h); d['beds']=[dict(x) for x in conn.execute('SELECT * FROM beds WHERE tenant_id=? AND home_id=?',(a['tenant_id'],h['id'])).fetchall()]; homes.append(d)
                    return self.send_json(200,homes)
                if p=='/api/residents':
                    rows=conn.execute('SELECT r.*,h.name home_name,b.label bed_label FROM residents r JOIN homes h ON h.id=r.home_id JOIN beds b ON b.id=r.bed_id WHERE r.tenant_id=? ORDER BY r.admitted_at DESC',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
                if p=='/api/audit':
                    rows=conn.execute('SELECT * FROM audit_events WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100',(a['tenant_id'],)).fetchall(); return self.send_json(200,[dict(r) for r in rows])
            return self.send_json(404,{'error':'not_found'})
        return super().do_GET()
    def do_POST(self):
        p=urlparse(self.path).path; data=self.read_json()
        if data is None:return self.send_json(400,{'error':'invalid_json'})
        if p=='/api/login':
            with db() as conn:
                tenant_slug=data.get('tenantSlug')
                if tenant_slug:
                    row=conn.execute('SELECT u.* FROM users u JOIN tenants t ON t.id=u.tenant_id WHERE u.email=? AND t.slug=?',(data.get('email',''),tenant_slug)).fetchone()
                else:
                    row=conn.execute('SELECT * FROM users WHERE email=?',(data.get('email',''),)).fetchone()
                success=bool(row and verify_password(data.get('password',''),row['password_hash']))
                conn.execute('INSERT INTO login_history(id,tenant_id,user_id,email,tenant_slug,success,reason,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?,?)',(uid('login'),row['tenant_id'] if row else None,row['id'] if row else None,data.get('email',''),tenant_slug,int(success),None if success else 'invalid_credentials',self.client_address[0],self.headers.get('User-Agent')))
                if not success:return self.send_json(401,{'error':'invalid_credentials'})
                fingerprint=hashlib.sha256(f"{self.client_address[0]}|{self.headers.get('User-Agent','')}".encode()).hexdigest()
                existing=conn.execute('SELECT id FROM devices WHERE tenant_id=? AND user_id=? AND fingerprint=?',(row['tenant_id'],row['id'],fingerprint)).fetchone()
                device_id=existing['id'] if existing else uid('device')
                if existing: conn.execute('UPDATE devices SET last_seen_at=? WHERE id=?',(now_iso(),device_id))
                else: conn.execute('INSERT INTO devices(id,tenant_id,user_id,fingerprint,display_name,last_seen_at) VALUES(?,?,?,?,?,?)',(device_id,row['tenant_id'],row['id'],fingerprint,self.headers.get('User-Agent','Unknown device')[:120],now_iso()))
                token=secrets.token_urlsafe(32); expires=(datetime.now(timezone.utc)+timedelta(hours=8)).isoformat()
                conn.execute('INSERT INTO sessions(token,user_id,tenant_id,expires_at,last_seen_at,ip_address,user_agent,device_id) VALUES(?,?,?,?,?,?,?,?)',(token,row['id'],row['tenant_id'],expires,now_iso(),self.client_address[0],self.headers.get('User-Agent'),device_id))
                return self.send_json(200,{'token':token,'expiresAt':expires,'user':{'email':row['email'],'role':row['role']},'deviceId':device_id})
        if p=='/api/password-reset/request':
            with db() as conn:
                tenant_slug=data.get('tenantSlug'); email=str(data.get('email','')).lower()
                row=conn.execute('SELECT u.* FROM users u JOIN tenants t ON t.id=u.tenant_id WHERE u.email=? AND t.slug=?',(email,tenant_slug)).fetchone()
                if row:
                    raw=secrets.token_urlsafe(32); token_hash=hashlib.sha256(raw.encode()).hexdigest(); expires=(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat()
                    conn.execute('INSERT INTO password_reset_tokens(id,tenant_id,user_id,token_hash,expires_at) VALUES(?,?,?,?,?)',(uid('reset'),row['tenant_id'],row['id'],token_hash,expires))
                    return self.send_json(200,{'accepted':True,'developmentToken':raw})
            return self.send_json(200,{'accepted':True})
        if p=='/api/password-reset/confirm':
            raw=str(data.get('token','')); new_password=str(data.get('newPassword',''))
            if len(new_password)<12:return self.send_json(422,{'error':'password_too_short'})
            token_hash=hashlib.sha256(raw.encode()).hexdigest()
            with db() as conn:
                row=conn.execute('SELECT * FROM password_reset_tokens WHERE token_hash=? AND consumed_at IS NULL AND expires_at>?',(token_hash,now_iso())).fetchone()
                if not row:return self.send_json(400,{'error':'invalid_or_expired_token'})
                conn.execute('UPDATE users SET password_hash=? WHERE id=?',(hash_password(new_password),row['user_id']))
                conn.execute('UPDATE password_reset_tokens SET consumed_at=? WHERE id=?',(now_iso(),row['id']))
                conn.execute('UPDATE sessions SET revoked_at=? WHERE user_id=? AND tenant_id=? AND revoked_at IS NULL',(now_iso(),row['user_id'],row['tenant_id']))
                return self.send_json(200,{'passwordReset':True})
        a=self.auth()
        if not a:return self.send_json(401,{'error':'unauthorized'})
        if p=='/api/logout':
            with db() as conn:
                conn.execute('UPDATE sessions SET revoked_at=? WHERE token=?',(now_iso(),self.headers.get('Authorization','')[7:]))
            return self.send_json(200,{'loggedOut':True})
        with db() as conn:
            if p=='/api/ai/knowledge-sources':
                required=['sourceKey','title','collectionKey','content']
                if any(not data.get(k) for k in required): return self.send_json(400,{'error':'missing_required_fields','required':required})
                source_id=uid('aisrc'); content=data['content'].strip(); checksum=hashlib.sha256(content.encode()).hexdigest()
                try:
                    conn.execute('INSERT INTO ai_knowledge_sources(id,tenant_id,source_key,title,collection_key,source_type,version,status,owner_user_id,effective_at,review_at,content,checksum) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(source_id,a['tenant_id'],data['sourceKey'],data['title'],data['collectionKey'],data.get('sourceType','POLICY'),data.get('version','1.0'),'APPROVED',a['user_id'],data.get('effectiveAt') or now_iso(),data.get('reviewAt'),content,checksum))
                except sqlite3.IntegrityError:return self.send_json(409,{'error':'knowledge_source_conflict'})
                paragraphs=[x.strip() for x in content.replace('\r','').split('\n\n') if x.strip()] or [content]
                for idx,chunk in enumerate(paragraphs): conn.execute('INSERT INTO ai_knowledge_chunks(id,tenant_id,source_id,chunk_index,heading,content,token_estimate,metadata_json) VALUES(?,?,?,?,?,?,?,?)',(uid('aichunk'),a['tenant_id'],source_id,idx,data.get('heading'),chunk,max(1,len(chunk.split())),json.dumps(data.get('metadata',{}))))
                self.audit(conn,a,'ai.knowledge_source_created','AIKnowledgeSource',source_id,{'sourceKey':data['sourceKey'],'chunks':len(paragraphs)})
                return self.send_json(201,dict(conn.execute('SELECT id,source_key,title,collection_key,version,status,checksum FROM ai_knowledge_sources WHERE id=?',(source_id,)).fetchone()))
            if p=='/api/ai/prompts':
                if not data.get('promptKey') or not data.get('name') or not data.get('content'): return self.send_json(400,{'error':'prompt_fields_required'})
                prompt_id=uid('aiprompt'); version_id=uid('aipromptver')
                conn.execute('INSERT INTO ai_prompts(id,tenant_id,prompt_key,name,owner_user_id,status) VALUES(?,?,?,?,?,?)',(prompt_id,a['tenant_id'],data['promptKey'],data['name'],a['user_id'],'ACTIVE'))
                conn.execute('INSERT INTO ai_prompt_versions(id,tenant_id,prompt_id,version_number,content,variables_json,status,approved_by_user_id,approved_at,effective_at) VALUES(?,?,?,?,?,?,?,?,?)',(version_id,a['tenant_id'],prompt_id,1,data['content'],json.dumps(data.get('variables',[])),'APPROVED',a['user_id'],now_iso(),now_iso()))
                self.audit(conn,a,'ai.prompt_created','AIPrompt',prompt_id,{'promptKey':data['promptKey']}); return self.send_json(201,{'id':prompt_id,'versionId':version_id,'version':1,'status':'APPROVED'})
            if p.startswith('/api/ai/agents/') and p.endswith('/run'):
                agent_key=p.split('/')[4]; agent=conn.execute("SELECT * FROM ai_agents WHERE tenant_id=? AND agent_key=? AND status='ACTIVE'",(a['tenant_id'],agent_key)).fetchone()
                if not agent:return self.send_json(404,{'error':'agent_not_found'})
                question=(data.get('question') or '').strip()
                if not question:return self.send_json(400,{'error':'question_required'})
                injection=self.ai_screen_prompt(question)
                if injection:
                    eid=uid('aisec'); conn.execute('INSERT INTO ai_security_events(id,tenant_id,user_id,event_type,severity,details_json) VALUES(?,?,?,?,?,?)',(eid,a['tenant_id'],a['user_id'],'PROMPT_INJECTION','HIGH',json.dumps({'pattern':injection})))
                    self.audit(conn,a,'ai.prompt_injection_blocked','AISecurityEvent',eid,{'pattern':injection})
                    return self.send_json(422,{'error':'prompt_injection_detected'})
                requested_tools=data.get('requestedTools') or []; allowed_tools=json.loads(agent['allowed_tools_json'] or '[]')
                denied=[t for t in requested_tools if t not in allowed_tools]
                if denied:return self.send_json(403,{'error':'tool_not_allowed','denied':denied})
                safe_question,redactions=self.ai_redact(question)
                started=datetime.now(timezone.utc); configured=json.loads(agent['allowed_collections_json'] or '[]'); allowed=[c for c in configured if self.ai_collection_allowed(conn,a['tenant_id'],a['role'],c)]; chunks=self.ai_retrieve(conn,a['tenant_id'],safe_question,allowed,4)
                citations=[{'sourceId':r['source_id'],'chunkId':r['id'],'title':r['title'],'version':r['version'],'heading':r['heading'],'excerpt':r['content'][:240]} for r in chunks]
                if chunks:
                    answer=' '.join(r['content'] for r in chunks)
                    answer=f"Based on approved AMC sources: {answer}"
                else: answer='No approved AMC knowledge source supports an answer to this question. Please consult a supervisor or add an approved source.'
                exec_id=uid('aiexec'); conv_id=data.get('conversationId') or uid('aiconv')
                if not data.get('conversationId'): conn.execute('INSERT INTO ai_conversations(id,tenant_id,user_id,agent_id,title,status) VALUES(?,?,?,?,?,?)',(conv_id,a['tenant_id'],a['user_id'],agent['id'],question[:100],'ACTIVE'))
                status='PENDING_APPROVAL' if agent['requires_approval'] else 'COMPLETED'; latency=max(1,int((datetime.now(timezone.utc)-started).total_seconds()*1000)); in_tok=max(1,len(safe_question.split())); out_tok=max(1,len(answer.split()))
                conn.execute('INSERT INTO ai_executions(id,tenant_id,conversation_id,agent_id,user_id,model_id,request_text,response_text,status,citations_json,input_tokens,output_tokens,estimated_cost,latency_ms) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(exec_id,a['tenant_id'],conv_id,agent['id'],a['user_id'],agent['model_id'],safe_question,answer,status,json.dumps(citations),in_tok,out_tok,0,latency))
                approval_id=None
                if agent['requires_approval']:
                    approval_id=uid('aiapproval'); conn.execute('INSERT INTO ai_approvals(id,tenant_id,execution_id,requested_by_user_id,assigned_to_user_id,status) VALUES(?,?,?,?,?,?)',(approval_id,a['tenant_id'],exec_id,a['user_id'],a['user_id'],'PENDING'))
                self.audit(conn,a,'ai.agent_executed','AIExecution',exec_id,{'agentKey':agent_key,'status':status,'citationCount':len(citations)})
                return self.send_json(201,{'executionId':exec_id,'conversationId':conv_id,'agentKey':agent_key,'status':status,'answer':answer,'citations':citations,'approvalId':approval_id,'redactions':redactions})
            if p=='/api/ai/feedback':
                execution=conn.execute('SELECT id FROM ai_executions WHERE id=? AND tenant_id=?',(data.get('executionId'),a['tenant_id'])).fetchone()
                if not execution:return self.send_json(404,{'error':'execution_not_found'})
                fid=uid('aifeedback'); conn.execute('INSERT INTO ai_feedback(id,tenant_id,execution_id,user_id,rating,helpful,correction_text,notes) VALUES(?,?,?,?,?,?,?,?)',(fid,a['tenant_id'],execution['id'],a['user_id'],data.get('rating'),1 if data.get('helpful') else 0,data.get('correctionText'),data.get('notes'))); return self.send_json(201,{'id':fid})
            if p=='/api/analytics/snapshots':
                score={}
                residents=conn.execute("SELECT COUNT(*) FROM residents WHERE tenant_id=? AND status='ACTIVE'",(a['tenant_id'],)).fetchone()[0]; beds=conn.execute('SELECT COUNT(*) FROM beds WHERE tenant_id=?',(a['tenant_id'],)).fetchone()[0]
                refs=conn.execute('SELECT COUNT(*) FROM referrals WHERE tenant_id=?',(a['tenant_id'],)).fetchone()[0]; admitted=conn.execute("SELECT COUNT(*) FROM referrals WHERE tenant_id=? AND status='ADMITTED'",(a['tenant_id'],)).fetchone()[0]
                tasks=conn.execute('SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=?',(a['tenant_id'],)).fetchone()[0]; done=conn.execute("SELECT COUNT(*) FROM resident_daily_tasks WHERE tenant_id=? AND status='COMPLETED'",(a['tenant_id'],)).fetchone()[0]
                b=conn.execute('SELECT COALESCE(SUM(approved_amount_cents),0),COALESCE(SUM(actual_amount_cents),0) FROM budgets WHERE tenant_id=?',(a['tenant_id'],)).fetchone(); open_inc=conn.execute("SELECT COUNT(*) FROM quick_incidents WHERE tenant_id=? AND status IN ('REPORTED','ESCALATED')",(a['tenant_id'],)).fetchone()[0]
                def pct(n,d): return round(n*100.0/d,1) if d else 0.0
                score={'occupancy_rate':pct(residents,beds),'referral_conversion_rate':pct(admitted,refs),'documentation_completion_rate':pct(done,tasks),'budget_utilization_rate':pct(b[1],b[0]),'open_incidents':open_inc}
                ts=now_iso()
                for key,val in score.items(): conn.execute('INSERT INTO kpi_snapshots(id,tenant_id,metric_key,snapshot_at,value) VALUES(?,?,?,?,?)',(uid('snap'),a['tenant_id'],key,ts,val))
                self.audit(conn,a,'analytics.snapshot_created','KpiSnapshot',ts,score); return self.send_json(201,{'snapshotAt':ts,'metrics':score})
            if p=='/api/analytics/reports':
                required=['reportKey','name','domain','queryKey']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                rid=uid('report'); conn.execute('INSERT INTO report_definitions(id,tenant_id,report_key,name,domain,format,query_key,parameters_json,created_by_user_id) VALUES(?,?,?,?,?,?,?,?,?)',(rid,a['tenant_id'],data['reportKey'],data['name'],data['domain'],data.get('format','CSV'),data['queryKey'],json.dumps(data.get('parameters',{})),a['user_id'])); return self.send_json(201,dict(conn.execute('SELECT * FROM report_definitions WHERE id=?',(rid,)).fetchone()))
            if p=='/api/analytics/report-schedules':
                required=['reportDefinitionId','cadence','nextRunAt']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                sid=uid('rsched'); conn.execute('INSERT INTO report_schedules(id,tenant_id,report_definition_id,cadence,next_run_at,recipients_json) VALUES(?,?,?,?,?,?)',(sid,a['tenant_id'],data['reportDefinitionId'],data['cadence'],data['nextRunAt'],json.dumps(data.get('recipients',[])))); return self.send_json(201,dict(conn.execute('SELECT * FROM report_schedules WHERE id=?',(sid,)).fetchone()))
            if p=='/api/analytics/dashboard-layouts':
                required=['roleKey','name']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                lid=uid('layout'); conn.execute('INSERT INTO dashboard_layouts(id,tenant_id,role_key,name,is_default,created_by_user_id) VALUES(?,?,?,?,?,?)',(lid,a['tenant_id'],data['roleKey'].upper(),data['name'],1 if data.get('isDefault') else 0,a['user_id']))
                for pos,w in enumerate(data.get('widgets',[])):
                    conn.execute('INSERT INTO dashboard_layout_widgets(id,tenant_id,layout_id,widget_key,title,metric_key,widget_type,position,width,height,config_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(uid('lwidget'),a['tenant_id'],lid,w.get('widgetKey') or f'widget-{pos}',w.get('title') or w.get('metricKey') or 'Widget',w.get('metricKey'),w.get('widgetType','METRIC'),w.get('position',pos),w.get('width',1),w.get('height',1),json.dumps(w.get('config',{}))))
                self.audit(conn,a,'analytics.dashboard_layout_created','DashboardLayout',lid); return self.send_json(201,dict(conn.execute('SELECT * FROM dashboard_layouts WHERE id=?',(lid,)).fetchone()))
            if p=='/api/analytics/report-subscriptions':
                required=['reportDefinitionId']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                if not conn.execute('SELECT 1 FROM report_definitions WHERE id=? AND tenant_id=?',(data['reportDefinitionId'],a['tenant_id'])).fetchone():return self.send_json(404,{'error':'report_not_found'})
                sid=uid('sub'); conn.execute('INSERT INTO report_subscriptions(id,tenant_id,report_definition_id,subscriber_user_id,delivery_channel,cadence,recipients_json,next_delivery_at) VALUES(?,?,?,?,?,?,?,?)',(sid,a['tenant_id'],data['reportDefinitionId'],a['user_id'],data.get('deliveryChannel','IN_APP'),data.get('cadence','DAILY'),json.dumps(data.get('recipients',[])),data.get('nextDeliveryAt') or now_iso())); return self.send_json(201,dict(conn.execute('SELECT * FROM report_subscriptions WHERE id=?',(sid,)).fetchone()))
            if p=='/api/analytics/briefings/generate':
                kind=str(data.get('type','EXECUTIVE')).upper(); day=(data.get('date') or now_iso()[:10]); score=self._analytics_scorecard(conn,a['tenant_id'])
                risks=[]; actions=[]; highlights=[]
                for key,val in score.items():
                    definition=conn.execute('SELECT * FROM kpi_definitions WHERE tenant_id=? AND metric_key=?',(a['tenant_id'],key)).fetchone()
                    target=float(definition['target_value']) if definition and definition['target_value'] is not None else None
                    if key=='open_incidents' and val>0: risks.append(f'{int(val)} open incident(s) require review'); actions.append('Review open incident queue')
                    elif target is not None and float(val)<target: risks.append(f"{definition['name']} is {val} versus target {target}"); actions.append(f"Assign improvement owner for {definition['name']}")
                    else: highlights.append(f"{definition['name'] if definition else key}: {val}")
                bid=uid('brief'); summary=f"{kind.title()} briefing generated from {len(score)} certified or active KPIs."
                conn.execute('INSERT OR REPLACE INTO executive_briefings(id,tenant_id,briefing_type,briefing_date,title,summary,highlights_json,risks_json,actions_json,generated_by) VALUES(?,?,?,?,?,?,?,?,?,?)',(bid,a['tenant_id'],kind,day,f'{kind.title()} Morning Briefing',summary,json.dumps(highlights),json.dumps(risks),json.dumps(actions),'RULES'))
                return self.send_json(201,dict(conn.execute('SELECT * FROM executive_briefings WHERE id=?',(bid,)).fetchone()))
            if p=='/api/analytics/remediation-tasks':
                required=['checkKey','title']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                tid=uid('dqtask'); conn.execute('INSERT INTO data_quality_remediation_tasks(id,tenant_id,check_key,result_id,title,description,priority,assigned_user_id,due_at) VALUES(?,?,?,?,?,?,?,?,?)',(tid,a['tenant_id'],data['checkKey'],data.get('resultId'),data['title'],data.get('description'),data.get('priority','NORMAL'),data.get('assignedUserId'),data.get('dueAt'))); return self.send_json(201,dict(conn.execute('SELECT * FROM data_quality_remediation_tasks WHERE id=?',(tid,)).fetchone()))
            if p=='/api/analytics/process':
                now=now_iso(); snapshots=0; reports=0; checks=0
                # snapshot via duplicated lightweight calculations
                residents=conn.execute("SELECT COUNT(*) FROM residents WHERE tenant_id=? AND status='ACTIVE'",(a['tenant_id'],)).fetchone()[0]; beds=conn.execute('SELECT COUNT(*) FROM beds WHERE tenant_id=?',(a['tenant_id'],)).fetchone()[0]
                val=round(residents*100.0/beds,1) if beds else 0.0; conn.execute('INSERT INTO kpi_snapshots(id,tenant_id,metric_key,snapshot_at,value) VALUES(?,?,?,?,?)',(uid('snap'),a['tenant_id'],'occupancy_rate',now,val)); snapshots+=1
                for sched in conn.execute("SELECT * FROM report_schedules WHERE tenant_id=? AND status='ACTIVE' AND next_run_at<=?",(a['tenant_id'],now)).fetchall():
                    run=uid('rrun'); conn.execute('INSERT INTO report_runs(id,tenant_id,report_definition_id,status,started_at,completed_at,output_format,row_count) VALUES(?,?,?,?,?,?,?,?)',(run,a['tenant_id'],sched['report_definition_id'],'COMPLETED',now,now,'CSV',0)); conn.execute("UPDATE report_schedules SET last_run_at=?,next_run_at=datetime(next_run_at,'+1 day') WHERE id=?",(now,sched['id'])); reports+=1
                issues={'missing_resident_home':conn.execute('SELECT COUNT(*) FROM residents WHERE tenant_id=? AND home_id IS NULL',(a['tenant_id'],)).fetchone()[0],'overdue_intake_tasks':conn.execute("SELECT COUNT(*) FROM intake_tasks WHERE tenant_id=? AND status='OPEN' AND due_at<CURRENT_TIMESTAMP",(a['tenant_id'],)).fetchone()[0],'expired_vendor_compliance':conn.execute("SELECT COUNT(*) FROM vendor_compliance_items WHERE tenant_id=? AND expires_at<CURRENT_TIMESTAMP",(a['tenant_id'],)).fetchone()[0],'open_quality_issues':conn.execute("SELECT COUNT(*) FROM documentation_quality_issues WHERE tenant_id=? AND status='OPEN'",(a['tenant_id'],)).fetchone()[0]}
                for key,count in issues.items(): conn.execute('INSERT INTO data_quality_results(id,tenant_id,check_key,checked_at,status,issue_count,details_json) VALUES(?,?,?,?,?,?,?)',(uid('dqres'),a['tenant_id'],key,now,'PASS' if count==0 else 'FAIL',count,json.dumps({'issueCount':count}))); checks+=1
                deliveries=0; remediation=0
                for sub in conn.execute("SELECT * FROM report_subscriptions WHERE tenant_id=? AND active=1 AND COALESCE(next_delivery_at,'')<=?",(a['tenant_id'],now)).fetchall():
                    did=uid('delivery'); recipient=(json.loads(sub['recipients_json'] or '[]') or [a['user_id']])[0]
                    conn.execute('INSERT INTO report_delivery_history(id,tenant_id,subscription_id,channel,recipient,status,delivered_at) VALUES(?,?,?,?,?,?,?)',(did,a['tenant_id'],sub['id'],sub['delivery_channel'],recipient,'DELIVERED',now)); conn.execute("UPDATE report_subscriptions SET next_delivery_at=datetime(COALESCE(next_delivery_at,?),'+1 day') WHERE id=?",(now,sub['id'])); deliveries+=1
                for r in conn.execute("SELECT * FROM data_quality_results WHERE tenant_id=? AND status='FAIL' AND NOT EXISTS (SELECT 1 FROM data_quality_remediation_tasks t WHERE t.tenant_id=data_quality_results.tenant_id AND t.result_id=data_quality_results.id AND t.status='OPEN')",(a['tenant_id'],)).fetchall():
                    conn.execute('INSERT INTO data_quality_remediation_tasks(id,tenant_id,check_key,result_id,title,description,priority,due_at) VALUES(?,?,?,?,?,?,?,?)',(uid('dqtask'),a['tenant_id'],r['check_key'],r['id'],f"Remediate {r['check_key']}",f"Resolve {r['issue_count']} data quality issue(s)",'HIGH' if r['issue_count']>5 else 'NORMAL',(datetime.now(timezone.utc)+timedelta(days=7)).isoformat())); remediation+=1
                return self.send_json(200,{'snapshotsCreated':snapshots,'reportsRun':reports,'qualityChecksRun':checks,'deliveriesProcessed':deliveries,'remediationTasksCreated':remediation})
            if p=='/api/daily-service/shifts/start':
                required=['homeId','employeeId']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                if conn.execute("SELECT 1 FROM service_shifts WHERE tenant_id=? AND employee_id=? AND status='ACTIVE'",(a['tenant_id'],data['employeeId'])).fetchone():return self.send_json(409,{'error':'active_shift_exists'})
                sid=uid('sshift'); conn.execute('INSERT INTO service_shifts(id,tenant_id,home_id,employee_id,status,started_at) VALUES(?,?,?,?,?,?)',(sid,a['tenant_id'],data['homeId'],data['employeeId'],'ACTIVE',now_iso())); self.audit(conn,a,'service_shift.started','ServiceShift',sid); return self.send_json(201,dict(conn.execute('SELECT * FROM service_shifts WHERE id=?',(sid,)).fetchone()))
            if p=='/api/daily-service/recurring-tasks':
                required=['residentId','homeId','title','recurrence','nextDueAt']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                rid=uid('rtpl'); conn.execute('INSERT INTO recurring_task_templates(id,tenant_id,resident_id,home_id,title,task_type,recurrence,next_due_at,priority,assigned_employee_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(rid,a['tenant_id'],data['residentId'],data['homeId'],data['title'],data.get('taskType','GENERAL'),data['recurrence'],data['nextDueAt'],data.get('priority','NORMAL'),data.get('assignedEmployeeId'),a['user_id'])); return self.send_json(201,dict(conn.execute('SELECT * FROM recurring_task_templates WHERE id=?',(rid,)).fetchone()))
            if p=='/api/daily-service/process-automation':
                now=now_iso(); created=reminders=escalations=quality=0
                for t in conn.execute("SELECT * FROM recurring_task_templates WHERE tenant_id=? AND active=1 AND next_due_at<=?",(a['tenant_id'],now)).fetchall():
                    tid=uid('rtask'); conn.execute('INSERT INTO resident_daily_tasks(id,tenant_id,resident_id,home_id,title,task_type,due_at,priority,assigned_employee_id,recurring_template_id) VALUES(?,?,?,?,?,?,?,?,?,?)',(tid,a['tenant_id'],t['resident_id'],t['home_id'],t['title'],t['task_type'],t['next_due_at'],t['priority'],t['assigned_employee_id'],t['id']))
                    step=timedelta(days=1 if t['recurrence']=='DAILY' else 7); conn.execute('UPDATE recurring_task_templates SET next_due_at=? WHERE id=?',((datetime.fromisoformat(t['next_due_at'])+step).isoformat(),t['id'])); created+=1
                for t in conn.execute("SELECT * FROM resident_daily_tasks WHERE tenant_id=? AND status IN ('OPEN','IN_PROGRESS') AND due_at<CURRENT_TIMESTAMP",(a['tenant_id'],)).fetchall():
                    conn.execute('UPDATE resident_daily_tasks SET escalation_level=escalation_level+1,reminder_sent_at=? WHERE id=?',(now,t['id'])); self.notify(conn,a,f"Overdue resident task: {t['title']}",'Resident task overdue',t['assigned_employee_id']); escalations+=1
                    conn.execute('INSERT INTO documentation_quality_issues(id,tenant_id,home_id,resident_id,issue_type,severity,message,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?)',(uid('qissue'),a['tenant_id'],t['home_id'],t['resident_id'],'OVERDUE_TASK','WARNING',f"Overdue task: {t['title']}",'ResidentDailyTask',t['id'])); quality+=1
                for ap in conn.execute("SELECT * FROM resident_appointments WHERE tenant_id=? AND status='SCHEDULED' AND starts_at<=datetime('now','+24 hours') AND reminder_sent_at IS NULL",(a['tenant_id'],)).fetchall():
                    self.notify(conn,a,f"Appointment due: {ap['appointment_type']}",'Appointment reminder'); conn.execute('UPDATE resident_appointments SET reminder_sent_at=? WHERE id=?',(now,ap['id'])); reminders+=1
                return self.send_json(200,{'recurringTasksCreated':created,'taskEscalations':escalations,'appointmentReminders':reminders,'qualityIssuesCreated':quality})
            if p=='/api/daily-service/handoffs':
                required=['homeId','outgoingEmployeeId','summary']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                hid=uid('handoff'); conn.execute('INSERT INTO shift_handoffs(id,tenant_id,shift_id,home_id,outgoing_employee_id,incoming_employee_id,summary,resident_alerts,outstanding_tasks,supervisor_notes,status,submitted_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(hid,a['tenant_id'],data.get('shiftId'),data['homeId'],data['outgoingEmployeeId'],data.get('incomingEmployeeId'),data['summary'],json.dumps(data.get('residentAlerts',[])),json.dumps(data.get('outstandingTasks',[])),data.get('supervisorNotes'),'SUBMITTED',now_iso())); self.audit(conn,a,'shift_handoff.submitted','ShiftHandoff',hid); return self.send_json(201,dict(conn.execute('SELECT * FROM shift_handoffs WHERE id=?',(hid,)).fetchone()))
            if p=='/api/daily-service/tasks':
                required=['residentId','homeId','title']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                tid=uid('rtask'); conn.execute('INSERT INTO resident_daily_tasks(id,tenant_id,resident_id,home_id,title,task_type,due_at,priority,assigned_employee_id,notes) VALUES(?,?,?,?,?,?,?,?,?,?)',(tid,a['tenant_id'],data['residentId'],data['homeId'],data['title'],data.get('taskType','GENERAL'),data.get('dueAt'),data.get('priority','NORMAL'),data.get('assignedEmployeeId'),data.get('notes'))); return self.send_json(201,dict(conn.execute('SELECT * FROM resident_daily_tasks WHERE id=?',(tid,)).fetchone()))
            if p=='/api/daily-service/appointments':
                required=['residentId','appointmentType','startsAt']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                aid=uid('appt'); conn.execute('INSERT INTO resident_appointments(id,tenant_id,resident_id,appointment_type,provider_name,location,starts_at,ends_at,transportation_required,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',(aid,a['tenant_id'],data['residentId'],data['appointmentType'],data.get('providerName'),data.get('location'),data['startsAt'],data.get('endsAt'),int(bool(data.get('transportationRequired'))),a['user_id'])); return self.send_json(201,dict(conn.execute('SELECT * FROM resident_appointments WHERE id=?',(aid,)).fetchone()))
            if p=='/api/daily-service/guardian-communications':
                required=['residentId','contactName','channel','direction','summary']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                cid=uid('gcomm'); conn.execute('INSERT INTO guardian_communications(id,tenant_id,resident_id,contact_name,relationship,channel,direction,subject,summary,follow_up_at,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(cid,a['tenant_id'],data['residentId'],data['contactName'],data.get('relationship'),data['channel'],data['direction'],data.get('subject'),data['summary'],data.get('followUpAt'),a['user_id'])); return self.send_json(201,dict(conn.execute('SELECT * FROM guardian_communications WHERE id=?',(cid,)).fetchone()))
            if p=='/api/daily-service/quick-incidents':
                required=['homeId','category','occurredAt','summary']; missing=[k for k in required if not data.get(k)]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                iid=uid('qinc'); conn.execute('INSERT INTO quick_incidents(id,tenant_id,resident_id,home_id,category,severity,occurred_at,summary,immediate_action,reported_by) VALUES(?,?,?,?,?,?,?,?,?,?)',(iid,a['tenant_id'],data.get('residentId'),data['homeId'],data['category'],data.get('severity','LOW'),data['occurredAt'],data['summary'],data.get('immediateAction'),a['user_id'])); self.audit(conn,a,'quick_incident.reported','QuickIncident',iid); return self.send_json(201,dict(conn.execute('SELECT * FROM quick_incidents WHERE id=?',(iid,)).fetchone()))
            if p=='/api/workforce/clock-in':
                employee_id=data.get('employeeProfileId')
                emp=conn.execute('SELECT * FROM employee_profiles WHERE id=? AND tenant_id=?',(employee_id,a['tenant_id'])).fetchone()
                if not emp:return self.send_json(404,{'error':'employee_not_found'})
                if conn.execute('SELECT 1 FROM workforce_time_entries WHERE tenant_id=? AND employee_profile_id=? AND clock_out_at IS NULL',(a['tenant_id'],employee_id)).fetchone():return self.send_json(409,{'error':'already_clocked_in'})
                entry_id=uid('time'); conn.execute('INSERT INTO workforce_time_entries(id,tenant_id,employee_profile_id,shift_id,clock_in_at,notes) VALUES(?,?,?,?,?,?)',(entry_id,a['tenant_id'],employee_id,data.get('shiftId'),now_iso(),data.get('notes'))); self.audit(conn,a,'workforce.clock_in','TimeEntry',entry_id,{'employeeProfileId':employee_id}); return self.send_json(201,dict(conn.execute('SELECT * FROM workforce_time_entries WHERE id=?',(entry_id,)).fetchone()))
            if p=='/api/workforce/clock-out':
                employee_id=data.get('employeeProfileId'); row=conn.execute('SELECT * FROM workforce_time_entries WHERE tenant_id=? AND employee_profile_id=? AND clock_out_at IS NULL ORDER BY clock_in_at DESC LIMIT 1',(a['tenant_id'],employee_id)).fetchone()
                if not row:return self.send_json(404,{'error':'no_open_time_entry'})
                conn.execute('UPDATE workforce_time_entries SET clock_out_at=?,notes=COALESCE(?,notes) WHERE id=?',(now_iso(),data.get('notes'),row['id'])); self.audit(conn,a,'workforce.clock_out','TimeEntry',row['id']); return self.send_json(200,dict(conn.execute('SELECT * FROM workforce_time_entries WHERE id=?',(row['id'],)).fetchone()))
            if p=='/api/workforce/leave-requests':
                employee_id=data.get('employeeProfileId'); starts=data.get('startsAt'); ends=data.get('endsAt')
                if not all([employee_id,starts,ends,data.get('leaveType')]):return self.send_json(422,{'error':'validation'})
                overlap=conn.execute("SELECT 1 FROM leave_requests WHERE tenant_id=? AND employee_profile_id=? AND status IN ('SUBMITTED','APPROVED') AND starts_at<? AND ends_at>?",(a['tenant_id'],employee_id,ends,starts)).fetchone()
                if overlap:return self.send_json(409,{'error':'leave_overlap'})
                lid=uid('leave'); conn.execute('INSERT INTO leave_requests(id,tenant_id,employee_profile_id,leave_type,starts_at,ends_at,reason) VALUES(?,?,?,?,?,?,?)',(lid,a['tenant_id'],employee_id,data['leaveType'],starts,ends,data.get('reason'))); return self.send_json(201,dict(conn.execute('SELECT * FROM leave_requests WHERE id=?',(lid,)).fetchone()))
            if p=='/api/workforce/goals':
                gid=uid('goal'); conn.execute('INSERT INTO workforce_goals(id,tenant_id,employee_profile_id,title,description,target_date) VALUES(?,?,?,?,?,?)',(gid,a['tenant_id'],data.get('employeeProfileId'),data.get('title'),data.get('description'),data.get('targetDate'))); return self.send_json(201,dict(conn.execute('SELECT * FROM workforce_goals WHERE id=?',(gid,)).fetchone()))
            if p=='/api/finance/vendors':
                name=str(data.get('name','')).strip()
                if not name:return self.send_json(422,{'error':'validation','missing':['name']})
                vid=uid('vendor')
                try: conn.execute('INSERT INTO vendors(id,tenant_id,name,category,email,phone,payment_terms,preferred,compliance_status) VALUES(?,?,?,?,?,?,?,?,?)',(vid,a['tenant_id'],name,data.get('category'),data.get('email'),data.get('phone'),data.get('paymentTerms'),int(bool(data.get('preferred'))),data.get('complianceStatus','PENDING')))
                except sqlite3.IntegrityError:return self.send_json(409,{'error':'vendor_exists'})
                self.audit(conn,a,'finance.vendor_created','Vendor',vid,{'name':name}); return self.send_json(201,dict(conn.execute('SELECT * FROM vendors WHERE id=?',(vid,)).fetchone()))
            if p=='/api/finance/budgets':
                name=str(data.get('name','')).strip(); year=int(data.get('fiscalYear') or datetime.now().year)
                if not name:return self.send_json(422,{'error':'validation','missing':['name']})
                bid=uid('budget'); conn.execute('INSERT INTO budgets(id,tenant_id,name,scope_type,scope_id,fiscal_year,status,approved_amount_cents) VALUES(?,?,?,?,?,?,?,?)',(bid,a['tenant_id'],name,data.get('scopeType','ORGANIZATION'),data.get('scopeId'),year,data.get('status','APPROVED'),int(data.get('approvedAmountCents',0))))
                self.audit(conn,a,'finance.budget_created','Budget',bid); return self.send_json(201,dict(conn.execute('SELECT * FROM budgets WHERE id=?',(bid,)).fetchone()))
            if p=='/api/finance/purchase-requests':
                title=str(data.get('title','')).strip(); items=data.get('items') or []
                if not title or not items:return self.send_json(422,{'error':'validation','missing':['title','items']})
                amount=sum(int(float(i.get('quantity',1))*int(i.get('unitPriceCents',0))) for i in items)
                budget_id=data.get('budgetId'); budget=conn.execute('SELECT * FROM budgets WHERE id=? AND tenant_id=?',(budget_id,a['tenant_id'])).fetchone() if budget_id else None
                if budget_id and not budget:return self.send_json(422,{'error':'invalid_budget'})
                number=f"PR-{datetime.now().strftime('%Y%m%d')}-{secrets.randbelow(10000):04d}"; rid=uid('pr')
                conn.execute('INSERT INTO purchase_requests(id,tenant_id,request_number,title,justification,home_id,budget_id,vendor_id,status,requested_by_user_id,requested_amount_cents,needed_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(rid,a['tenant_id'],number,title,data.get('justification'),data.get('homeId'),budget_id,data.get('vendorId'),'SUBMITTED',a['user_id'],amount,data.get('neededBy')))
                for item in items: conn.execute('INSERT INTO purchase_request_items(id,tenant_id,purchase_request_id,description,quantity,unit_price_cents,category) VALUES(?,?,?,?,?,?,?)',(uid('pri'),a['tenant_id'],rid,item.get('description','Item'),float(item.get('quantity',1)),int(item.get('unitPriceCents',0)),item.get('category')))
                self.audit(conn,a,'finance.purchase_request_created','PurchaseRequest',rid,{'amountCents':amount}); self.notify(conn,a,f'Purchase request {number} submitted','Purchase request'); return self.send_json(201,dict(conn.execute('SELECT * FROM purchase_requests WHERE id=?',(rid,)).fetchone()))
            if p=='/api/finance/purchase-orders':
                pr=conn.execute("SELECT * FROM purchase_requests WHERE id=? AND tenant_id=? AND status='FINANCE_APPROVED'",(data.get('purchaseRequestId'),a['tenant_id'])).fetchone()
                if not pr:return self.send_json(409,{'error':'purchase_request_not_approved'})
                vendor_id=data.get('vendorId') or pr['vendor_id']; vendor=conn.execute("SELECT id FROM vendors WHERE id=? AND tenant_id=? AND status='ACTIVE'",(vendor_id,a['tenant_id'])).fetchone()
                if not vendor:return self.send_json(422,{'error':'active_vendor_required'})
                number=f"PO-{datetime.now().strftime('%Y%m%d')}-{secrets.randbelow(10000):04d}"; oid=uid('po')
                conn.execute('INSERT INTO purchase_orders(id,tenant_id,po_number,purchase_request_id,vendor_id,total_cents,expected_at) VALUES(?,?,?,?,?,?,?)',(oid,a['tenant_id'],number,pr['id'],vendor_id,pr['approved_amount_cents'] or pr['requested_amount_cents'],data.get('expectedAt')))
                if pr['budget_id']: conn.execute('UPDATE budgets SET committed_amount_cents=committed_amount_cents+? WHERE id=? AND tenant_id=?',(pr['approved_amount_cents'] or pr['requested_amount_cents'],pr['budget_id'],a['tenant_id']))
                self.audit(conn,a,'finance.purchase_order_issued','PurchaseOrder',oid); return self.send_json(201,dict(conn.execute('SELECT * FROM purchase_orders WHERE id=?',(oid,)).fetchone()))
            if p=='/api/finance/receiving':
                po=conn.execute("SELECT * FROM purchase_orders WHERE id=? AND tenant_id=? AND status IN ('ISSUED','PARTIALLY_RECEIVED')",(data.get('purchaseOrderId'),a['tenant_id'])).fetchone()
                if not po:return self.send_json(409,{'error':'purchase_order_not_open'})
                rec_id=uid('recv'); conn.execute('INSERT INTO receiving_records(id,tenant_id,purchase_order_id,received_by_user_id,status,notes) VALUES(?,?,?,?,?,?)',(rec_id,a['tenant_id'],po['id'],a['user_id'],data.get('status','RECEIVED'),data.get('notes'))); conn.execute("UPDATE purchase_orders SET status='RECEIVED' WHERE id=?",(po['id'],))
                self.audit(conn,a,'finance.purchase_order_received','PurchaseOrder',po['id']); return self.send_json(201,dict(conn.execute('SELECT * FROM receiving_records WHERE id=?',(rec_id,)).fetchone()))
            if p=='/api/finance/assets':
                tag=str(data.get('assetTag','')).strip(); name=str(data.get('name','')).strip()
                if not tag or not name:return self.send_json(422,{'error':'validation','missing':['assetTag','name']})
                aid=uid('asset'); conn.execute('INSERT INTO assets(id,tenant_id,asset_tag,name,category,status,serial_number,vendor_id,purchase_order_id,home_id,purchase_date,purchase_cost_cents,assigned_to_type,assigned_to_id,next_maintenance_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(aid,a['tenant_id'],tag,name,data.get('category','GENERAL'),data.get('status','ACTIVE'),data.get('serialNumber'),data.get('vendorId'),data.get('purchaseOrderId'),data.get('homeId'),data.get('purchaseDate'),data.get('purchaseCostCents'),data.get('assignedToType'),data.get('assignedToId'),data.get('nextMaintenanceAt')))
                self.audit(conn,a,'finance.asset_created','Asset',aid); self.index_search(conn,a['tenant_id'],'Asset',aid,f'{tag} {name}',data.get('category','')); return self.send_json(201,dict(conn.execute('SELECT * FROM assets WHERE id=?',(aid,)).fetchone()))
            if p=='/api/finance/grants':
                name=str(data.get('name','')).strip(); funder=str(data.get('funder','')).strip()
                if not name or not funder:return self.send_json(422,{'error':'validation','missing':['name','funder']})
                gid=uid('grant'); conn.execute('INSERT INTO grants(id,tenant_id,name,funder,status,requested_amount_cents,awarded_amount_cents,application_due_at,award_start_at,award_end_at,reporting_due_at,owner_user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(gid,a['tenant_id'],name,funder,data.get('status','PROSPECT'),data.get('requestedAmountCents'),data.get('awardedAmountCents'),data.get('applicationDueAt'),data.get('awardStartAt'),data.get('awardEndAt'),data.get('reportingDueAt'),data.get('ownerUserId') or a['user_id']))
                self.audit(conn,a,'finance.grant_created','Grant',gid); return self.send_json(201,dict(conn.execute('SELECT * FROM grants WHERE id=?',(gid,)).fetchone()))
            if p=='/api/finance/vendor-compliance':
                vendor=conn.execute('SELECT * FROM vendors WHERE id=? AND tenant_id=?',(data.get('vendorId'),a['tenant_id'])).fetchone()
                if not vendor:return self.send_json(404,{'error':'vendor_not_found'})
                cid=uid('vcomp'); conn.execute('INSERT INTO vendor_compliance_items(id,tenant_id,vendor_id,item_type,status,reference_number,expires_at,document_key) VALUES(?,?,?,?,?,?,?,?)',(cid,a['tenant_id'],vendor['id'],data.get('itemType','INSURANCE'),data.get('status','CURRENT'),data.get('referenceNumber'),data.get('expiresAt'),data.get('documentKey')))
                return self.send_json(201,dict(conn.execute('SELECT * FROM vendor_compliance_items WHERE id=?',(cid,)).fetchone()))
            if p=='/api/finance/contracts':
                vendor=conn.execute('SELECT * FROM vendors WHERE id=? AND tenant_id=?',(data.get('vendorId'),a['tenant_id'])).fetchone()
                if not vendor:return self.send_json(404,{'error':'vendor_not_found'})
                cid=uid('contract'); conn.execute('INSERT INTO vendor_contracts(id,tenant_id,vendor_id,title,status,starts_at,ends_at,renewal_notice_days,value_cents,owner_user_id,document_key) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(cid,a['tenant_id'],vendor['id'],data.get('title','Vendor Contract'),data.get('status','ACTIVE'),data.get('startsAt'),data.get('endsAt'),int(data.get('renewalNoticeDays',30)),data.get('valueCents'),data.get('ownerUserId') or a['user_id'],data.get('documentKey')))
                self.audit(conn,a,'finance.vendor_contract_created','VendorContract',cid); return self.send_json(201,dict(conn.execute('SELECT * FROM vendor_contracts WHERE id=?',(cid,)).fetchone()))
            if p=='/api/finance/purchase-request-attachments':
                pr=conn.execute('SELECT id FROM purchase_requests WHERE id=? AND tenant_id=?',(data.get('purchaseRequestId'),a['tenant_id'])).fetchone()
                if not pr:return self.send_json(404,{'error':'purchase_request_not_found'})
                aid=uid('pratt'); conn.execute('INSERT INTO purchase_request_attachments(id,tenant_id,purchase_request_id,file_name,storage_key,content_type,created_by_user_id) VALUES(?,?,?,?,?,?,?)',(aid,a['tenant_id'],pr['id'],data.get('fileName','attachment'),data.get('storageKey'),data.get('contentType'),a['user_id']))
                return self.send_json(201,{'id':aid})
            if p=='/api/finance/invoices':
                vendor=conn.execute('SELECT * FROM vendors WHERE id=? AND tenant_id=?',(data.get('vendorId'),a['tenant_id'])).fetchone(); po=None
                if not vendor:return self.send_json(404,{'error':'vendor_not_found'})
                if data.get('purchaseOrderId'):
                    po=conn.execute('SELECT * FROM purchase_orders WHERE id=? AND tenant_id=?',(data.get('purchaseOrderId'),a['tenant_id'])).fetchone()
                    if not po:return self.send_json(404,{'error':'purchase_order_not_found'})
                items=data.get('items') or []; subtotal=sum(int(float(i.get('quantity',1))*int(i.get('unitPriceCents',0))) for i in items); tax=int(data.get('taxCents',0)); total=subtotal+tax
                iid=uid('invoice')
                try: conn.execute('INSERT INTO vendor_invoices(id,tenant_id,invoice_number,vendor_id,purchase_order_id,invoice_date,due_date,subtotal_cents,tax_cents,total_cents) VALUES(?,?,?,?,?,?,?,?,?,?)',(iid,a['tenant_id'],data.get('invoiceNumber'),vendor['id'],po['id'] if po else None,data.get('invoiceDate'),data.get('dueDate'),subtotal,tax,total))
                except sqlite3.IntegrityError:return self.send_json(409,{'error':'invoice_exists'})
                for item in items: conn.execute('INSERT INTO vendor_invoice_items(id,tenant_id,invoice_id,description,quantity,unit_price_cents,purchase_request_item_id) VALUES(?,?,?,?,?,?,?)',(uid('invi'),a['tenant_id'],iid,item.get('description','Item'),float(item.get('quantity',1)),int(item.get('unitPriceCents',0)),item.get('purchaseRequestItemId')))
                self.audit(conn,a,'finance.invoice_received','VendorInvoice',iid); return self.send_json(201,dict(conn.execute('SELECT * FROM vendor_invoices WHERE id=?',(iid,)).fetchone()))
            if p=='/api/finance/process-reminders':
                created=0; now=now_iso()
                checks=[('VENDOR_COMPLIANCE','VendorCompliance',"SELECT id,expires_at FROM vendor_compliance_items WHERE tenant_id=? AND expires_at IS NOT NULL AND expires_at<=datetime('now','+30 days') AND status<>'EXPIRED'",'Vendor compliance expires soon'),('CONTRACT_RENEWAL','VendorContract',"SELECT id,ends_at FROM vendor_contracts WHERE tenant_id=? AND status='ACTIVE' AND ends_at IS NOT NULL AND ends_at<=datetime('now','+60 days')",'Vendor contract renewal due'),('GRANT_DELIVERABLE','GrantDeliverable',"SELECT id,due_at FROM grant_deliverables WHERE tenant_id=? AND status='OPEN' AND due_at<=datetime('now','+30 days')",'Grant deliverable due')]
                for typ,entity,sql,msg in checks:
                    for r in conn.execute(sql,(a['tenant_id'],)).fetchall():
                        due=r[1]; exists=conn.execute("SELECT 1 FROM finance_reminders WHERE tenant_id=? AND reminder_type=? AND entity_id=? AND status='OPEN'",(a['tenant_id'],typ,r['id'])).fetchone()
                        if not exists: conn.execute('INSERT INTO finance_reminders(id,tenant_id,reminder_type,entity_type,entity_id,due_at,severity,message) VALUES(?,?,?,?,?,?,?,?)',(uid('frem'),a['tenant_id'],typ,entity,r['id'],due,'HIGH',msg)); created+=1
                return self.send_json(200,{'created':created,'processedAt':now})
            if p=='/api/finance/grant-deliverables':
                grant=conn.execute('SELECT id FROM grants WHERE id=? AND tenant_id=?',(data.get('grantId'),a['tenant_id'])).fetchone()
                if not grant:return self.send_json(404,{'error':'grant_not_found'})
                did=uid('gdel'); conn.execute('INSERT INTO grant_deliverables(id,tenant_id,grant_id,title,due_at,status,owner_user_id,notes) VALUES(?,?,?,?,?,?,?,?)',(did,a['tenant_id'],grant['id'],data.get('title'),data.get('dueAt'),data.get('status','OPEN'),data.get('ownerUserId') or a['user_id'],data.get('notes'))); return self.send_json(201,{'id':did})
            if p=='/api/referrals':
                if not self.require(a,'referral.write'):return
                required=['firstName','lastName']; missing=[k for k in required if not str(data.get(k,'')).strip()]
                if missing:return self.send_json(422,{'error':'validation','missing':missing})
                idem_key=self.headers.get('Idempotency-Key')
                prior=self.idempotency_lookup(conn,a,idem_key,data)
                if prior:return self.send_json(prior[1],prior[2])
                rid=uid('ref'); sla_hours={'URGENT':4,'HIGH':24,'ROUTINE':72}.get(str(data.get('urgency','ROUTINE')).upper(),72); sla_due=(datetime.now(timezone.utc)+timedelta(hours=sla_hours)).isoformat()
                org_id=data.get('sourceOrganizationId'); contact_id=data.get('sourceContactId')
                org_name=data.get('sourceOrganization')
                if org_id:
                    org=conn.execute('SELECT name FROM organizations WHERE id=? AND tenant_id=?',(org_id,a['tenant_id'])).fetchone()
                    if not org:return self.send_json(422,{'error':'invalid_source_organization'})
                    org_name=org['name']
                conn.execute('INSERT INTO referrals(id,tenant_id,applicant_first_name,applicant_last_name,source_organization,source_organization_id,source_contact_id,support_summary,funding_status,created_by,date_of_birth,phone,email,current_housing,preferred_county,requested_service,urgency,assigned_to,sla_due_at,next_action,next_action_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,a['tenant_id'],data['firstName'].strip(),data['lastName'].strip(),org_name,org_id,contact_id,data.get('supportSummary'),data.get('fundingStatus','UNKNOWN'),a['user_id'],data.get('dateOfBirth'),data.get('phone'),data.get('email'),data.get('currentHousing'),data.get('preferredCounty'),data.get('requestedService'),str(data.get('urgency','ROUTINE')).upper(),data.get('assignedTo') or a['user_id'],sla_due,'Complete intake screening',sla_due))
                conn.execute('INSERT INTO referral_assignments(id,tenant_id,referral_id,user_id,role) VALUES(?,?,?,?,?)',(uid('assign'),a['tenant_id'],rid,data.get('assignedTo') or a['user_id'],'COORDINATOR'))
                for title,blocking in [('Verify referral authorization',1),('Collect required documents',1),('Complete support-needs screening',1),('Confirm funding pathway',1)]: conn.execute('INSERT INTO intake_tasks(id,tenant_id,referral_id,title,due_at,assigned_to,blocking) VALUES(?,?,?,?,?,?,?)',(uid('task'),a['tenant_id'],rid,title,sla_due,data.get('assignedTo') or a['user_id'],blocking))
                program_code=str(data.get('programCode','SUPPORTED_LIVING')).upper()
                rules=conn.execute('SELECT item_type FROM intake_document_rules WHERE tenant_id=? AND program_code=? AND required=1',(a['tenant_id'],program_code)).fetchall()
                for rule in rules: conn.execute('INSERT INTO referral_funding_items(id,tenant_id,referral_id,item_type) VALUES(?,?,?,?)',(uid('fund'),a['tenant_id'],rid,rule['item_type']))
                candidates=conn.execute("SELECT id,applicant_first_name,applicant_last_name,date_of_birth,email,phone FROM referrals WHERE tenant_id=? AND id<>? AND disposition='ACTIVE'",(a['tenant_id'],rid)).fetchall()
                for c in candidates:
                    score=0; reasons=[]
                    if c['applicant_first_name'].lower()==data['firstName'].strip().lower() and c['applicant_last_name'].lower()==data['lastName'].strip().lower(): score+=60; reasons.append('same_name')
                    if data.get('dateOfBirth') and c['date_of_birth']==data.get('dateOfBirth'): score+=30; reasons.append('same_dob')
                    if data.get('email') and c['email'] and c['email'].lower()==data.get('email').lower(): score+=20; reasons.append('same_email')
                    if data.get('phone') and c['phone']==data.get('phone'): score+=20; reasons.append('same_phone')
                    if score>=60: conn.execute('INSERT OR IGNORE INTO duplicate_referral_matches(id,tenant_id,referral_id,possible_duplicate_id,score,reason) VALUES(?,?,?,?,?,?)',(uid('dup'),a['tenant_id'],rid,c['id'],score,','.join(reasons)))
                self.audit(conn,a,'referral.created','Referral',rid,{'name':f"{data['firstName']} {data['lastName']}",'slaDueAt':sla_due});self.activity(conn,a,rid,'CREATED','Referral created and intake workflow initialized');self.notify(conn,a,f"Referral created for {data['firstName']} {data['lastName']}; intake due {sla_due}",'Referral created');self.index_search(conn,a['tenant_id'],'Referral',rid,f"{data['firstName']} {data['lastName']}",' '.join(str(data.get(k,'')) for k in ('supportSummary','currentHousing','requestedService','preferredCounty')))
                response=dict(conn.execute('SELECT * FROM referrals WHERE id=?',(rid,)).fetchone());self.idempotency_store(conn,a,idem_key,data,201,response);return self.send_json(201,response)
            if p.startswith('/api/referrals/') and p.endswith('/intake'):
                rid=p.split('/')[3]; row=conn.execute('SELECT * FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(404,{'error':'not_found'})
                conn.execute('UPDATE referrals SET support_summary=COALESCE(?,support_summary),funding_status=COALESCE(?,funding_status),current_housing=COALESCE(?,current_housing),preferred_county=COALESCE(?,preferred_county),requested_service=COALESCE(?,requested_service),next_action=COALESCE(?,next_action),next_action_at=COALESCE(?,next_action_at),updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?',(data.get('supportSummary'),data.get('fundingStatus'),data.get('currentHousing'),data.get('preferredCounty'),data.get('requestedService'),data.get('nextAction'),data.get('nextActionAt'),rid,a['tenant_id']))
                for need in data.get('supportNeeds',[]):
                    conn.execute('INSERT INTO referral_support_needs(id,tenant_id,referral_id,domain,level,details) VALUES(?,?,?,?,?,?) ON CONFLICT(tenant_id,referral_id,domain) DO UPDATE SET level=excluded.level,details=excluded.details',(uid('need'),a['tenant_id'],rid,str(need.get('domain','GENERAL')).upper(),str(need.get('level','UNKNOWN')).upper(),need.get('details')))
                for item in data.get('fundingChecklist',[]):
                    status=str(item.get('status','REQUIRED')).upper(); verified=status=='VERIFIED'
                    conn.execute('INSERT INTO referral_funding_items(id,tenant_id,referral_id,item_type,status,reference_number,expires_at,verified_by,verified_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,referral_id,item_type) DO UPDATE SET status=excluded.status,reference_number=excluded.reference_number,expires_at=excluded.expires_at,verified_by=excluded.verified_by,verified_at=excluded.verified_at',(uid('fund'),a['tenant_id'],rid,str(item.get('itemType')).upper(),status,item.get('referenceNumber'),item.get('expiresAt'),a['user_id'] if verified else None,now_iso() if verified else None))
                self.audit(conn,a,'referral.intake_updated','Referral',rid,{'supportNeeds':len(data.get('supportNeeds',[])),'fundingItems':len(data.get('fundingChecklist',[]))});self.activity(conn,a,rid,'INTAKE_UPDATED','Referral intake profile updated')
                return self.send_json(200,{'updated':True})
            if p.startswith('/api/referrals/') and p.endswith('/activities'):
                rid=p.split('/')[3]; row=conn.execute('SELECT id FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(404,{'error':'not_found'})
                summary=str(data.get('summary','')).strip()
                if not summary:return self.send_json(422,{'error':'validation','missing':['summary']})
                activity_type=str(data.get('activityType','NOTE')).upper()
                self.activity(conn,a,rid,activity_type,summary,data.get('details'));self.audit(conn,a,'referral.activity_created','Referral',rid,{'activityType':activity_type})
                return self.send_json(201,{'created':True})
            if p.startswith('/api/referrals/') and p.endswith('/documents'):
                rid=p.split('/')[3]; row=conn.execute('SELECT id FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(404,{'error':'not_found'})
                file_name=str(data.get('fileName','')).strip(); item_type=str(data.get('itemType','OTHER')).upper()
                if not file_name:return self.send_json(422,{'error':'validation','missing':['fileName']})
                doc_id=uid('doc'); storage_key=f"{a['tenant_id']}/referrals/{rid}/{doc_id}/{Path(file_name).name}"
                conn.execute('INSERT INTO intake_documents(id,tenant_id,referral_id,item_type,file_name,storage_key,status,uploaded_by) VALUES(?,?,?,?,?,?,?,?)',(doc_id,a['tenant_id'],rid,item_type,file_name,storage_key,'AVAILABLE',a['user_id']))
                conn.execute("UPDATE referral_funding_items SET status='RECEIVED' WHERE tenant_id=? AND referral_id=? AND item_type=?",(a['tenant_id'],rid,item_type))
                self.activity(conn,a,rid,'DOCUMENT_RECEIVED',f'Document received: {file_name}',{'itemType':item_type,'documentId':doc_id}); self.audit(conn,a,'intake.document_linked','Referral',rid,{'documentId':doc_id,'itemType':item_type})
                return self.send_json(201,dict(conn.execute('SELECT * FROM intake_documents WHERE id=?',(doc_id,)).fetchone()))
            if p.startswith('/api/referrals/') and p.endswith('/communications'):
                rid=p.split('/')[3]; row=conn.execute('SELECT id FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(404,{'error':'not_found'})
                summary=str(data.get('summary','')).strip()
                if not summary:return self.send_json(422,{'error':'validation','missing':['summary']})
                cid=uid('comm'); conn.execute('INSERT INTO referral_communications(id,tenant_id,referral_id,direction,channel,subject,summary,contact_name,contact_value,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',(cid,a['tenant_id'],rid,str(data.get('direction','OUTBOUND')).upper(),str(data.get('channel','PHONE')).upper(),data.get('subject'),summary,data.get('contactName'),data.get('contactValue'),a['user_id']))
                self.activity(conn,a,rid,'COMMUNICATION',summary,{'channel':data.get('channel','PHONE')}); return self.send_json(201,{'id':cid})
            if p.startswith('/api/referrals/') and p.endswith('/meetings'):
                rid=p.split('/')[3]; scheduled=str(data.get('scheduledAt','')).strip()
                if not scheduled:return self.send_json(422,{'error':'validation','missing':['scheduledAt']})
                mid=uid('meeting'); conn.execute('INSERT INTO intake_meetings(id,tenant_id,referral_id,meeting_type,scheduled_at,duration_minutes,location,created_by) VALUES(?,?,?,?,?,?,?,?)',(mid,a['tenant_id'],rid,str(data.get('meetingType','INTAKE')).upper(),scheduled,int(data.get('durationMinutes',60)),data.get('location'),a['user_id']))
                self.activity(conn,a,rid,'MEETING_SCHEDULED','Intake meeting scheduled',{'scheduledAt':scheduled}); self.notify(conn,a,f'Intake meeting scheduled for {scheduled}','Intake meeting'); return self.send_json(201,{'id':mid})
            if p.startswith('/api/referrals/') and p.endswith('/reassign'):
                rid=p.split('/')[3]; user_id=data.get('userId')
                user=conn.execute('SELECT id FROM users WHERE id=? AND tenant_id=?',(user_id,a['tenant_id'])).fetchone()
                if not user:return self.send_json(422,{'error':'invalid_assignee'})
                conn.execute('UPDATE referral_assignments SET ended_at=? WHERE tenant_id=? AND referral_id=? AND ended_at IS NULL',(now_iso(),a['tenant_id'],rid))
                conn.execute('INSERT INTO referral_assignments(id,tenant_id,referral_id,user_id,role) VALUES(?,?,?,?,?)',(uid('assign'),a['tenant_id'],rid,user_id,'COORDINATOR'))
                conn.execute('UPDATE referrals SET assigned_to=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?',(user_id,rid,a['tenant_id']))
                conn.execute("UPDATE intake_tasks SET assigned_to=? WHERE tenant_id=? AND referral_id=? AND status='OPEN'",(user_id,a['tenant_id'],rid)); self.activity(conn,a,rid,'REASSIGNED','Referral reassigned',{'userId':user_id}); return self.send_json(200,{'reassigned':True})
            if p.startswith('/api/referrals/') and p.endswith('/screening-outcome'):
                rid=p.split('/')[3]; outcome=str(data.get('outcome','')).upper()
                if outcome not in {'CONTINUE','WAITLIST','DECLINE'}:return self.send_json(422,{'error':'invalid_outcome'})
                oid=uid('outcome'); conn.execute('INSERT INTO screening_outcomes(id,tenant_id,referral_id,outcome,reason_code,rationale,decided_by) VALUES(?,?,?,?,?,?,?)',(oid,a['tenant_id'],rid,outcome,data.get('reasonCode'),data.get('rationale'),a['user_id']))
                if outcome=='WAITLIST':
                    conn.execute("UPDATE referrals SET disposition='WAITLISTED',waitlist_status='ACTIVE',status='WAITLISTED' WHERE id=? AND tenant_id=?",(rid,a['tenant_id']))
                    conn.execute('INSERT OR REPLACE INTO waitlist_entries(id,tenant_id,referral_id,priority,status,review_at,notes) VALUES(?,?,?,?,?,?,?)',(uid('wait'),a['tenant_id'],rid,int(data.get('priority',100)),'ACTIVE',data.get('reviewAt'),data.get('rationale')))
                elif outcome=='DECLINE': conn.execute("UPDATE referrals SET disposition='DECLINED',disposition_reason=?,status='DECLINED' WHERE id=? AND tenant_id=?",(data.get('rationale'),rid,a['tenant_id']))
                else: conn.execute("UPDATE referrals SET disposition='ACTIVE',status=CASE WHEN status IN ('WAITLISTED','DECLINED') THEN 'NEW' ELSE status END WHERE id=? AND tenant_id=?",(rid,a['tenant_id']))
                self.activity(conn,a,rid,'SCREENING_OUTCOME',f'Screening outcome: {outcome}',{'rationale':data.get('rationale')}); self.audit(conn,a,'referral.screening_outcome','Referral',rid,{'outcome':outcome}); return self.send_json(201,{'id':oid,'outcome':outcome})
            if p.startswith('/api/referrals/') and p.endswith('/readiness'):
                rid=p.split('/')[3]; row=conn.execute('SELECT * FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(404,{'error':'not_found'})
                conn.execute("UPDATE referrals SET management_approved=?,assessment_complete=?,documents_verified=?,status='READY',updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?",(int(bool(data.get('managementApproved'))),int(bool(data.get('assessmentComplete'))),int(bool(data.get('documentsVerified'))),rid,a['tenant_id']))
                self.audit(conn,a,'referral.readiness_updated','Referral',rid,data); self.activity(conn,a,rid,'READINESS_UPDATED','Readiness requirements updated',data); return self.send_json(200,dict(conn.execute('SELECT * FROM referrals WHERE id=?',(rid,)).fetchone()))
            if p.startswith('/api/referrals/') and p.endswith('/admit'):
                rid=p.split('/')[3]; ref=conn.execute('SELECT * FROM referrals WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not ref:return self.send_json(404,{'error':'not_found'})
                if not(ref['management_approved'] and ref['assessment_complete'] and ref['documents_verified']):return self.send_json(409,{'error':'not_ready','message':'Management approval, assessment, and documents are required.'})
                bed=conn.execute("SELECT b.*,h.id home_id FROM beds b JOIN homes h ON h.id=b.home_id WHERE b.id=? AND b.tenant_id=?",(data.get('bedId'),a['tenant_id'])).fetchone()
                if not bed:return self.send_json(409,{'error':'bed_unavailable'})
                # Atomic compare-and-set: exactly one concurrent request can change AVAILABLE to OCCUPIED.
                claimed=conn.execute("UPDATE beds SET status='OCCUPIED' WHERE id=? AND tenant_id=? AND status='AVAILABLE'",(bed['id'],a['tenant_id']))
                if claimed.rowcount != 1:return self.send_json(409,{'error':'bed_unavailable'})
                admission_id,resident_id=uid('adm'),uid('res')
                try:
                    conn.execute('INSERT INTO admissions(id,tenant_id,referral_id,home_id,bed_id,admitted_by) VALUES(?,?,?,?,?,?)',(admission_id,a['tenant_id'],rid,bed['home_id'],bed['id'],a['user_id']))
                    conn.execute('INSERT INTO residents(id,tenant_id,referral_id,first_name,last_name,home_id,bed_id) VALUES(?,?,?,?,?,?,?)',(resident_id,a['tenant_id'],rid,ref['applicant_first_name'],ref['applicant_last_name'],bed['home_id'],bed['id']))
                except Exception:
                    conn.execute("UPDATE beds SET status='AVAILABLE' WHERE id=? AND tenant_id=?",(bed['id'],a['tenant_id']))
                    raise
                conn.execute("UPDATE referrals SET status='ADMITTED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?",(rid,a['tenant_id']))
                self.audit(conn,a,'resident.admitted','Resident',resident_id,{'referralId':rid,'bedId':bed['id']}); self.notify(conn,a,f"Resident {ref['applicant_first_name']} {ref['applicant_last_name']} admitted",'Admission completed'); self.index_search(conn,a['tenant_id'],'Resident',resident_id,f"{ref['applicant_first_name']} {ref['applicant_last_name']}",'Active resident'); self.activity(conn,a,rid,'ADMITTED','Referral admitted',{'residentId':resident_id,'bedId':bed['id']})
                return self.send_json(201,{'admissionId':admission_id,'residentId':resident_id})
        return self.send_json(404,{'error':'not_found'})

    def do_PATCH(self):
        p=urlparse(self.path).path; data=self.read_json() or {}; a=self.auth()
        if not a:return self.send_json(401,{'error':'unauthorized'})
        with db() as conn:
            if p.startswith('/api/ai/approvals/'):
                approval_id=p.split('/')[4]; approval=conn.execute('SELECT * FROM ai_approvals WHERE id=? AND tenant_id=?',(approval_id,a['tenant_id'])).fetchone()
                if not approval:return self.send_json(404,{'error':'approval_not_found'})
                decision=data.get('decision','').upper()
                if decision not in ('APPROVED','REJECTED'):return self.send_json(400,{'error':'invalid_decision'})
                conn.execute('UPDATE ai_approvals SET status=?,decision_notes=?,decided_by_user_id=?,decided_at=? WHERE id=?',(decision,data.get('notes'),a['user_id'],now_iso(),approval_id))
                conn.execute('UPDATE ai_executions SET status=? WHERE id=?',('COMPLETED' if decision=='APPROVED' else 'REJECTED',approval['execution_id']))
                self.audit(conn,a,'ai.approval_decided','AIApproval',approval_id,{'decision':decision}); return self.send_json(200,dict(conn.execute('SELECT * FROM ai_approvals WHERE id=?',(approval_id,)).fetchone()))
            if p.startswith('/api/analytics/kpis/') and p.endswith('/certify'):
                key=p.split('/')[4]; definition=conn.execute('SELECT * FROM kpi_definitions WHERE tenant_id=? AND metric_key=?',(a['tenant_id'],key)).fetchone()
                if not definition:return self.send_json(404,{'error':'metric_not_found'})
                status=data.get('status','CERTIFIED'); cid=uid('cert')
                conn.execute('INSERT INTO metric_certifications(id,tenant_id,metric_key,owner_user_id,certification_status,methodology,source_systems_json,certified_by_user_id,certified_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,metric_key) DO UPDATE SET owner_user_id=excluded.owner_user_id,certification_status=excluded.certification_status,methodology=excluded.methodology,source_systems_json=excluded.source_systems_json,certified_by_user_id=excluded.certified_by_user_id,certified_at=excluded.certified_at,expires_at=excluded.expires_at,updated_at=CURRENT_TIMESTAMP',(cid,a['tenant_id'],key,data.get('ownerUserId') or a['user_id'],status,data.get('methodology','Approved system calculation'),json.dumps(data.get('sourceSystems',['AMC-EOS'])),a['user_id'],now_iso() if status=='CERTIFIED' else None,data.get('expiresAt')))
                conn.execute('UPDATE kpi_definitions SET owner_user_id=?,certified_by_user_id=?,certified_at=? WHERE tenant_id=? AND metric_key=?',(data.get('ownerUserId') or a['user_id'],a['user_id'],now_iso(),a['tenant_id'],key)); self.audit(conn,a,'analytics.metric_certified','KpiDefinition',key,{'status':status}); return self.send_json(200,dict(conn.execute('SELECT * FROM metric_certifications WHERE tenant_id=? AND metric_key=?',(a['tenant_id'],key)).fetchone()))
            if p.startswith('/api/analytics/remediation-tasks/'):
                tid=p.split('/')[4]; task=conn.execute('SELECT * FROM data_quality_remediation_tasks WHERE id=? AND tenant_id=?',(tid,a['tenant_id'])).fetchone()
                if not task:return self.send_json(404,{'error':'not_found'})
                status=data.get('status',task['status']); completed=now_iso() if status=='COMPLETED' else None
                conn.execute('UPDATE data_quality_remediation_tasks SET status=?,assigned_user_id=COALESCE(?,assigned_user_id),resolution_notes=COALESCE(?,resolution_notes),completed_at=? WHERE id=?',(status,data.get('assignedUserId'),data.get('resolutionNotes'),completed,tid)); return self.send_json(200,dict(conn.execute('SELECT * FROM data_quality_remediation_tasks WHERE id=?',(tid,)).fetchone()))
            if p.startswith('/api/finance/purchase-requests/') and p.endswith('/approve'):
                rid=p.split('/')[4]; stage=str(data.get('stage','MANAGER')).upper(); approved=bool(data.get('approved',True)); pr=conn.execute('SELECT * FROM purchase_requests WHERE id=? AND tenant_id=?',(rid,a['tenant_id'])).fetchone()
                if not pr:return self.send_json(404,{'error':'not_found'})
                if not approved: status='REJECTED'
                elif stage=='MANAGER' and pr['status']=='SUBMITTED': status='MANAGER_APPROVED'
                elif stage=='FINANCE' and pr['status']=='MANAGER_APPROVED': status='FINANCE_APPROVED'
                else:return self.send_json(409,{'error':'invalid_approval_transition','currentStatus':pr['status']})
                amount=int(data.get('approvedAmountCents') or pr['requested_amount_cents'])
                if status=='FINANCE_APPROVED' and pr['budget_id']:
                    budget=conn.execute('SELECT * FROM budgets WHERE id=? AND tenant_id=?',(pr['budget_id'],a['tenant_id'])).fetchone()
                    if budget and budget['approved_amount_cents']-budget['committed_amount_cents']<amount:return self.send_json(409,{'error':'insufficient_budget'})
                conn.execute('UPDATE purchase_requests SET status=?,approved_amount_cents=?,approved_by_user_id=?,approved_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,amount,a['user_id'],now_iso(),rid)); self.audit(conn,a,'finance.purchase_request_approved','PurchaseRequest',rid,{'status':status,'amountCents':amount}); return self.send_json(200,dict(conn.execute('SELECT * FROM purchase_requests WHERE id=?',(rid,)).fetchone()))
            if p.startswith('/api/finance/invoices/') and p.endswith('/match'):
                iid=p.split('/')[4]; inv=conn.execute('SELECT * FROM vendor_invoices WHERE id=? AND tenant_id=?',(iid,a['tenant_id'])).fetchone()
                if not inv:return self.send_json(404,{'error':'invoice_not_found'})
                po=conn.execute('SELECT * FROM purchase_orders WHERE id=? AND tenant_id=?',(inv['purchase_order_id'],a['tenant_id'])).fetchone() if inv['purchase_order_id'] else None
                received=0
                if po:
                    recs=conn.execute('SELECT id FROM receiving_records WHERE purchase_order_id=? AND tenant_id=?',(po['id'],a['tenant_id'])).fetchall()
                    received=po['total_cents'] if recs else 0
                expected=po['total_cents'] if po else inv['total_cents']; matched=min(inv['total_cents'],expected,received or expected); discrepancy=inv['total_cents']-matched
                status='MATCHED' if discrepancy==0 and (not po or received>0) else 'DISCREPANCY'
                conn.execute('UPDATE vendor_invoices SET status=?,matched_amount_cents=?,discrepancy_cents=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,matched,discrepancy,iid))
                if discrepancy!=0: conn.execute('INSERT INTO invoice_discrepancies(id,tenant_id,invoice_id,discrepancy_type,amount_cents,details) VALUES(?,?,?,?,?,?)',(uid('disc'),a['tenant_id'],iid,'AMOUNT_MISMATCH',abs(discrepancy),'Invoice total does not match PO/receiving'))
                return self.send_json(200,dict(conn.execute('SELECT * FROM vendor_invoices WHERE id=?',(iid,)).fetchone()))
            if p.startswith('/api/finance/invoice-discrepancies/') and p.endswith('/resolve'):
                did=p.split('/')[4]; cur=conn.execute("UPDATE invoice_discrepancies SET status='RESOLVED',details=COALESCE(?,details),resolved_by_user_id=?,resolved_at=? WHERE id=? AND tenant_id=? AND status='OPEN'",(data.get('resolutionNotes'),a['user_id'],now_iso(),did,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(409,{'error':'discrepancy_not_open'})
                return self.send_json(200,dict(conn.execute('SELECT * FROM invoice_discrepancies WHERE id=?',(did,)).fetchone()))
            if p.startswith('/api/finance/invoices/') and p.endswith('/approve'):
                iid=p.split('/')[4]; inv=conn.execute("SELECT * FROM vendor_invoices WHERE id=? AND tenant_id=? AND status='MATCHED'",(iid,a['tenant_id'])).fetchone()
                if not inv:return self.send_json(409,{'error':'invoice_not_matched'})
                conn.execute("UPDATE vendor_invoices SET status='APPROVED',updated_at=CURRENT_TIMESTAMP WHERE id=?",(iid,))
                if inv['purchase_order_id']:
                    po=conn.execute('SELECT * FROM purchase_orders WHERE id=?',(inv['purchase_order_id'],)).fetchone(); pr=conn.execute('SELECT * FROM purchase_requests WHERE id=?',(po['purchase_request_id'],)).fetchone() if po else None
                    if pr and pr['budget_id']:
                        conn.execute('UPDATE budgets SET committed_amount_cents=MAX(0,committed_amount_cents-?),actual_amount_cents=actual_amount_cents+? WHERE id=?',(inv['total_cents'],inv['total_cents'],pr['budget_id']))
                        conn.execute('INSERT INTO budget_transactions(id,tenant_id,budget_id,transaction_type,reference_type,reference_id,amount_cents,notes,created_by_user_id) VALUES(?,?,?,?,?,?,?,?,?)',(uid('btx'),a['tenant_id'],pr['budget_id'],'ACTUAL','INVOICE',iid,inv['total_cents'],'Approved matched invoice',a['user_id']))
                return self.send_json(200,dict(conn.execute('SELECT * FROM vendor_invoices WHERE id=?',(iid,)).fetchone()))
            if p.startswith('/api/finance/assets/') and p.endswith('/transfer'):
                aid=p.split('/')[4]; asset=conn.execute('SELECT * FROM assets WHERE id=? AND tenant_id=?',(aid,a['tenant_id'])).fetchone()
                if not asset:return self.send_json(404,{'error':'not_found'})
                tid=uid('atr'); conn.execute('INSERT INTO asset_transfers(id,tenant_id,asset_id,from_type,from_id,to_type,to_id,transferred_by_user_id,notes) VALUES(?,?,?,?,?,?,?,?,?)',(tid,a['tenant_id'],aid,asset['assigned_to_type'],asset['assigned_to_id'],data.get('toType'),data.get('toId'),a['user_id'],data.get('notes'))); conn.execute("UPDATE assets SET assigned_to_type=?,assigned_to_id=?,status='ASSIGNED' WHERE id=?",(data.get('toType'),data.get('toId'),aid)); return self.send_json(200,{'id':tid})
            if p.startswith('/api/finance/assets/') and p.endswith('/inspect'):
                aid=p.split('/')[4]; asset=conn.execute('SELECT id FROM assets WHERE id=? AND tenant_id=?',(aid,a['tenant_id'])).fetchone()
                if not asset:return self.send_json(404,{'error':'not_found'})
                iid=uid('ains'); conn.execute('INSERT INTO asset_inspections(id,tenant_id,asset_id,inspection_type,status,inspected_by_user_id,next_inspection_at,findings) VALUES(?,?,?,?,?,?,?,?)',(iid,a['tenant_id'],aid,data.get('inspectionType','ROUTINE'),data.get('status','PASS'),a['user_id'],data.get('nextInspectionAt'),data.get('findings'))); return self.send_json(201,{'id':iid})
            if p.startswith('/api/finance/assets/') and p.endswith('/dispose'):
                aid=p.split('/')[4]; asset=conn.execute("SELECT id FROM assets WHERE id=? AND tenant_id=? AND status<>'DISPOSED'",(aid,a['tenant_id'])).fetchone()
                if not asset:return self.send_json(409,{'error':'asset_not_disposable'})
                did=uid('adis'); conn.execute('INSERT INTO asset_disposals(id,tenant_id,asset_id,method,reason,proceeds_cents,approved_by_user_id) VALUES(?,?,?,?,?,?,?)',(did,a['tenant_id'],aid,data.get('method','RECYCLE'),data.get('reason'),int(data.get('proceedsCents',0)),a['user_id'])); conn.execute("UPDATE assets SET status='DISPOSED',assigned_to_type=NULL,assigned_to_id=NULL WHERE id=?",(aid,)); return self.send_json(200,{'id':did})
            if p.startswith('/api/finance/assets/') and p.endswith('/maintenance'):
                aid=p.split('/')[4]; asset=conn.execute('SELECT * FROM assets WHERE id=? AND tenant_id=?',(aid,a['tenant_id'])).fetchone()
                if not asset:return self.send_json(404,{'error':'not_found'})
                mid=uid('maint'); conn.execute('INSERT INTO asset_maintenance(id,tenant_id,asset_id,maintenance_type,status,scheduled_at,cost_cents,notes) VALUES(?,?,?,?,?,?,?,?)',(mid,a['tenant_id'],aid,data.get('maintenanceType','PREVENTIVE'),data.get('status','SCHEDULED'),data.get('scheduledAt') or now_iso(),data.get('costCents'),data.get('notes'))); conn.execute("UPDATE assets SET status='MAINTENANCE',next_maintenance_at=? WHERE id=?",(data.get('nextMaintenanceAt'),aid)); return self.send_json(201,{'id':mid})
            if p.startswith('/api/daily-service/handoffs/') and p.endswith('/acknowledge'):
                hid=p.split('/')[4]; cur=conn.execute("UPDATE shift_handoffs SET status='ACKNOWLEDGED',acknowledged_at=?,acknowledged_by=? WHERE id=? AND tenant_id=? AND status='SUBMITTED'",(now_iso(),a['user_id'],hid,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(409,{'error':'handoff_not_submitted'})
                return self.send_json(200,dict(conn.execute('SELECT * FROM shift_handoffs WHERE id=?',(hid,)).fetchone()))
            if p.startswith('/api/daily-service/tasks/') and p.endswith('/complete'):
                tid=p.split('/')[4]; cur=conn.execute("UPDATE resident_daily_tasks SET status='COMPLETED',completed_at=?,completed_by=?,notes=COALESCE(?,notes) WHERE id=? AND tenant_id=? AND status<>'COMPLETED'",(now_iso(),a['user_id'],data.get('notes'),tid,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(409,{'error':'task_not_open'})
                return self.send_json(200,dict(conn.execute('SELECT * FROM resident_daily_tasks WHERE id=?',(tid,)).fetchone()))
            if p.startswith('/api/daily-service/shifts/') and p.endswith('/close'):
                sid=p.split('/')[4]; shift=conn.execute("SELECT * FROM service_shifts WHERE id=? AND tenant_id=? AND status='ACTIVE'",(sid,a['tenant_id'])).fetchone()
                if not shift:return self.send_json(409,{'error':'shift_not_active'})
                pending=conn.execute("SELECT COUNT(*) FROM shift_handoffs WHERE tenant_id=? AND home_id=? AND outgoing_employee_id=? AND status NOT IN ('ACKNOWLEDGED','CLOSED')",(a['tenant_id'],shift['home_id'],shift['employee_id'])).fetchone()[0]
                if pending:return self.send_json(409,{'error':'handoff_not_acknowledged'})
                conn.execute("UPDATE service_shifts SET status='CLOSED',ended_at=?,closing_summary=?,reviewed_by=?,reviewed_at=? WHERE id=?",(now_iso(),data.get('closingSummary'),a['user_id'],now_iso(),sid)); self.audit(conn,a,'service_shift.closed','ServiceShift',sid); return self.send_json(200,dict(conn.execute('SELECT * FROM service_shifts WHERE id=?',(sid,)).fetchone()))
            if p.startswith('/api/daily-service/handoffs/') and p.endswith('/close'):
                hid=p.split('/')[4]; cur=conn.execute("UPDATE shift_handoffs SET status='CLOSED',closed_at=?,closed_by=?,outgoing_signature=COALESCE(?,outgoing_signature),incoming_signature=COALESCE(?,incoming_signature) WHERE id=? AND tenant_id=? AND status='ACKNOWLEDGED'",(now_iso(),a['user_id'],data.get('outgoingSignature'),data.get('incomingSignature'),hid,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(409,{'error':'handoff_not_acknowledged'})
                return self.send_json(200,dict(conn.execute('SELECT * FROM shift_handoffs WHERE id=?',(hid,)).fetchone()))
            if p.startswith('/api/daily-service/appointments/') and p.endswith('/complete'):
                aid=p.split('/')[4]; cur=conn.execute("UPDATE resident_appointments SET status='COMPLETED',completed_at=?,outcome=?,follow_up=?,follow_up_due_at=? WHERE id=? AND tenant_id=? AND status IN ('SCHEDULED','CONFIRMED')",(now_iso(),data.get('outcome'),data.get('followUp'),data.get('followUpDueAt'),aid,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(409,{'error':'appointment_not_open'})
                ap=conn.execute('SELECT * FROM resident_appointments WHERE id=?',(aid,)).fetchone(); conn.execute('INSERT INTO service_timeline_events(id,tenant_id,resident_id,event_type,title,details_json,created_by) VALUES(?,?,?,?,?,?,?)',(uid('ste'),a['tenant_id'],ap['resident_id'],'APPOINTMENT_COMPLETED',f"Appointment completed: {ap['appointment_type']}",json.dumps({'outcome':data.get('outcome'),'followUp':data.get('followUp')}),a['user_id'])); return self.send_json(200,dict(ap))
            if p.startswith('/api/daily-service/quick-incidents/') and p.endswith('/convert'):
                iid=p.split('/')[4]; row=conn.execute("SELECT * FROM quick_incidents WHERE id=? AND tenant_id=? AND status IN ('REPORTED','ESCALATED')",(iid,a['tenant_id'])).fetchone()
                if not row:return self.send_json(409,{'error':'incident_not_convertible'})
                full_id=uid('incident'); conn.execute("UPDATE quick_incidents SET status='CONVERTED',full_incident_id=?,converted_at=?,converted_by=? WHERE id=?",(full_id,now_iso(),a['user_id'],iid)); self.audit(conn,a,'quick_incident.converted','QuickIncident',iid,{'fullIncidentId':full_id}); return self.send_json(200,{'quickIncidentId':iid,'fullIncidentId':full_id,'status':'CONVERTED'})
            if p.startswith('/api/workforce/leave-requests/') and p.endswith('/review'):
                lid=p.split('/')[4]; approved=bool(data.get('approved')); cur=conn.execute("UPDATE leave_requests SET status=?,reviewed_by=?,reviewed_at=?,review_notes=? WHERE id=? AND tenant_id=?",('APPROVED' if approved else 'REJECTED',a['user_id'],now_iso(),data.get('notes'),lid,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(404,{'error':'not_found'})
                return self.send_json(200,dict(conn.execute('SELECT * FROM leave_requests WHERE id=?',(lid,)).fetchone()))
            if p.startswith('/api/intake-tasks/') and p.endswith('/complete'):
                task_id=p.split('/')[3]; cur=conn.execute("UPDATE intake_tasks SET status='COMPLETED',completed_at=?,completed_by=? WHERE id=? AND tenant_id=? AND status='OPEN'",(now_iso(),a['user_id'],task_id,a['tenant_id']))
                if cur.rowcount!=1:return self.send_json(404,{'error':'not_found_or_completed'})
                task=conn.execute('SELECT referral_id,title FROM intake_tasks WHERE id=?',(task_id,)).fetchone(); self.activity(conn,a,task['referral_id'],'TASK_COMPLETED',f"Task completed: {task['title']}"); return self.send_json(200,{'completed':True})
            if p=='/api/intake-operations/process-reminders':
                warning_cutoff=(datetime.now(timezone.utc)+timedelta(hours=6)).isoformat(); now=now_iso(); warnings=breaches=escalated=0
                for r in conn.execute("SELECT * FROM referrals WHERE tenant_id=? AND disposition='ACTIVE' AND status NOT IN ('ADMITTED','CLOSED')",(a['tenant_id'],)).fetchall():
                    if r['sla_due_at'] and r['sla_due_at']<now and not r['sla_breach_sent_at']:
                        conn.execute('UPDATE referrals SET sla_breach_sent_at=? WHERE id=?',(now,r['id'])); self.notify(conn,a,f"SLA breached for {r['applicant_first_name']} {r['applicant_last_name']}",'Referral SLA breach',r['assigned_to']); breaches+=1
                    elif r['sla_due_at'] and r['sla_due_at']<=warning_cutoff and not r['sla_warning_sent_at']:
                        conn.execute('UPDATE referrals SET sla_warning_sent_at=? WHERE id=?',(now,r['id'])); self.notify(conn,a,f"SLA approaching for {r['applicant_first_name']} {r['applicant_last_name']}",'Referral SLA warning',r['assigned_to']); warnings+=1
                for t in conn.execute("SELECT * FROM intake_tasks WHERE tenant_id=? AND status='OPEN' AND due_at<CURRENT_TIMESTAMP",(a['tenant_id'],)).fetchall():
                    conn.execute('UPDATE intake_tasks SET escalation_level=escalation_level+1,escalated_at=? WHERE id=?',(now,t['id'])); self.notify(conn,a,f"Overdue intake task: {t['title']}",'Intake task overdue',t['assigned_to']); escalated+=1
                return self.send_json(200,{'warnings':warnings,'breaches':breaches,'tasksEscalated':escalated})
            if p.startswith('/api/notifications/') and p.endswith('/read'):
                nid=p.split('/')[3]; cur=conn.execute("UPDATE notifications SET status='READ',read_at=? WHERE id=? AND tenant_id=? AND (user_id=? OR user_id IS NULL)",(now_iso(),nid,a['tenant_id'],a['user_id']))
                if cur.rowcount!=1:return self.send_json(404,{'error':'not_found'})
                return self.send_json(200,{'read':True})
            if p.startswith('/api/sessions/') and p.endswith('/revoke'):
                if a['role']!='ADMIN':return self.send_json(403,{'error':'forbidden'})
                token=p.split('/')[3]; cur=conn.execute('UPDATE sessions SET revoked_at=? WHERE token=? AND tenant_id=?',(now_iso(),token,a['tenant_id']))
                return self.send_json(200,{'revoked':cur.rowcount})
        return self.send_json(404,{'error':'not_found'})

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('command',nargs='?',default='serve',choices=['serve','migrate','seed']); ap.add_argument('--port',type=int,default=int(os.getenv('PORT','8080'))); args=ap.parse_args()
    if args.command=='migrate': migrate(); print('migrations applied'); return
    if args.command=='seed': seed(); print('seed complete'); return
    seed(); os.chdir(STATIC); server=ThreadingHTTPServer(('0.0.0.0',args.port),Handler); print(f'AMC-EOS pilot running at http://localhost:{args.port}'); server.serve_forever()
if __name__=='__main__': main()
